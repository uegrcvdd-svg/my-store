'use client';
import { useState, useCallback } from 'react';
import Image from 'next/image';
import Link from 'next/link';
import { Search, X } from 'lucide-react';
import { useRouter } from 'next/navigation';
import { useDebounce } from '../../hooks/useDebounce';

interface HeaderProps {
  onSearch?: (q: string) => void;
  showSearch?: boolean;
}

export default function Header({ onSearch, showSearch = true }: HeaderProps) {
  const [query, setQuery] = useState('');
  const router = useRouter();

  const handleChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const val = e.target.value;
      setQuery(val);
      if (onSearch) onSearch(val);
    },
    [onSearch]
  );

  const handleClear = () => {
    setQuery('');
    if (onSearch) onSearch('');
  };

  return (
    <header className="sticky top-0 z-40 bg-white shadow-sm">
      <div className="page-padding py-3">
        <div className="flex items-center gap-3 max-w-2xl mx-auto">
          {/* Logo */}
          <Link href="/" className="flex-shrink-0">
            <Image
              src="/logo.png"
              alt="طابع"
              width={80}
              height={50}
              className="h-10 w-auto object-contain"
              priority
            />
          </Link>

          {/* Search bar */}
          {showSearch && (
            <div className="flex-1 relative">
              <Search
                size={18}
                className="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400 pointer-events-none"
              />
              <input
                type="search"
                value={query}
                onChange={handleChange}
                placeholder="ابحث عن خضار أو فاكهة..."
                className="w-full bg-gray-100 rounded-full pr-10 pl-10 py-2.5 text-sm
                           focus:outline-none focus:bg-white focus:ring-2 focus:ring-primary-700
                           transition-all placeholder-gray-400"
                enterKeyHint="search"
              />
              {query && (
                <button
                  onClick={handleClear}
                  className="absolute top-1/2 -translate-y-1/2 left-3 text-gray-400 hover:text-gray-600"
                >
                  <X size={16} />
                </button>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
