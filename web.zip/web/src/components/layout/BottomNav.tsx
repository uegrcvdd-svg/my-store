'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, Leaf, Apple, ShoppingCart } from 'lucide-react';
import { useCartStore } from '../../store/cartStore';

const navItems = [
  { href: '/', label: 'الرئيسية', icon: Home },
  { href: '/vegetables', label: 'الخضار', icon: Leaf },
  { href: '/fruits', label: 'الفاكهة', icon: Apple },
  { href: '/cart', label: 'السلة', icon: ShoppingCart },
];

export default function BottomNav() {
  const pathname = usePathname();
  const totalItems = useCartStore((s) => s.totalItems());

  return (
    <nav
      className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-gray-200"
      style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}
    >
      <div className="flex items-center justify-around h-16">
        {navItems.map(({ href, label, icon: Icon }) => {
          const isActive = pathname === href || (href !== '/' && pathname.startsWith(href));
          const isCart = href === '/cart';

          return (
            <Link
              key={href}
              href={href}
              className={`flex flex-col items-center justify-center flex-1 h-full gap-1 transition-colors relative
                ${isActive ? 'text-primary-700' : 'text-gray-400 hover:text-gray-600'}`}
            >
              <div className="relative">
                <Icon size={22} strokeWidth={isActive ? 2.5 : 2} />
                {isCart && totalItems > 0 && (
                  <span className="absolute -top-2 -left-2 bg-red-500 text-white text-[10px] font-bold
                                   rounded-full min-w-[16px] h-4 flex items-center justify-center px-1 cart-pulse">
                    {totalItems > 99 ? '99+' : totalItems}
                  </span>
                )}
              </div>
              <span className={`text-[11px] font-semibold ${isActive ? 'text-primary-700' : 'text-gray-400'}`}>
                {label}
              </span>
              {isActive && (
                <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-8 h-0.5 bg-primary-700 rounded-full" />
              )}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}
