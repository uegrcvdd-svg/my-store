'use client';
import Image from 'next/image';
import Link from 'next/link';
import { ShoppingCart, Plus } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '../../types';
import { useCartStore } from '../../store/cartStore';

interface ProductCardProps {
  product: Product;
}

const PLACEHOLDER = '/placeholder-product.png';

export default function ProductCard({ product }: ProductCardProps) {
  const addItem = useCartStore((s) => s.addItem);
  const [added, setAdded] = useState(false);

  const imageUrl = product.primary_image || PLACEHOLDER;
  const price = parseFloat(product.price);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 800);
  };

  return (
    <Link href={`/product/${product.id}`} className="card flex flex-col group">
      {/* Product image */}
      <div className="relative aspect-square bg-gray-50 overflow-hidden">
        <Image
          src={imageUrl}
          alt={product.name_ar}
          fill
          className="object-cover group-hover:scale-105 transition-transform duration-300"
          sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
          onError={(e) => {
            (e.target as HTMLImageElement).src = PLACEHOLDER;
          }}
        />
      </div>

      {/* Card body */}
      <div className="p-3 flex flex-col gap-2 flex-1">
        <h3 className="text-sm font-semibold text-gray-900 leading-snug line-clamp-2">
          {product.name_ar}
        </h3>

        <div className="mt-auto">
          <p className="text-primary-700 font-bold text-base">
            {price > 0 ? (
              <>
                {price.toFixed(2)}{' '}
                <span className="text-xs font-normal text-gray-500">جنيه / {product.unit_ar}</span>
              </>
            ) : (
              <span className="text-gray-400 text-sm">السعر عند الطلب</span>
            )}
          </p>

          <button
            onClick={handleAdd}
            className={`mt-2 w-full flex items-center justify-center gap-1.5 py-2.5 rounded-lg
                        font-semibold text-sm transition-all duration-200
                        ${added
                          ? 'bg-green-500 text-white'
                          : 'bg-primary-700 hover:bg-primary-800 text-white active:scale-95'
                        }`}
          >
            {added ? (
              <>
                <ShoppingCart size={16} />
                <span>تمت الإضافة</span>
              </>
            ) : (
              <>
                <Plus size={16} />
                <span>إضافة</span>
              </>
            )}
          </button>
        </div>
      </div>
    </Link>
  );
}
