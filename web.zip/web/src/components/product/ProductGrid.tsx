'use client';
import { useState, useEffect, useCallback } from 'react';
import ProductCard from './ProductCard';
import LoadingSkeleton from '../ui/LoadingSkeleton';
import EmptyState from '../ui/EmptyState';
import { useInfiniteScroll } from '../../hooks/useInfiniteScroll';
import { fetchProducts } from '../../lib/api';
import type { Product } from '../../types';
import { useDebounce } from '../../hooks/useDebounce';

interface ProductGridProps {
  categorySlug?: string;
  searchQuery?: string;
  title?: string;
}

export default function ProductGrid({ categorySlug, searchQuery, title }: ProductGridProps) {
  const [products, setProducts] = useState<Product[]>([]);
  const [page, setPage] = useState(1);
  const [hasMore, setHasMore] = useState(true);
  const [loading, setLoading] = useState(false);
  const [initialLoading, setInitialLoading] = useState(true);

  const debouncedSearch = useDebounce(searchQuery, 300);

  const load = useCallback(
    async (pageNum: number, reset = false) => {
      setLoading(true);
      try {
        const res = await fetchProducts({
          page: pageNum,
          limit: 20,
          category: categorySlug,
          search: debouncedSearch || undefined,
        });

        if (res.success) {
          setProducts((prev) => (reset ? res.data : [...prev, ...res.data]));
          setHasMore(res.meta?.hasMore ?? false);
        }
      } catch {
        // silent
      } finally {
        setLoading(false);
        setInitialLoading(false);
      }
    },
    [categorySlug, debouncedSearch]
  );

  // Reset on search/category change
  useEffect(() => {
    setPage(1);
    setProducts([]);
    setHasMore(true);
    setInitialLoading(true);
    load(1, true);
  }, [categorySlug, debouncedSearch]);

  const loadMore = useCallback(() => {
    const next = page + 1;
    setPage(next);
    load(next);
  }, [page, load]);

  const sentinelRef = useInfiniteScroll(loadMore, hasMore, loading);

  if (initialLoading) {
    return (
      <div>
        {title && <h2 className="section-title">{title}</h2>}
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <LoadingSkeleton key={i} type="card" />
          ))}
        </div>
      </div>
    );
  }

  if (!loading && products.length === 0) {
    return (
      <div>
        {title && <h2 className="section-title">{title}</h2>}
        <EmptyState
          icon="search"
          title={debouncedSearch ? 'لا توجد نتائج' : 'لا توجد منتجات'}
          description={debouncedSearch ? `لم نجد نتائج لـ "${debouncedSearch}"` : 'لم يتم إضافة منتجات بعد'}
        />
      </div>
    );
  }

  return (
    <div>
      {title && <h2 className="section-title">{title}</h2>}

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {products.map((product) => (
          <ProductCard key={product.id} product={product} />
        ))}

        {loading &&
          Array.from({ length: 4 }).map((_, i) => (
            <LoadingSkeleton key={`skeleton-${i}`} type="card" />
          ))}
      </div>

      {/* Infinite scroll sentinel */}
      <div ref={sentinelRef} className="h-8" />

      {!hasMore && products.length > 0 && (
        <p className="text-center text-gray-400 text-sm py-4">لقد وصلت إلى نهاية المنتجات</p>
      )}
    </div>
  );
}
