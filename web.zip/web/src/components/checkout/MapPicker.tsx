'use client';
import { useEffect, useRef, useState } from 'react';
import { MapPin, Navigation } from 'lucide-react';

interface MapPickerProps {
  onLocationSelect: (lat: number, lng: number, address: string) => void;
  initialLat?: number;
  initialLng?: number;
}

// Qena Governorate center
const QENA_CENTER = { lat: 26.165, lng: 32.716 };

export default function MapPicker({ onLocationSelect, initialLat, initialLng }: MapPickerProps) {
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);
  const markerRef = useRef<google.maps.Marker | null>(null);
  const [loaded, setLoaded] = useState(false);
  const [locating, setLocating] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState('');

  useEffect(() => {
    const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
    if (!apiKey) {
      setLoaded(false);
      return;
    }

    if (typeof google !== 'undefined') {
      initMap();
      return;
    }

    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=geocoding`;
    script.async = true;
    script.onload = () => initMap();
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  const initMap = () => {
    if (!mapRef.current) return;

    const center = initialLat && initialLng
      ? { lat: initialLat, lng: initialLng }
      : QENA_CENTER;

    const map = new google.maps.Map(mapRef.current, {
      center,
      zoom: 14,
      disableDefaultUI: false,
      mapTypeControl: false,
      streetViewControl: false,
      fullscreenControl: false,
    });

    const marker = new google.maps.Marker({
      position: center,
      map,
      draggable: true,
      title: 'موقعك',
    });

    mapInstanceRef.current = map;
    markerRef.current = marker;
    setLoaded(true);

    // Place initial marker if coordinates provided
    if (initialLat && initialLng) {
      reverseGeocode(initialLat, initialLng);
    }

    // Click to place marker
    map.addListener('click', (e: google.maps.MapMouseEvent) => {
      if (!e.latLng) return;
      const lat = e.latLng.lat();
      const lng = e.latLng.lng();
      marker.setPosition(e.latLng);
      reverseGeocode(lat, lng);
    });

    // Drag marker
    marker.addListener('dragend', () => {
      const pos = marker.getPosition();
      if (!pos) return;
      reverseGeocode(pos.lat(), pos.lng());
    });
  };

  const reverseGeocode = (lat: number, lng: number) => {
    const geocoder = new google.maps.Geocoder();
    geocoder.geocode({ location: { lat, lng } }, (results, status) => {
      const address =
        status === 'OK' && results?.[0]
          ? results[0].formatted_address
          : `${lat.toFixed(6)}, ${lng.toFixed(6)}`;
      setSelectedAddress(address);
      onLocationSelect(lat, lng, address);
    });
  };

  const handleLocateMe = () => {
    if (!navigator.geolocation) return;
    setLocating(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        const { latitude: lat, longitude: lng } = pos.coords;
        const latLng = new google.maps.LatLng(lat, lng);
        mapInstanceRef.current?.panTo(latLng);
        mapInstanceRef.current?.setZoom(16);
        markerRef.current?.setPosition(latLng);
        reverseGeocode(lat, lng);
        setLocating(false);
      },
      () => {
        setLocating(false);
        alert('تعذر تحديد موقعك. يرجى السماح بالوصول إلى الموقع الجغرافي.');
      }
    );
  };

  return (
    <div className="space-y-2">
      <div className="relative">
        <div
          ref={mapRef}
          className="w-full h-56 rounded-xl border border-gray-200 overflow-hidden bg-gray-100"
        />
        {!loaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-gray-100 rounded-xl">
            <div className="text-center text-gray-500">
              <MapPin size={32} className="mx-auto mb-2 text-gray-400" />
              <p className="text-sm">جاري تحميل الخريطة...</p>
            </div>
          </div>
        )}
      </div>

      <button
        type="button"
        onClick={handleLocateMe}
        disabled={locating || !loaded}
        className="flex items-center gap-2 text-primary-700 text-sm font-semibold
                   hover:text-primary-800 transition-colors disabled:opacity-50"
      >
        <Navigation size={16} className={locating ? 'animate-spin' : ''} />
        {locating ? 'جاري التحديد...' : 'تحديد موقعي الحالي'}
      </button>

      {selectedAddress && (
        <p className="text-xs text-gray-500 bg-gray-50 rounded-lg p-2">
          <MapPin size={12} className="inline ml-1 text-primary-700" />
          {selectedAddress}
        </p>
      )}

      <p className="text-xs text-gray-400">اضغط على الخريطة لتحديد موقعك أو اسحب المؤشر</p>
    </div>
  );
}
