'use client';
import Image from 'next/image';
import Link from 'next/link';
import { Plus, ShoppingCart } from 'lucide-react';
import { useState } from 'react';
import type { Product } from '../../types';
import { useCartStore } from '../../store/cartStore';

interface PopularProductsProps {
  products: Product[];
}

export default function PopularProducts({ products }: PopularProductsProps) {
  if (!products.length) return null;

  return (
    <section>
      <div className="flex items-center justify-between mb-3">
        <h2 className="section-title mb-0">الأكثر مبيعاً</h2>
        <Link href="/" className="text-sm text-primary-700 font-semibold">
          عرض الكل
        </Link>
      </div>
      <div className="flex gap-3 overflow-x-auto scrollbar-hide pb-2 -mx-4 px-4">
        {products.map((product) => (
          <PopularCard key={product.id} product={product} />
        ))}
      </div>
    </section>
  );
}

function PopularCard({ product }: { product: Product }) {
  const addItem = useCartStore((s) => s.addItem);
  const [added, setAdded] = useState(false);
  const price = parseFloat(product.price);

  const handleAdd = (e: React.MouseEvent) => {
    e.preventDefault();
    addItem(product, 1);
    setAdded(true);
    setTimeout(() => setAdded(false), 800);
  };

  return (
    <Link
      href={`/product/${product.id}`}
      className="flex-shrink-0 w-36 card flex flex-col snap-start"
    >
      <div className="relative w-full aspect-square bg-gray-50 overflow-hidden">
        <Image
          src={product.primary_image || '/placeholder-product.png'}
          alt={product.name_ar}
          fill
          className="object-cover"
          sizes="144px"
        />
      </div>
      <div className="p-2 flex flex-col gap-1.5">
        <p className="text-xs font-semibold text-gray-900 line-clamp-2 leading-snug">
          {product.name_ar}
        </p>
        {price > 0 && (
          <p className="text-primary-700 text-xs font-bold">
            {price.toFixed(2)} ج / {product.unit_ar}
          </p>
        )}
        <button
          onClick={handleAdd}
          className={`w-full flex items-center justify-center gap-1 py-1.5 rounded-lg text-xs font-semibold transition-all
            ${added ? 'bg-green-500 text-white' : 'bg-primary-700 text-white active:scale-95'}`}
        >
          {added ? <ShoppingCart size={12} /> : <Plus size={12} />}
          {added ? 'تمت' : 'إضافة'}
        </button>
      </div>
    </Link>
  );
}
