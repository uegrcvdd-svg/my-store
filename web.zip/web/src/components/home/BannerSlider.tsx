'use client';
import { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import type { Banner } from '../../types';

interface BannerSliderProps {
  banners: Banner[];
}

export default function BannerSlider({ banners }: BannerSliderProps) {
  const [current, setCurrent] = useState(0);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const startTimer = () => {
    timerRef.current = setInterval(() => {
      setCurrent((prev) => (prev + 1) % banners.length);
    }, 4000);
  };

  useEffect(() => {
    if (banners.length <= 1) return;
    startTimer();
    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [banners.length]);

  const goTo = (index: number) => {
    setCurrent(index);
    if (timerRef.current) clearInterval(timerRef.current);
    startTimer();
  };

  // Touch handling for swipe
  const touchStartX = useRef(0);

  const handleTouchStart = (e: React.TouchEvent) => {
    touchStartX.current = e.touches[0].clientX;
  };

  const handleTouchEnd = (e: React.TouchEvent) => {
    const diff = touchStartX.current - e.changedTouches[0].clientX;
    if (Math.abs(diff) > 50) {
      if (diff > 0) {
        goTo((current + 1) % banners.length);
      } else {
        goTo((current - 1 + banners.length) % banners.length);
      }
    }
  };

  if (!banners.length) {
    return (
      <div className="w-full aspect-[2/1] md:aspect-[3/1] bg-gradient-to-l from-primary-700 to-primary-800 rounded-xl flex items-center justify-center mx-auto max-w-2xl">
        <div className="text-center text-white p-8">
          <p className="text-2xl font-bold mb-2">طابع</p>
          <p className="text-sm opacity-80">خضار وفاكهة طازجة من الطبيعة إلى بيتك</p>
        </div>
      </div>
    );
  }

  return (
    <div
      className="relative w-full overflow-hidden rounded-xl aspect-[2/1] md:aspect-[3/1] max-w-2xl mx-auto"
      onTouchStart={handleTouchStart}
      onTouchEnd={handleTouchEnd}
    >
      {/* Slides */}
      <div
        className="flex transition-transform duration-400 ease-in-out h-full"
        style={{ transform: `translateX(${current * 100}%)` }}
      >
        {banners.map((banner) => (
          <div key={banner.id} className="min-w-full h-full relative">
            <Image
              src={banner.image_url}
              alt={banner.title || 'طابع بانر'}
              fill
              className="object-cover"
              priority={banners.indexOf(banner) === 0}
              sizes="(max-width: 768px) 100vw, 672px"
            />
            {(banner.title || banner.subtitle) && (
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent flex flex-col justify-end p-4">
                {banner.title && (
                  <p className="text-white font-bold text-lg drop-shadow">{banner.title}</p>
                )}
                {banner.subtitle && (
                  <p className="text-white/90 text-sm drop-shadow">{banner.subtitle}</p>
                )}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Dots */}
      {banners.length > 1 && (
        <div className="absolute bottom-3 left-1/2 -translate-x-1/2 flex gap-1.5">
          {banners.map((_, i) => (
            <button
              key={i}
              onClick={() => goTo(i)}
              className={`rounded-full transition-all duration-200 ${
                i === current ? 'w-5 h-2 bg-white' : 'w-2 h-2 bg-white/50'
              }`}
              aria-label={`الشريحة ${i + 1}`}
            />
          ))}
        </div>
      )}
    </div>
  );
}
