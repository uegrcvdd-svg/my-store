'use client';
import { ShoppingCart, Search, Package, Inbox } from 'lucide-react';
import Link from 'next/link';

interface EmptyStateProps {
  icon?: 'cart' | 'search' | 'package' | 'inbox';
  title: string;
  description?: string;
  actionLabel?: string;
  actionHref?: string;
}

const icons = {
  cart: ShoppingCart,
  search: Search,
  package: Package,
  inbox: Inbox,
};

export default function EmptyState({
  icon = 'inbox',
  title,
  description,
  actionLabel,
  actionHref,
}: EmptyStateProps) {
  const Icon = icons[icon];

  return (
    <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
      <div className="w-20 h-20 bg-gray-100 rounded-full flex items-center justify-center mb-4">
        <Icon size={36} className="text-gray-400" />
      </div>
      <h3 className="text-lg font-bold text-gray-800 mb-2">{title}</h3>
      {description && <p className="text-gray-500 text-sm mb-6 max-w-xs">{description}</p>}
      {actionLabel && actionHref && (
        <Link
          href={actionHref}
          className="bg-primary-700 text-white font-semibold px-6 py-3 rounded-lg hover:bg-primary-800 transition-colors"
        >
          {actionLabel}
        </Link>
      )}
    </div>
  );
}
