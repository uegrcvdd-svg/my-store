'use client';

interface LoadingSkeletonProps {
  type?: 'card' | 'banner' | 'text' | 'row';
}

export default function LoadingSkeleton({ type = 'card' }: LoadingSkeletonProps) {
  if (type === 'banner') {
    return (
      <div className="w-full aspect-[2/1] md:aspect-[3/1] rounded-xl skeleton max-w-2xl mx-auto" />
    );
  }

  if (type === 'text') {
    return (
      <div className="space-y-2">
        <div className="h-4 skeleton rounded w-3/4" />
        <div className="h-4 skeleton rounded w-1/2" />
      </div>
    );
  }

  if (type === 'row') {
    return (
      <div className="flex items-center gap-3 p-3 bg-white rounded-lg">
        <div className="w-16 h-16 skeleton rounded-lg flex-shrink-0" />
        <div className="flex-1 space-y-2">
          <div className="h-4 skeleton rounded w-2/3" />
          <div className="h-3 skeleton rounded w-1/3" />
        </div>
      </div>
    );
  }

  // Default: card
  return (
    <div className="bg-white rounded-card overflow-hidden shadow-card">
      <div className="aspect-square skeleton" />
      <div className="p-3 space-y-2">
        <div className="h-4 skeleton rounded w-4/5" />
        <div className="h-3 skeleton rounded w-2/3" />
        <div className="h-9 skeleton rounded-lg mt-2" />
      </div>
    </div>
  );
}
