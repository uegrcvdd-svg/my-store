export function buildWhatsAppLink(message?: string): string {
  const number = process.env.NEXT_PUBLIC_WHATSAPP_NUMBER || '201008721996';
  const defaultMessage = 'مرحباً طابع، أريد الاستفسار عن طلبي.';
  const text = encodeURIComponent(message || defaultMessage);
  return `https://wa.me/${number}?text=${text}`;
}
