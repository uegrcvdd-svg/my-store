import axios from 'axios';
import type { ApiResponse, Product, Banner, Category, StoreSettings, CreateOrderInput } from '../types';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
  withCredentials: true,
  timeout: 10000,
});

// Products
export async function fetchProducts(params: {
  page?: number;
  limit?: number;
  category?: string;
  search?: string;
}): Promise<ApiResponse<Product[]>> {
  const { data } = await api.get('/products', { params });
  return data;
}

export async function fetchPopularProducts(): Promise<ApiResponse<Product[]>> {
  const { data } = await api.get('/products/popular');
  return data;
}

export async function fetchProduct(id: string): Promise<ApiResponse<Product>> {
  const { data } = await api.get(`/products/${id}`);
  return data;
}

export async function searchProducts(q: string, page = 1, limit = 20): Promise<ApiResponse<Product[]>> {
  const { data } = await api.get('/products/search', { params: { q, page, limit } });
  return data;
}

// Categories
export async function fetchCategories(): Promise<ApiResponse<Category[]>> {
  const { data } = await api.get('/categories');
  return data;
}

// Banners
export async function fetchBanners(): Promise<ApiResponse<Banner[]>> {
  const { data } = await api.get('/banners');
  return data;
}

// Settings
export async function fetchPublicSettings(): Promise<ApiResponse<StoreSettings>> {
  const { data } = await api.get('/settings/public');
  return data;
}

// Orders
export async function submitOrder(input: CreateOrderInput): Promise<ApiResponse<{ id: string; order_number: number; grand_total: string }>> {
  const { data } = await api.post('/orders', input);
  return data;
}

export default api;
