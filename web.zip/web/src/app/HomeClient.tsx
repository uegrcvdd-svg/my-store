'use client';
import { useState } from 'react';
import Header from '../components/layout/Header';
import BottomNav from '../components/layout/BottomNav';
import WhatsAppButton from '../components/layout/WhatsAppButton';
import BannerSlider from '../components/home/BannerSlider';
import PopularProducts from '../components/home/PopularProducts';
import ProductGrid from '../components/product/ProductGrid';
import type { Banner, Product } from '../types';

interface HomeClientProps {
  banners: Banner[];
  popularProducts: Product[];
}

export default function HomeClient({ banners, popularProducts }: HomeClientProps) {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      <Header onSearch={setSearchQuery} showSearch />

      <main className="page-padding py-4 max-w-2xl mx-auto space-y-6">
        {/* Banner Slider */}
        {!searchQuery && <BannerSlider banners={banners} />}

        {/* Popular Products */}
        {!searchQuery && popularProducts.length > 0 && (
          <PopularProducts products={popularProducts} />
        )}

        {/* All Products / Search Results */}
        <section>
          <ProductGrid
            searchQuery={searchQuery}
            title={searchQuery ? `نتائج: "${searchQuery}"` : 'جميع المنتجات'}
          />
        </section>
      </main>

      {/* WhatsApp floating button */}
      <WhatsAppButton variant="floating" />

      {/* Bottom Navigation */}
      <BottomNav />
    </div>
  );
}
