import { Suspense } from 'react';
import { fetchBanners, fetchPopularProducts } from '../lib/api';
import HomeClient from './HomeClient';

export const revalidate = 60; // ISR: revalidate every 60 seconds

export default async function HomePage() {
  // Fetch initial data server-side
  const [bannersRes, popularRes] = await Promise.allSettled([
    fetchBanners(),
    fetchPopularProducts(),
  ]);

  const banners = bannersRes.status === 'fulfilled' ? bannersRes.value.data : [];
  const popular = popularRes.status === 'fulfilled' ? popularRes.value.data : [];

  return <HomeClient banners={banners} popularProducts={popular} />;
}
