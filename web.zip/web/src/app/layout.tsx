import type { Metadata, Viewport } from 'next';
import { Cairo } from 'next/font/google';
import './globals.css';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['400', '600', '700', '800'],
  display: 'swap',
  variable: '--font-cairo',
});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export const metadata: Metadata = {
  title: 'طابع | خضار وفاكهة طازجة',
  description: 'تسوق أفضل الخضروات والفاكهة الطازجة في قنا. توصيل سريع لباب بيتك.',
  keywords: ['خضار', 'فاكهة', 'طازج', 'قنا', 'طابع', 'توصيل'],
  openGraph: {
    title: 'طابع | خضار وفاكهة طازجة',
    description: 'تسوق أفضل الخضروات والفاكهة الطازجة في قنا',
    locale: 'ar_EG',
    type: 'website',
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={cairo.variable}>
      <body className="font-cairo bg-gray-50 min-h-screen">
        {children}
      </body>
    </html>
  );
}
