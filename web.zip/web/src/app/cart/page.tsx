'use client';
import Image from 'next/image';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Trash2, Minus, Plus, ShoppingCart } from 'lucide-react';
import { useCartStore } from '../../store/cartStore';
import BottomNav from '../../components/layout/BottomNav';
import Header from '../../components/layout/Header';
import EmptyState from '../../components/ui/EmptyState';

export default function CartPage() {
  const { items, removeItem, updateQuantity, grandTotal } = useCartStore();
  const router = useRouter();

  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      <Header showSearch={false} />

      <main className="page-padding py-4 max-w-2xl mx-auto">
        <div className="flex items-center gap-2 mb-4">
          <ShoppingCart size={22} className="text-gray-700" />
          <h1 className="text-xl font-bold text-gray-900">السلة</h1>
          {items.length > 0 && (
            <span className="bg-primary-700 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center font-bold">
              {items.length}
            </span>
          )}
        </div>

        {items.length === 0 ? (
          <EmptyState
            icon="cart"
            title="سلتك فارغة"
            description="أضف منتجات من الصفحة الرئيسية"
            actionLabel="تسوق الآن"
            actionHref="/"
          />
        ) : (
          <>
            {/* Cart items */}
            <div className="space-y-3 mb-6">
              {items.map(({ product, quantity }) => {
                const price = parseFloat(product.price);
                const total = price * quantity;

                return (
                  <div key={product.id} className="card p-3 flex gap-3">
                    {/* Image */}
                    <Link href={`/product/${product.id}`} className="flex-shrink-0">
                      <div className="relative w-20 h-20 rounded-lg overflow-hidden bg-gray-50">
                        <Image
                          src={product.primary_image || '/placeholder-product.png'}
                          alt={product.name_ar}
                          fill
                          className="object-cover"
                          sizes="80px"
                        />
                      </div>
                    </Link>

                    {/* Details */}
                    <div className="flex-1 min-w-0">
                      <Link href={`/product/${product.id}`}>
                        <h3 className="font-semibold text-gray-900 text-sm leading-snug line-clamp-2">
                          {product.name_ar}
                        </h3>
                      </Link>
                      {price > 0 && (
                        <p className="text-gray-500 text-xs mt-0.5">
                          {price.toFixed(2)} جنيه / {product.unit_ar}
                        </p>
                      )}

                      <div className="flex items-center justify-between mt-2">
                        {/* Quantity controls */}
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(product.id, quantity - 1)}
                            className="w-7 h-7 rounded-full border border-gray-300 flex items-center justify-center
                                       hover:border-primary-700 active:scale-90 transition-all"
                          >
                            <Minus size={12} />
                          </button>
                          <span className="text-sm font-bold w-6 text-center">{quantity}</span>
                          <button
                            onClick={() => updateQuantity(product.id, quantity + 1)}
                            className="w-7 h-7 rounded-full bg-primary-700 flex items-center justify-center
                                       hover:bg-primary-800 active:scale-90 transition-all"
                          >
                            <Plus size={12} className="text-white" />
                          </button>
                        </div>

                        <div className="flex items-center gap-3">
                          {/* Total */}
                          {price > 0 && (
                            <span className="text-primary-700 font-bold text-sm">
                              {total.toFixed(2)} ج
                            </span>
                          )}
                          {/* Delete */}
                          <button
                            onClick={() => removeItem(product.id)}
                            className="text-red-400 hover:text-red-600 transition-colors active:scale-90"
                          >
                            <Trash2 size={17} />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Order summary */}
            <div className="card p-4 mb-4">
              <h3 className="font-bold text-gray-900 mb-3">ملخص الطلب</h3>
              <div className="space-y-2 text-sm">
                {items.map(({ product, quantity }) => (
                  <div key={product.id} className="flex justify-between text-gray-600">
                    <span>{product.name_ar} × {quantity}</span>
                    {parseFloat(product.price) > 0 && (
                      <span>{(parseFloat(product.price) * quantity).toFixed(2)} ج</span>
                    )}
                  </div>
                ))}
                <div className="border-t pt-2 flex justify-between font-bold text-gray-900 text-base">
                  <span>الإجمالي</span>
                  <span className="text-primary-700">{grandTotal().toFixed(2)} جنيه</span>
                </div>
              </div>
            </div>

            {/* Checkout button */}
            <button
              onClick={() => router.push('/checkout')}
              className="btn-primary text-lg py-4"
            >
              إتمام الطلب
            </button>
          </>
        )}
      </main>

      <BottomNav />
    </div>
  );
}
