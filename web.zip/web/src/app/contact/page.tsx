'use client';
import { Phone, Clock, MapPin } from 'lucide-react';
import Header from '../../components/layout/Header';
import BottomNav from '../../components/layout/BottomNav';
import WhatsAppButton from '../../components/layout/WhatsAppButton';

export default function ContactPage() {
  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      <Header showSearch={false} />

      <main className="page-padding py-6 max-w-2xl mx-auto space-y-5">
        <h1 className="text-2xl font-bold text-gray-900">تواصل معنا</h1>

        {/* WhatsApp + Call */}
        <div className="card p-5 space-y-3">
          <h2 className="font-bold text-gray-900 mb-3">تواصل معنا</h2>
          <WhatsAppButton variant="inline" label="تحدث معنا على واتساب" />
          <a
            href="tel:+201008721996"
            className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl border-2 border-primary-700 text-primary-700 font-semibold text-sm"
          >
            <Phone size={18} />
            اتصل بنا — +20 10 08721996
          </a>
          <p className="text-xs text-gray-400 text-center">
            متاحون يومياً لخدمتك
          </p>
        </div>

        {/* Contact info */}
        <div className="card p-5 space-y-4">
          <h2 className="font-bold text-gray-900">معلومات التواصل</h2>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center">
              <Phone size={18} className="text-primary-700" />
            </div>
            <div>
              <p className="text-xs text-gray-500">الهاتف</p>
              <p className="font-semibold text-gray-900">+20 10 08721996</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center">
              <Clock size={18} className="text-primary-700" />
            </div>
            <div>
              <p className="text-xs text-gray-500">ساعات العمل</p>
              <p className="font-semibold text-gray-900">يومياً 8 صباحاً – 10 مساءً</p>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-primary-50 rounded-full flex items-center justify-center">
              <MapPin size={18} className="text-primary-700" />
            </div>
            <div>
              <p className="text-xs text-gray-500">منطقة التوصيل</p>
              <p className="font-semibold text-gray-900">محافظة قنا – مصر</p>
            </div>
          </div>
        </div>

        {/* About */}
        <div className="card p-5">
          <h2 className="font-bold text-gray-900 mb-2">عن طابع</h2>
          <p className="text-gray-600 text-sm leading-relaxed">
            طابع متجرك لأفضل الخضروات والفاكهة الطازجة في محافظة قنا.
            نوصل طلبك مباشرة لباب بيتك بأعلى جودة وأسرع وقت.
          </p>
        </div>
      </main>

      <WhatsAppButton variant="floating" />
      <BottomNav />
    </div>
  );
}
