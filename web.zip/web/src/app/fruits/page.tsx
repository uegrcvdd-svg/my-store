'use client';
import { useState } from 'react';
import Header from '../../components/layout/Header';
import BottomNav from '../../components/layout/BottomNav';
import WhatsAppButton from '../../components/layout/WhatsAppButton';
import ProductGrid from '../../components/product/ProductGrid';

export default function FruitsPage() {
  const [searchQuery, setSearchQuery] = useState('');

  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      <Header onSearch={setSearchQuery} showSearch />

      <main className="page-padding py-4 max-w-2xl mx-auto">
        {/* Category header */}
        <div className="flex items-center gap-3 mb-4">
          <span className="text-3xl">🍎</span>
          <div>
            <h1 className="text-2xl font-bold text-gray-900">الفاكهة</h1>
            <p className="text-sm text-gray-500">فاكهة طازجة من أجود المصادر</p>
          </div>
        </div>

        <ProductGrid
          categorySlug="fruits"
          searchQuery={searchQuery}
          title={searchQuery ? `نتائج في الفاكهة: "${searchQuery}"` : undefined}
        />
      </main>

      <WhatsAppButton variant="floating" />
      <BottomNav />
    </div>
  );
}
