'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { ChevronLeft, User, Phone, MapPin, MessageSquare, Landmark } from 'lucide-react';
import { useCartStore } from '../../store/cartStore';
import { submitOrder } from '../../lib/api';
import MapPicker from '../../components/checkout/MapPicker';
import BottomNav from '../../components/layout/BottomNav';
import Header from '../../components/layout/Header';
import Toast from '../../components/ui/Toast';

interface FormData {
  customer_name: string;
  phone_primary: string;
  phone_secondary: string;
  address_text: string;
  landmark: string;
  notes: string;
  gps_lat?: number;
  gps_lng?: number;
}

interface FormErrors {
  [key: string]: string;
}

const EGYPTIAN_PHONE_REGEX = /^01[0125][0-9]{8}$/;

export default function CheckoutPage() {
  const router = useRouter();
  const { items, grandTotal, clearCart } = useCartStore();
  const [submitting, setSubmitting] = useState(false);
  const [toast, setToast] = useState<{ message: string; type: 'success' | 'error' } | null>(null);

  const [form, setForm] = useState<FormData>({
    customer_name: '',
    phone_primary: '',
    phone_secondary: '',
    address_text: '',
    landmark: '',
    notes: '',
  });

  const [errors, setErrors] = useState<FormErrors>({});

  if (items.length === 0) {
    router.replace('/cart');
    return null;
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const handleLocationSelect = (lat: number, lng: number, address: string) => {
    setForm((prev) => ({ ...prev, gps_lat: lat, gps_lng: lng, address_text: address }));
    if (errors.address_text) setErrors((prev) => ({ ...prev, address_text: '' }));
  };

  const validate = (): boolean => {
    const newErrors: FormErrors = {};

    if (!form.customer_name.trim() || form.customer_name.trim().length < 2) {
      newErrors.customer_name = 'الاسم يجب أن يكون حرفين على الأقل';
    }

    if (!EGYPTIAN_PHONE_REGEX.test(form.phone_primary.replace(/\s/g, ''))) {
      newErrors.phone_primary = 'رقم الهاتف غير صحيح (مثال: 01012345678)';
    }

    if (form.phone_secondary && !EGYPTIAN_PHONE_REGEX.test(form.phone_secondary.replace(/\s/g, ''))) {
      newErrors.phone_secondary = 'رقم الهاتف الإضافي غير صحيح';
    }

    if (!form.address_text.trim() || form.address_text.trim().length < 5) {
      newErrors.address_text = 'يرجى تحديد موقعك على الخريطة أو كتابة العنوان';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    setSubmitting(true);

    try {
      const orderItems = items.map(({ product, quantity }) => ({
        product_id: product.id,
        quantity,
      }));

      const res = await submitOrder({
        customer_name: form.customer_name.trim(),
        phone_primary: form.phone_primary.replace(/\s/g, ''),
        phone_secondary: form.phone_secondary ? form.phone_secondary.replace(/\s/g, '') : undefined,
        address_text: form.address_text.trim(),
        gps_lat: form.gps_lat,
        gps_lng: form.gps_lng,
        landmark: form.landmark.trim() || undefined,
        notes: form.notes.trim() || undefined,
        items: orderItems,
      });

      if (res.success) {
        clearCart();
        router.push(`/order-success?order=${res.data.order_number}&id=${res.data.id}`);
      } else {
        setToast({ message: 'حدث خطأ في إرسال الطلب. حاول مرة أخرى.', type: 'error' });
      }
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || 'حدث خطأ. يرجى المحاولة مرة أخرى.';
      setToast({ message: msg, type: 'error' });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      {toast && (
        <Toast message={toast.message} type={toast.type} onClose={() => setToast(null)} />
      )}

      <Header showSearch={false} />

      <main className="page-padding py-4 max-w-2xl mx-auto pb-32">
        <div className="flex items-center gap-2 mb-5">
          <button onClick={() => router.back()}>
            <ChevronLeft size={22} className="text-gray-600" />
          </button>
          <h1 className="text-xl font-bold text-gray-900">إتمام الطلب</h1>
        </div>

        {/* Order summary card */}
        <div className="card p-4 mb-5">
          <h3 className="font-bold text-gray-700 mb-3 text-sm">ملخص طلبك ({items.length} منتج)</h3>
          <div className="space-y-1.5 text-sm text-gray-600 mb-3">
            {items.map(({ product, quantity }) => (
              <div key={product.id} className="flex justify-between">
                <span>{product.name_ar} × {quantity} {product.unit_ar}</span>
                {parseFloat(product.price) > 0 && (
                  <span className="font-medium">
                    {(parseFloat(product.price) * quantity).toFixed(2)} ج
                  </span>
                )}
              </div>
            ))}
          </div>
          {grandTotal() > 0 && (
            <div className="border-t pt-2 flex justify-between font-bold text-base">
              <span>الإجمالي</span>
              <span className="text-primary-700">{grandTotal().toFixed(2)} جنيه</span>
            </div>
          )}
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <User size={14} className="inline ml-1" />
              الاسم الكامل <span className="text-red-500">*</span>
            </label>
            <input
              type="text"
              name="customer_name"
              value={form.customer_name}
              onChange={handleChange}
              placeholder="أدخل اسمك الكامل"
              className={`input ${errors.customer_name ? 'border-red-400 ring-1 ring-red-400' : ''}`}
              autoComplete="name"
            />
            {errors.customer_name && (
              <p className="text-red-500 text-xs mt-1">{errors.customer_name}</p>
            )}
          </div>

          {/* Phone Primary */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <Phone size={14} className="inline ml-1" />
              رقم الهاتف <span className="text-red-500">*</span>
            </label>
            <input
              type="tel"
              name="phone_primary"
              value={form.phone_primary}
              onChange={handleChange}
              placeholder="01012345678"
              className={`input ${errors.phone_primary ? 'border-red-400 ring-1 ring-red-400' : ''}`}
              autoComplete="tel"
              inputMode="numeric"
              dir="ltr"
            />
            {errors.phone_primary && (
              <p className="text-red-500 text-xs mt-1">{errors.phone_primary}</p>
            )}
          </div>

          {/* Phone Secondary */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <Phone size={14} className="inline ml-1" />
              رقم هاتف إضافي
              <span className="text-gray-400 text-xs font-normal mr-1">(اختياري)</span>
            </label>
            <input
              type="tel"
              name="phone_secondary"
              value={form.phone_secondary}
              onChange={handleChange}
              placeholder="01012345678"
              className={`input ${errors.phone_secondary ? 'border-red-400 ring-1 ring-red-400' : ''}`}
              inputMode="numeric"
              dir="ltr"
            />
            {errors.phone_secondary && (
              <p className="text-red-500 text-xs mt-1">{errors.phone_secondary}</p>
            )}
          </div>

          {/* Location */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <MapPin size={14} className="inline ml-1" />
              الموقع على الخريطة <span className="text-red-500">*</span>
            </label>
            <MapPicker
              onLocationSelect={handleLocationSelect}
              initialLat={form.gps_lat}
              initialLng={form.gps_lng}
            />
            {/* Manual address input as fallback */}
            <input
              type="text"
              name="address_text"
              value={form.address_text}
              onChange={handleChange}
              placeholder="أو اكتب عنوانك يدوياً"
              className={`input mt-2 ${errors.address_text ? 'border-red-400 ring-1 ring-red-400' : ''}`}
            />
            {errors.address_text && (
              <p className="text-red-500 text-xs mt-1">{errors.address_text}</p>
            )}
          </div>

          {/* Landmark */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <Landmark size={14} className="inline ml-1" />
              علامة مميزة للمكان
              <span className="text-gray-400 text-xs font-normal mr-1">(اختياري)</span>
            </label>
            <input
              type="text"
              name="landmark"
              value={form.landmark}
              onChange={handleChange}
              placeholder="مثال: أمام المسجد، بجوار البنك"
              className="input"
            />
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-semibold text-gray-700 mb-1.5">
              <MessageSquare size={14} className="inline ml-1" />
              ملاحظات الطلب
              <span className="text-gray-400 text-xs font-normal mr-1">(اختياري)</span>
            </label>
            <textarea
              name="notes"
              value={form.notes}
              onChange={handleChange}
              placeholder="أي ملاحظات أو تعليمات خاصة للمندوب..."
              rows={3}
              className="input resize-none"
            />
          </div>
        </form>
      </main>

      {/* Sticky submit button */}
      <div
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 z-40"
        style={{ paddingBottom: 'calc(64px + env(safe-area-inset-bottom) + 8px)' }}
      >
        <div className="max-w-2xl mx-auto">
          <button
            onClick={handleSubmit}
            disabled={submitting}
            className="btn-primary text-base py-4 flex items-center justify-center gap-2"
          >
            {submitting ? (
              <>
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                جاري إرسال الطلب...
              </>
            ) : (
              'تأكيد الطلب ✓'
            )}
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
