'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Image from 'next/image';
import { ArrowRight, Heart, Minus, Plus, ShoppingCart, ChevronLeft } from 'lucide-react';
import { fetchProduct } from '../../../lib/api';
import { useCartStore } from '../../../store/cartStore';
import type { Product } from '../../../types';
import BottomNav from '../../../components/layout/BottomNav';
import LoadingSkeleton from '../../../components/ui/LoadingSkeleton';
import Toast from '../../../components/ui/Toast';

const PLACEHOLDER = '/placeholder-product.png';

export default function ProductDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const addItem = useCartStore((s) => s.addItem);

  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [toast, setToast] = useState<string | null>(null);

  useEffect(() => {
    if (!id) return;
    fetchProduct(id)
      .then((res) => {
        if (res.success) setProduct(res.data);
      })
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 bottom-nav-safe">
        <div className="max-w-2xl mx-auto">
          <div className="aspect-square skeleton" />
          <div className="p-4 space-y-4">
            <LoadingSkeleton type="text" />
            <div className="h-12 skeleton rounded-lg" />
            <div className="h-14 skeleton rounded-lg" />
          </div>
        </div>
        <BottomNav />
      </div>
    );
  }

  if (!product) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center bottom-nav-safe">
        <div className="text-center">
          <p className="text-xl font-bold text-gray-700 mb-4">المنتج غير موجود</p>
          <button
            onClick={() => router.back()}
            className="btn-primary max-w-xs"
          >
            العودة
          </button>
        </div>
        <BottomNav />
      </div>
    );
  }

  const images = product.images?.length
    ? product.images.sort((a, b) => (b.is_primary ? 1 : 0) - (a.is_primary ? 1 : 0))
    : [];
  const currentImageUrl = images[selectedImage]?.image_url || PLACEHOLDER;
  const price = parseFloat(product.price);
  const totalPrice = price * quantity;

  const handleAddToCart = () => {
    addItem(product, quantity);
    setToast(`تمت إضافة ${product.name_ar} إلى السلة`);
  };

  return (
    <div className="min-h-screen bg-gray-50 bottom-nav-safe">
      {/* Toast */}
      {toast && <Toast message={toast} type="success" onClose={() => setToast(null)} />}

      <div className="max-w-2xl mx-auto">
        {/* Back button */}
        <div className="absolute top-4 right-4 z-10">
          <button
            onClick={() => router.back()}
            className="w-10 h-10 bg-white/90 backdrop-blur rounded-full flex items-center justify-center shadow-md"
          >
            <ChevronLeft size={20} className="text-gray-700" />
          </button>
        </div>

        {/* Main Image */}
        <div className="relative aspect-square bg-white">
          <Image
            src={currentImageUrl}
            alt={product.name_ar}
            fill
            className="object-contain p-4"
            priority
            sizes="(max-width: 768px) 100vw, 672px"
          />
        </div>

        {/* Thumbnail strip */}
        {images.length > 1 && (
          <div className="flex gap-2 px-4 py-3 bg-white overflow-x-auto scrollbar-hide border-t border-gray-100">
            {images.map((img, idx) => (
              <button
                key={img.id}
                onClick={() => setSelectedImage(idx)}
                className={`flex-shrink-0 w-16 h-16 rounded-lg overflow-hidden border-2 transition-all
                  ${idx === selectedImage ? 'border-primary-700' : 'border-gray-200'}`}
              >
                <Image
                  src={img.image_url}
                  alt={`${product.name_ar} ${idx + 1}`}
                  width={64}
                  height={64}
                  className="object-cover w-full h-full"
                />
              </button>
            ))}
          </div>
        )}

        {/* Product Info */}
        <div className="bg-white px-4 py-5 mt-2">
          {/* Category badge */}
          <span className="inline-block bg-primary-50 text-primary-700 text-xs font-semibold px-3 py-1 rounded-full mb-3">
            {product.category_name_ar}
          </span>

          <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name_ar}</h1>

          {/* Price */}
          <div className="mb-4">
            {price > 0 ? (
              <p className="text-primary-700 text-xl font-bold">
                {price.toFixed(2)}{' '}
                <span className="text-base font-normal text-gray-500">جنيه / {product.unit_ar}</span>
              </p>
            ) : (
              <p className="text-gray-400 text-base">السعر عند الطلب</p>
            )}
          </div>

          {/* Description */}
          {product.description && (
            <div className="mb-5">
              <h3 className="font-semibold text-gray-700 mb-1">الوصف</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{product.description}</p>
            </div>
          )}

          {/* Quantity selector */}
          <div className="mb-5">
            <h3 className="font-semibold text-gray-700 mb-3">الكمية ({product.unit_ar})</h3>
            <div className="flex items-center gap-4">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-12 h-12 rounded-full border-2 border-gray-200 flex items-center justify-center
                           hover:border-primary-700 transition-colors active:scale-95"
              >
                <Minus size={20} className="text-gray-600" />
              </button>
              <span className="text-2xl font-bold text-gray-900 min-w-[3rem] text-center">
                {quantity}
              </span>
              <button
                onClick={() => setQuantity((q) => Math.min(99, q + 1))}
                className="w-12 h-12 rounded-full bg-primary-700 flex items-center justify-center
                           hover:bg-primary-800 transition-colors active:scale-95"
              >
                <Plus size={20} className="text-white" />
              </button>
            </div>
          </div>

          {/* Total */}
          {price > 0 && (
            <div className="flex items-center justify-between bg-gray-50 rounded-lg px-4 py-3 mb-5">
              <span className="text-gray-600 font-medium">الإجمالي</span>
              <span className="text-primary-700 font-bold text-lg">
                {totalPrice.toFixed(2)} جنيه
              </span>
            </div>
          )}
        </div>
      </div>

      {/* Sticky add to cart button */}
      <div
        className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 px-4 py-3 z-40"
        style={{ paddingBottom: 'calc(64px + env(safe-area-inset-bottom) + 8px)' }}
      >
        <div className="max-w-2xl mx-auto">
          <button
            onClick={handleAddToCart}
            className="btn-primary flex items-center justify-center gap-2"
          >
            <ShoppingCart size={20} />
            <span>إضافة للسلة</span>
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
