'use client';
import { useSearchParams } from 'next/navigation';
import { Suspense, useEffect, useState, useRef } from 'react';
import Link from 'next/link';
import { CheckCircle, Home, Phone } from 'lucide-react';
import WhatsAppButton from '../../components/layout/WhatsAppButton';
import BottomNav from '../../components/layout/BottomNav';

const PHONE_NUMBER = '+201008721996';
const PHONE_DISPLAY = '+20 10 08721996';

function OrderSuccessContent() {
  const params = useSearchParams();
  const orderNumber = params.get('order');
  const orderId = params.get('id');
  const [status, setStatus] = useState<string | null>(null);
  const [preparedNotified, setPreparedNotified] = useState(false);
  const intervalRef = useRef<NodeJS.Timeout | null>(null);

  // Poll order status to detect "prepared" — in-app notification
  useEffect(() => {
    if (!orderId) return;
    const apiUrl = process.env.NEXT_PUBLIC_API_URL;
    if (!apiUrl) return;

    const poll = async () => {
      try {
        const res = await fetch(`${apiUrl}/orders/${orderId}/status`);
        if (!res.ok) return;
        const data = await res.json();
        const s = data?.data?.status;
        if (s) setStatus(s);
        if (s === 'prepared' && !preparedNotified) {
          setPreparedNotified(true);
          if (intervalRef.current) clearInterval(intervalRef.current);
        }
      } catch (_) { /* silent */ }
    };

    poll();
    intervalRef.current = setInterval(poll, 15000); // poll every 15s
    return () => { if (intervalRef.current) clearInterval(intervalRef.current); };
  }, [orderId, preparedNotified]);

  const statusLabel: Record<string, string> = {
    new: 'جديد',
    confirmed: 'تم التأكيد',
    prepared: 'تم التجهيز بنجاح ✓',
    in_delivery: 'قيد التوصيل',
    delivered: 'تم التوصيل',
    cancelled: 'ملغي',
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col items-center justify-center bottom-nav-safe px-6">
      <div className="text-center max-w-sm w-full">

        {/* Prepared notification banner */}
        {preparedNotified && (
          <div className="bg-purple-600 text-white rounded-xl px-4 py-3 mb-5 animate-pulse shadow-lg">
            <p className="font-bold text-lg">🎉 تم تجهيز طلبك بنجاح!</p>
            <p className="text-sm mt-1 opacity-90">سيصلك المندوب قريباً</p>
          </div>
        )}

        {/* Animated checkmark */}
        <div className="w-24 h-24 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-6 animate-bounce">
          <CheckCircle size={52} className="text-green-600" strokeWidth={1.5} />
        </div>

        <h1 className="text-2xl font-bold text-gray-900 mb-3">تم استلام طلبك بنجاح!</h1>

        {orderNumber && (
          <div className="bg-primary-50 rounded-xl px-4 py-3 mb-4">
            <p className="text-gray-500 text-sm">رقم طلبك</p>
            <p className="text-primary-700 font-bold text-2xl">#{orderNumber}</p>
          </div>
        )}

        {/* Live order status */}
        {status && (
          <div className="bg-white border border-gray-200 rounded-xl px-4 py-3 mb-4 shadow-sm">
            <p className="text-gray-500 text-xs mb-1">حالة الطلب</p>
            <p className={`font-bold text-sm ${status === 'prepared' ? 'text-purple-700' : status === 'delivered' ? 'text-green-700' : 'text-gray-800'}`}>
              {statusLabel[status] ?? status}
            </p>
          </div>
        )}

        <p className="text-gray-600 mb-8 leading-relaxed">
          شكراً لاختيارك <span className="font-bold text-primary-700">طابع</span>!
          <br />
          سيتواصل معك المندوب في أقرب وقت ممكن لتوصيل طلبك.
        </p>

        <div className="space-y-3 w-full">
          <Link href="/" className="btn-primary flex items-center justify-center gap-2 no-underline">
            <Home size={18} />
            العودة للرئيسية
          </Link>

          <WhatsAppButton variant="inline" label="تواصل معنا عبر واتساب" />

          <a
            href={`tel:${PHONE_NUMBER}`}
            className="flex items-center justify-center gap-2 w-full py-3 px-4 rounded-xl border-2 border-primary-700 text-primary-700 font-semibold text-sm"
          >
            <Phone size={18} />
            اتصل بنا — {PHONE_DISPLAY}
          </a>
        </div>

        <div className="mt-8 flex justify-center gap-2 text-2xl">
          🥦 🍎 🥕 🍋 🍅
        </div>
      </div>

      <BottomNav />
    </div>
  );
}

export default function OrderSuccessPage() {
  return (
    <Suspense fallback={
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-primary-700 border-t-transparent rounded-full animate-spin" />
      </div>
    }>
      <OrderSuccessContent />
    </Suspense>
  );
}
