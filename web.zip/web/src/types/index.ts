export interface Product {
  id: string;
  category_id: string;
  category_name_ar: string;
  category_slug: string;
  name: string;
  name_ar: string;
  description: string | null;
  unit: string;
  unit_ar: string;
  price: string;
  display_order: number;
  is_visible: boolean;
  is_popular: boolean;
  images: ProductImage[];
  primary_image: string | null;
}

export interface ProductImage {
  id: string;
  image_url: string;
  is_primary: boolean;
  sort_order: number;
}

export interface Category {
  id: string;
  name: string;
  name_ar: string;
  slug: string;
  product_count: number;
}

export interface Banner {
  id: string;
  image_url: string;
  title: string | null;
  subtitle: string | null;
  link_url: string | null;
  display_order: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface OrderItem {
  product_id: string;
  quantity: number;
}

export interface CreateOrderInput {
  customer_name: string;
  phone_primary: string;
  phone_secondary?: string;
  address_text: string;
  gps_lat?: number;
  gps_lng?: number;
  landmark?: string;
  notes?: string;
  items: OrderItem[];
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  meta?: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
    totalPages: number;
  };
  error?: {
    code: string;
    message: string;
    details?: unknown;
  };
}

export interface StoreSettings {
  store_name: string;
  whatsapp_number: string;
  working_hours: string;
  delivery_area: string;
  phone_primary: string;
  facebook_url: string;
  instagram_url: string;
}
