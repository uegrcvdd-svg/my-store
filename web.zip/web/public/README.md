# Public Assets

Place the following files in this directory:

- `logo.png` — Official Tayea logo (exact, unmodified)
- `placeholder-product.png` — Fallback image for products without photos

The logo.png file must be the official Tayea logo uploaded by the client.
Do NOT use AI-generated or modified versions.
