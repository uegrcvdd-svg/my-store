import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1B6B35',
          50: '#E8F5E9',
          100: '#C8E6C9',
          200: '#A5D6A7',
          400: '#4CAF50',
          600: '#2E7D32',
          700: '#1B6B35',
          800: '#1A5C2A',
          900: '#133D1C',
        },
        brand: {
          red: '#CC0000',
          gold: '#F5A800',
        },
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif'],
      },
      borderRadius: {
        card: '12px',
      },
      boxShadow: {
        card: '0 2px 8px rgba(0,0,0,0.08)',
        btn: '0 2px 4px rgba(27,107,53,0.3)',
      },
    },
  },
  plugins: [],
};

export default config;
