import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: '#1B6B35',
          50: '#E8F5E9',
          100: '#C8E6C9',
          600: '#2E7D32',
          700: '#1B6B35',
          800: '#1A5C2A',
        },
        sidebar: '#0F3D1F',
      },
      fontFamily: {
        cairo: ['Cairo', 'sans-serif'],
      },
    },
  },
  plugins: [],
};

export default config;
