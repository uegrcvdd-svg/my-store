import type { OrderStatus } from '../../types';
import { STATUS_LABELS, STATUS_COLORS } from '../../types';

interface StatusBadgeProps {
  status: OrderStatus | string;
}

export default function StatusBadge({ status }: StatusBadgeProps) {
  const label = STATUS_LABELS[status as OrderStatus] || status;
  const color = STATUS_COLORS[status as OrderStatus] || 'bg-gray-100 text-gray-600';

  return (
    <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold ${color}`}>
      <span className="w-1.5 h-1.5 rounded-full bg-current opacity-70" />
      {label}
    </span>
  );
}
