'use client';
import { useState, useRef } from 'react';
import Image from 'next/image';
import { Upload, X, Star, Loader2 } from 'lucide-react';
import type { Product, Category, ProductImage } from '../../../types';
import {
  uploadProductImage, setPrimaryImage,
  deleteProductImage,
} from '../../../lib/api';
import toast from 'react-hot-toast';

const UNIT_OPTIONS = [
  { value: 'kg', label: 'كيلو (kg)' },
  { value: 'piece', label: 'حبة (piece)' },
  { value: 'bundle', label: 'ربطة (bundle)' },
  { value: 'tray', label: 'صينية (tray)' },
  { value: 'bag', label: 'كيس (bag)' },
  { value: 'jar', label: 'جرة (jar)' },
  { value: 'pack', label: 'علبة (pack)' },
  { value: 'roll', label: 'لفة (roll)' },
];

interface ProductFormProps {
  product?: Product;
  categories: Category[];
  onSubmit: (data: Record<string, unknown>) => Promise<void>;
  submitting: boolean;
}

export default function ProductForm({ product, categories, onSubmit, submitting }: ProductFormProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [images, setImages] = useState<ProductImage[]>(product?.images || []);
  const [uploadingImage, setUploadingImage] = useState(false);

  const [form, setForm] = useState({
    category_id: product?.category_id || categories[0]?.id || '',
    name: product?.name || '',
    name_ar: product?.name_ar || '',
    description: product?.description || '',
    unit: product?.unit || 'kg',
    price: product ? parseFloat(product.price).toString() : '0',
    display_order: product?.display_order?.toString() || '999',
    is_visible: product?.is_visible ?? true,
    is_popular: product?.is_popular ?? false,
  });

  const [errors, setErrors] = useState<Record<string, string>>({});

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    const { name, value, type } = e.target;
    const val = type === 'checkbox' ? (e.target as HTMLInputElement).checked : value;
    setForm((prev) => ({ ...prev, [name]: val }));
    if (errors[name]) setErrors((prev) => ({ ...prev, [name]: '' }));
  };

  const validate = () => {
    const errs: Record<string, string> = {};
    if (!form.category_id) errs.category_id = 'القسم مطلوب';
    if (!form.name.trim()) errs.name = 'الاسم بالإنجليزية مطلوب';
    if (!form.name_ar.trim()) errs.name_ar = 'الاسم بالعربية مطلوب';
    if (isNaN(parseFloat(form.price)) || parseFloat(form.price) < 0) errs.price = 'السعر غير صحيح';
    setErrors(errs);
    return Object.keys(errs).length === 0;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;
    await onSubmit({
      category_id: form.category_id,
      name: form.name.trim(),
      name_ar: form.name_ar.trim(),
      description: form.description.trim() || undefined,
      unit: form.unit,
      price: parseFloat(form.price),
      display_order: parseInt(form.display_order) || 999,
      is_visible: form.is_visible,
      is_popular: form.is_popular,
    });
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!product?.id) {
      toast.error('احفظ المنتج أولاً قبل رفع الصور');
      return;
    }
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate type
    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type)) {
      toast.error('نوع الملف غير مدعوم. يُسمح بـ JPG, PNG, WEBP فقط');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error('حجم الصورة كبير جداً. الحد الأقصى 10 ميجا');
      return;
    }

    setUploadingImage(true);
    const formData = new FormData();
    formData.append('image', file);

    try {
      const res = await uploadProductImage(product.id, formData);
      if (res.data.success) {
        // Refresh images
        const newImage = res.data.data as unknown as ProductImage;
        setImages((prev) => [...prev, newImage]);
        toast.success('تم رفع الصورة بنجاح');
      }
    } catch {
      toast.error('فشل رفع الصورة');
    } finally {
      setUploadingImage(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleSetPrimary = async (imageId: string) => {
    if (!product?.id) return;
    try {
      await setPrimaryImage(product.id, imageId);
      setImages((prev) => prev.map((img) => ({ ...img, is_primary: img.id === imageId })));
      toast.success('تم تعيين الصورة الرئيسية');
    } catch {
      toast.error('فشل تعيين الصورة الرئيسية');
    }
  };

  const handleDeleteImage = async (imageId: string) => {
    if (!product?.id || !confirm('هل تريد حذف هذه الصورة؟')) return;
    try {
      await deleteProductImage(product.id, imageId);
      setImages((prev) => prev.filter((img) => img.id !== imageId));
      toast.success('تم حذف الصورة');
    } catch {
      toast.error('فشل حذف الصورة');
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-6">
      <div className="grid md:grid-cols-2 gap-5">

        {/* Arabic Name */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            الاسم بالعربية <span className="text-red-500">*</span>
          </label>
          <input
            name="name_ar"
            value={form.name_ar}
            onChange={handleChange}
            placeholder="مثال: طماطم"
            className={`input ${errors.name_ar ? 'border-red-400' : ''}`}
          />
          {errors.name_ar && <p className="text-red-500 text-xs mt-1">{errors.name_ar}</p>}
        </div>

        {/* English Name */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            الاسم بالإنجليزية <span className="text-red-500">*</span>
          </label>
          <input
            name="name"
            value={form.name}
            onChange={handleChange}
            placeholder="Example: Tomatoes"
            className={`input ${errors.name ? 'border-red-400' : ''}`}
            dir="ltr"
          />
          {errors.name && <p className="text-red-500 text-xs mt-1">{errors.name}</p>}
        </div>

        {/* Category */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            القسم <span className="text-red-500">*</span>
          </label>
          <select
            name="category_id"
            value={form.category_id}
            onChange={handleChange}
            className={`input ${errors.category_id ? 'border-red-400' : ''}`}
          >
            {categories.map((c) => (
              <option key={c.id} value={c.id}>{c.name_ar}</option>
            ))}
          </select>
          {errors.category_id && <p className="text-red-500 text-xs mt-1">{errors.category_id}</p>}
        </div>

        {/* Unit */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            الوحدة <span className="text-red-500">*</span>
          </label>
          <select name="unit" value={form.unit} onChange={handleChange} className="input">
            {UNIT_OPTIONS.map(({ value, label }) => (
              <option key={value} value={value}>{label}</option>
            ))}
          </select>
        </div>

        {/* Price */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            السعر (جنيه) <span className="text-red-500">*</span>
          </label>
          <input
            name="price"
            type="number"
            min="0"
            step="0.01"
            value={form.price}
            onChange={handleChange}
            placeholder="0.00"
            className={`input ${errors.price ? 'border-red-400' : ''}`}
            dir="ltr"
          />
          {errors.price && <p className="text-red-500 text-xs mt-1">{errors.price}</p>}
        </div>

        {/* Display order */}
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-1.5">
            ترتيب العرض
          </label>
          <input
            name="display_order"
            type="number"
            min="0"
            value={form.display_order}
            onChange={handleChange}
            placeholder="999"
            className="input"
            dir="ltr"
          />
          <p className="text-xs text-gray-400 mt-1">الأرقام الأصغر تظهر أولاً</p>
        </div>
      </div>

      {/* Description */}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">
          الوصف <span className="text-gray-400 font-normal">(اختياري)</span>
        </label>
        <textarea
          name="description"
          value={form.description}
          onChange={handleChange}
          rows={3}
          placeholder="وصف اختياري للمنتج..."
          className="input resize-none"
        />
      </div>

      {/* Toggles */}
      <div className="flex gap-6">
        <label className="flex items-center gap-2 cursor-pointer">
          <div
            onClick={() => setForm((p) => ({ ...p, is_visible: !p.is_visible }))}
            className={`relative w-11 h-6 rounded-full transition-colors
              ${form.is_visible ? 'bg-primary-700' : 'bg-gray-300'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform
              ${form.is_visible ? 'translate-x-1' : 'right-1'}`} />
          </div>
          <span className="text-sm font-medium text-gray-700">ظاهر في المتجر</span>
        </label>

        <label className="flex items-center gap-2 cursor-pointer">
          <div
            onClick={() => setForm((p) => ({ ...p, is_popular: !p.is_popular }))}
            className={`relative w-11 h-6 rounded-full transition-colors
              ${form.is_popular ? 'bg-yellow-500' : 'bg-gray-300'}`}
          >
            <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow transition-transform
              ${form.is_popular ? 'translate-x-1' : 'right-1'}`} />
          </div>
          <span className="text-sm font-medium text-gray-700 flex items-center gap-1">
            <Star size={14} className="text-yellow-500" />
            الأكثر مبيعاً
          </span>
        </label>
      </div>

      {/* Image management (only when editing existing product) */}
      {product && (
        <div>
          <label className="block text-sm font-semibold text-gray-700 mb-3">
            صور المنتج
          </label>

          {/* Existing images */}
          {images.length > 0 && (
            <div className="flex flex-wrap gap-3 mb-4">
              {images.map((img) => (
                <div key={img.id} className="relative group w-24 h-24">
                  <div className={`w-full h-full rounded-lg overflow-hidden border-2 transition-colors
                    ${img.is_primary ? 'border-primary-700' : 'border-gray-200'}`}>
                    <Image
                      src={img.image_url}
                      alt="صورة المنتج"
                      width={96}
                      height={96}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  {img.is_primary && (
                    <span className="absolute -top-1.5 -right-1.5 bg-primary-700 text-white text-[9px] px-1.5 py-0.5 rounded-full font-bold">
                      رئيسية
                    </span>
                  )}
                  <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100
                                  transition-opacity rounded-lg flex items-center justify-center gap-1">
                    {!img.is_primary && (
                      <button
                        type="button"
                        onClick={() => handleSetPrimary(img.id)}
                        title="تعيين رئيسية"
                        className="w-7 h-7 bg-white/90 rounded-full flex items-center justify-center hover:bg-white"
                      >
                        <Star size={13} className="text-yellow-500" />
                      </button>
                    )}
                    <button
                      type="button"
                      onClick={() => handleDeleteImage(img.id)}
                      title="حذف"
                      className="w-7 h-7 bg-white/90 rounded-full flex items-center justify-center hover:bg-white"
                    >
                      <X size={13} className="text-red-500" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}

          {/* Upload button */}
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            onChange={handleImageUpload}
            className="hidden"
            id="image-upload"
          />
          <label
            htmlFor="image-upload"
            className={`flex items-center gap-2 px-4 py-2.5 border-2 border-dashed border-gray-300
                        rounded-lg cursor-pointer hover:border-primary-700 hover:bg-primary-50
                        transition-colors text-sm font-medium text-gray-600 w-fit
                        ${uploadingImage ? 'opacity-50 pointer-events-none' : ''}`}
          >
            {uploadingImage ? (
              <Loader2 size={16} className="animate-spin" />
            ) : (
              <Upload size={16} />
            )}
            {uploadingImage ? 'جاري الرفع...' : 'رفع صورة جديدة'}
          </label>
          <p className="text-xs text-gray-400 mt-1">JPG, PNG, WEBP — الحد الأقصى 10 ميجا</p>
        </div>
      )}

      {/* Submit */}
      <div className="flex gap-3 pt-2">
        <button
          type="submit"
          disabled={submitting}
          className="btn-primary px-8"
        >
          {submitting ? (
            <><Loader2 size={16} className="animate-spin" /> جاري الحفظ...</>
          ) : (
            product ? 'حفظ التعديلات' : 'إضافة المنتج'
          )}
        </button>
      </div>
    </form>
  );
}
