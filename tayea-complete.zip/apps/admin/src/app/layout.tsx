import type { Metadata, Viewport } from 'next';
import { Cairo } from 'next/font/google';
import { Toaster } from 'react-hot-toast';
import './globals.css';

const cairo = Cairo({
  subsets: ['arabic', 'latin'],
  weight: ['400', '600', '700', '800'],
  display: 'swap',
});

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  userScalable: true,
};

export const metadata: Metadata = {
  title: 'لوحة تحكم طابع',
  description: 'لوحة تحكم إدارة متجر طابع للخضار والفاكهة',
  robots: 'noindex, nofollow',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl">
      <body className={`${cairo.className} bg-gray-50 min-h-screen`}>
        {children}
        <Toaster
          position="top-center"
          toastOptions={{
            duration: 3000,
            style: {
              fontFamily: 'Cairo, sans-serif',
              direction: 'rtl',
              borderRadius: '12px',
              padding: '12px 16px',
              fontSize: '14px',
              fontWeight: '600',
            },
            success: {
              style: { background: '#16a34a', color: 'white' },
              iconTheme: { primary: 'white', secondary: '#16a34a' },
            },
            error: {
              style: { background: '#dc2626', color: 'white' },
              iconTheme: { primary: 'white', secondary: '#dc2626' },
            },
          }}
        />
      </body>
    </html>
  );
}
