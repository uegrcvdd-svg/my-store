'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  ArrowRight, MapPin, Copy, Share2, Printer, ExternalLink,
  Phone, User, MessageSquare, Landmark, CheckCircle, RefreshCw,
} from 'lucide-react';
import { fetchAdminOrder, updateOrderStatus, getOrderShareMessage } from '../../../../lib/api';
import type { Order, OrderStatus } from '../../../../types';
import { STATUS_LABELS } from '../../../../types';
import StatusBadge from '../../../../components/orders/StatusBadge';
import { formatDriverMessage } from '../../../../lib/orderShare';

const STATUS_FLOW: OrderStatus[] = ['new', 'confirmed', 'prepared', 'in_delivery', 'delivered', 'cancelled'];

export default function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);
  const [updatingStatus, setUpdatingStatus] = useState(false);
  const [copied, setCopied] = useState(false);
  const [toast, setToast] = useState('');

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetchAdminOrder(id);
      if (res.data.success) setOrder(res.data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, [id]);

  const handleStatusChange = async (status: OrderStatus) => {
    if (!order || updatingStatus) return;
    setUpdatingStatus(true);
    try {
      await updateOrderStatus(order.id, status);
      setOrder((prev) => prev ? { ...prev, status } : prev);
      showToast('تم تحديث حالة الطلب');
    } finally {
      setUpdatingStatus(false);
    }
  };

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(''), 2500);
  };

  const handleCopy = async () => {
    if (!order) return;
    const message = formatDriverMessage(order);
    await navigator.clipboard.writeText(message);
    setCopied(true);
    showToast('تم نسخ معلومات الطلب');
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (!order) return;
    const message = formatDriverMessage(order);
    if (navigator.share) {
      await navigator.share({ text: message });
    } else {
      await handleCopy();
    }
  };

  const handlePrint = () => {
    window.print();
  };

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="skeleton h-8 w-48 rounded" />
        <div className="grid lg:grid-cols-3 gap-4">
          <div className="lg:col-span-2 space-y-4">
            {[1, 2, 3].map((i) => <div key={i} className="card p-5 skeleton h-40" />)}
          </div>
          <div className="card p-5 skeleton h-96" />
        </div>
      </div>
    );
  }

  if (!order) return (
    <div className="text-center py-12">
      <p className="text-gray-500">الطلب غير موجود</p>
      <Link href="/dashboard/orders" className="btn-primary mt-4 inline-flex">
        العودة للطلبات
      </Link>
    </div>
  );

  return (
    <div className="space-y-5">
      {/* Toast */}
      {toast && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-50 bg-green-600 text-white
                        px-5 py-3 rounded-xl shadow-lg font-semibold text-sm flex items-center gap-2">
          <CheckCircle size={16} />
          {toast}
        </div>
      )}

      {/* Header */}
      <div className="flex items-center gap-3">
        <button onClick={() => router.back()} className="p-2 hover:bg-gray-100 rounded-lg">
          <ArrowRight size={20} />
        </button>
        <div>
          <h1 className="text-xl font-bold text-gray-900">
            تفاصيل الطلب #{order.order_number}
          </h1>
          <p className="text-gray-500 text-xs">
            {new Date(order.ordered_at).toLocaleString('ar-EG', {
              weekday: 'long', year: 'numeric', month: 'long',
              day: 'numeric', hour: '2-digit', minute: '2-digit',
            })}
          </p>
        </div>
        <div className="mr-auto">
          <StatusBadge status={order.status} />
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-5">
        {/* Left: main info */}
        <div className="lg:col-span-2 space-y-4">

          {/* Customer Info */}
          <div className="card p-5">
            <h2 className="font-bold text-gray-900 mb-4 text-base">معلومات العميل</h2>
            <div className="space-y-3">
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                  <User size={15} className="text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-400">الاسم</p>
                  <p className="font-semibold text-gray-900">{order.customer_name}</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                  <Phone size={15} className="text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-400">الهاتف</p>
                  <a href={`tel:${order.phone_primary}`} className="font-semibold text-primary-700 hover:underline">
                    {order.phone_primary}
                  </a>
                  {order.phone_secondary && (
                    <p className="text-sm text-gray-600 mt-0.5">{order.phone_secondary}</p>
                  )}
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                  <MapPin size={15} className="text-gray-500" />
                </div>
                <div>
                  <p className="text-xs text-gray-400">العنوان</p>
                  <p className="font-semibold text-gray-900">{order.address_text}</p>
                </div>
              </div>
              {order.landmark && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                    <Landmark size={15} className="text-gray-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">علامة مميزة</p>
                    <p className="font-semibold text-gray-900">{order.landmark}</p>
                  </div>
                </div>
              )}
              {order.notes && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center">
                    <MessageSquare size={15} className="text-gray-500" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400">ملاحظات</p>
                    <p className="text-gray-700">{order.notes}</p>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Order Items */}
          <div className="card p-5">
            <h2 className="font-bold text-gray-900 mb-4 text-base">المنتجات</h2>
            <div className="space-y-3">
              {order.items?.map((item, idx) => (
                <div key={idx} className="flex items-center justify-between py-2 border-b border-gray-50 last:border-0">
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900">{item.product_name_ar}</p>
                    <p className="text-gray-400 text-xs">
                      {Number(item.quantity)} {item.unit_ar} × {Number(item.price_per_unit).toFixed(2)} ج
                    </p>
                  </div>
                  <p className="font-bold text-gray-900">
                    {Number(item.item_total).toFixed(2)} ج
                  </p>
                </div>
              ))}
              <div className="flex justify-between pt-2 font-bold text-base">
                <span>الإجمالي</span>
                <span className="text-primary-700">{Number(order.grand_total).toFixed(2)} جنيه</span>
              </div>
            </div>
          </div>

          {/* Map */}
          {order.maps_link && (
            <div className="card overflow-hidden">
              <div className="relative w-full h-48 bg-gray-100">
                <iframe
                  src={`https://maps.google.com/maps?q=${order.gps_lat},${order.gps_lng}&z=15&output=embed`}
                  className="w-full h-full border-0"
                  loading="lazy"
                  title="موقع العميل"
                />
              </div>
            </div>
          )}
        </div>

        {/* Right: actions */}
        <div className="space-y-4">
          {/* Status update */}
          <div className="card p-5">
            <h2 className="font-bold text-gray-900 mb-4 text-sm">تحديث الحالة</h2>
            <div className="space-y-2">
              {STATUS_FLOW.map((s) => (
                <button
                  key={s}
                  onClick={() => handleStatusChange(s)}
                  disabled={updatingStatus || order.status === s}
                  className={`w-full text-sm py-2.5 rounded-lg font-medium transition-all
                    ${order.status === s
                      ? 'bg-primary-700 text-white cursor-default'
                      : 'bg-gray-50 text-gray-600 hover:bg-gray-100 disabled:opacity-50'
                    }`}
                >
                  {updatingStatus && order.status !== s ? (
                    <RefreshCw size={14} className="animate-spin inline" />
                  ) : null}{' '}
                  {STATUS_LABELS[s]}
                </button>
              ))}
            </div>
          </div>

          {/* Order actions */}
          <div className="card p-5">
            <h2 className="font-bold text-gray-900 mb-4 text-sm">إجراءات الطلب</h2>
            <div className="space-y-2">
              {order.maps_link && (
                <a
                  href={order.maps_link}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="btn-secondary w-full justify-center text-sm"
                >
                  <ExternalLink size={16} />
                  فتح خرائط جوجل
                </a>
              )}
              <button onClick={handleCopy} className="btn-secondary w-full justify-center text-sm">
                <Copy size={16} />
                {copied ? 'تم النسخ ✓' : 'نسخ معلومات الطلب'}
              </button>
              <button onClick={handleShare} className="btn-secondary w-full justify-center text-sm">
                <Share2 size={16} />
                مشاركة الطلب
              </button>
              <button onClick={handlePrint} className="btn-secondary w-full justify-center text-sm">
                <Printer size={16} />
                طباعة الطلب
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
