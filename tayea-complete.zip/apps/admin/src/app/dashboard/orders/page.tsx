'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import { useSearchParams } from 'next/navigation';
import { Search, Eye, RefreshCw } from 'lucide-react';
import { fetchAdminOrders } from '../../../lib/api';
import type { Order, OrderStatus } from '../../../types';
import { STATUS_LABELS } from '../../../types';
import StatusBadge from '../../../components/orders/StatusBadge';
import { Suspense } from 'react';

const STATUSES: { value: string; label: string }[] = [
  { value: '', label: 'الكل' },
  { value: 'new', label: STATUS_LABELS.new },
  { value: 'confirmed', label: STATUS_LABELS.confirmed },
  { value: 'prepared', label: STATUS_LABELS.prepared },
  { value: 'in_delivery', label: STATUS_LABELS.in_delivery },
  { value: 'delivered', label: STATUS_LABELS.delivered },
  { value: 'cancelled', label: STATUS_LABELS.cancelled },
];

function OrdersContent() {
  const searchParams = useSearchParams();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState(searchParams.get('status') || '');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const limit = 20;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchAdminOrders({ page, limit, search: search || undefined, status: status || undefined });
      if (res.data.success) {
        setOrders(res.data.data);
        setTotal(res.data.meta?.total || 0);
      }
    } finally {
      setLoading(false);
    }
  }, [page, search, status]);

  useEffect(() => {
    load();
    // Auto-refresh every 30s so new orders appear without manual refresh
    const interval = setInterval(() => load(), 30000);
    return () => clearInterval(interval);
  }, [load]);

  // Debounce search
  useEffect(() => {
    const t = setTimeout(() => { setPage(1); load(); }, 400);
    return () => clearTimeout(t);
  }, [search]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">الطلبات</h1>
        <button onClick={load} className="btn-secondary">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          تحديث
        </button>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="بحث بالاسم أو الهاتف أو رقم الطلب..."
            className="input pr-9"
          />
        </div>
        <div className="flex gap-2 flex-wrap">
          {STATUSES.map(({ value, label }) => (
            <button
              key={value}
              onClick={() => { setStatus(value); setPage(1); }}
              className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-colors
                ${status === value
                  ? 'bg-primary-700 text-white'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="flex items-center justify-between px-5 py-3 border-b border-gray-100">
          <p className="text-sm text-gray-500">{total} طلب</p>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 whitespace-nowrap">#</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">العميل</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden lg:table-cell">العنوان</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">الوقت</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الإجمالي</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 8 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 7 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded w-20" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={7} className="px-4 py-12 text-center text-gray-400">
                    لا توجد طلبات
                  </td>
                </tr>
              ) : (
                orders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-bold text-primary-700 whitespace-nowrap">
                      #{order.order_number}
                    </td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="font-semibold text-gray-900">{order.customer_name}</p>
                        <p className="text-gray-400 text-xs">{order.phone_primary}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600 hidden lg:table-cell max-w-[180px] truncate">
                      {order.address_text}
                    </td>
                    <td className="px-4 py-3 text-gray-500 hidden md:table-cell text-xs whitespace-nowrap">
                      {new Date(order.ordered_at).toLocaleString('ar-EG', {
                        month: 'short', day: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                    <td className="px-4 py-3 font-bold text-gray-900 whitespace-nowrap">
                      {parseFloat(order.grand_total).toFixed(2)} ج
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={order.status} />
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/dashboard/orders/${order.id}`}
                        className="flex items-center gap-1 text-primary-700 hover:text-primary-800 font-semibold text-xs"
                      >
                        <Eye size={14} />
                        عرض
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > limit && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >
              السابق
            </button>
            <span className="text-sm text-gray-500">
              صفحة {page} من {Math.ceil(total / limit)}
            </span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={page * limit >= total}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >
              التالي
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

export default function OrdersPage() {
  return (
    <Suspense fallback={<div className="animate-pulse">جاري التحميل...</div>}>
      <OrdersContent />
    </Suspense>
  );
}
