'use client';
import { useState, useEffect, useRef, useCallback } from 'react';
import Link from 'next/link';
import { ShoppingBag, Users, TrendingUp, Package, ArrowLeft, RefreshCw } from 'lucide-react';
import { fetchDashboardStats, fetchRecentOrders } from '../../lib/api';
import type { DashboardStats, Order } from '../../types';
import { STATUS_LABELS, STATUS_COLORS } from '../../types';
import StatusBadge from '../../components/orders/StatusBadge';
import toast from 'react-hot-toast';

export default function DashboardPage() {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const prevNewCount = useRef<number | null>(null);

  const load = useCallback(async (silent = false) => {
    if (!silent) setLoading(true);
    try {
      const [statsRes, ordersRes] = await Promise.all([
        fetchDashboardStats(),
        fetchRecentOrders(),
      ]);
      if (statsRes.data.success) {
        const newCount = parseInt(statsRes.data.data.new_orders || '0');
        // Notify admin if new orders arrived since last poll
        if (prevNewCount.current !== null && newCount > prevNewCount.current) {
          const diff = newCount - prevNewCount.current;
          toast.success(
            `🛒 ${diff === 1 ? 'طلب جديد وصل!' : `${diff} طلبات جديدة وصلت!`}`,
            { duration: 6000, id: 'new-order-alert' }
          );
        }
        prevNewCount.current = newCount;
        setStats(statsRes.data.data);
      }
      if (ordersRes.data.success) setOrders(ordersRes.data.data);
    } finally {
      if (!silent) setLoading(false);
    }
  }, []);

  useEffect(() => {
    load();
    // Poll every 30 seconds for new orders
    const interval = setInterval(() => load(true), 30000);
    return () => clearInterval(interval);
  }, [load]);

  const calcChange = (today: string, yesterday: string) => {
    const t = parseFloat(today || '0');
    const y = parseFloat(yesterday || '0');
    if (y === 0) return t > 0 ? '+100%' : '0%';
    const pct = ((t - y) / y) * 100;
    return `${pct >= 0 ? '+' : ''}${pct.toFixed(0)}%`;
  };

  const statCards = stats
    ? [
        {
          label: 'إجمالي المبيعات اليوم',
          value: `${parseFloat(stats.total_sales_today).toFixed(2)} ج`,
          change: calcChange(stats.total_sales_today, stats.total_sales_yesterday),
          icon: TrendingUp,
          color: 'bg-green-50 text-green-700',
        },
        {
          label: 'طلبات اليوم',
          value: stats.orders_today,
          change: calcChange(stats.orders_today, stats.orders_yesterday),
          icon: ShoppingBag,
          color: 'bg-blue-50 text-blue-700',
        },
        {
          label: 'إجمالي العملاء',
          value: stats.customers_total,
          change: '',
          icon: Users,
          color: 'bg-purple-50 text-purple-700',
        },
        {
          label: 'إجمالي الطلبات',
          value: stats.orders_total,
          change: '',
          icon: Package,
          color: 'bg-orange-50 text-orange-700',
        },
      ]
    : [];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">لوحة التحكم</h1>
          <p className="text-gray-500 text-sm mt-1">مرحباً بك في إدارة متجر طابع</p>
        </div>
        <button
          onClick={() => load(false)}
          disabled={loading}
          className="btn-secondary"
        >
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          تحديث
        </button>
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {loading
          ? Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="card p-5">
                <div className="skeleton h-10 w-10 rounded-lg mb-3" />
                <div className="skeleton h-7 w-24 mb-2" />
                <div className="skeleton h-4 w-32" />
              </div>
            ))
          : statCards.map(({ label, value, change, icon: Icon, color }) => (
              <div key={label} className="card p-5">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color}`}>
                  <Icon size={20} />
                </div>
                <p className="text-2xl font-bold text-gray-900">{value}</p>
                <p className="text-gray-500 text-xs mt-1">{label}</p>
                {change && (
                  <p className={`text-xs font-semibold mt-1 ${change.startsWith('+') ? 'text-green-600' : 'text-red-500'}`}>
                    {change} عن أمس
                  </p>
                )}
              </div>
            ))}
      </div>

      {/* New orders alert */}
      {stats && parseInt(stats.new_orders) > 0 && (
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 bg-blue-500 rounded-full animate-pulse" />
            <p className="text-blue-800 font-semibold">
              {stats.new_orders} طلب جديد في انتظار المعالجة
            </p>
          </div>
          <Link href="/dashboard/orders?status=new" className="btn-primary text-sm py-2">
            عرض الطلبات
          </Link>
        </div>
      )}

      {/* Recent orders */}
      <div className="card">
        <div className="flex items-center justify-between px-5 py-4 border-b border-gray-100">
          <h2 className="font-bold text-gray-900">أحدث الطلبات</h2>
          <Link href="/dashboard/orders" className="text-sm text-primary-700 font-semibold flex items-center gap-1">
            عرض الكل
            <ArrowLeft size={14} />
          </Link>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">#</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">العميل</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">الوقت</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الإجمالي</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراء</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 5 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded w-20" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : orders.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-8 text-center text-gray-400">
                    لا توجد طلبات بعد
                  </td>
                </tr>
              ) : (
                orders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3 font-bold text-primary-700">#{order.order_number}</td>
                    <td className="px-4 py-3">
                      <div>
                        <p className="font-semibold text-gray-900">{order.customer_name}</p>
                        <p className="text-gray-400 text-xs">{order.phone_primary}</p>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-500 hidden md:table-cell text-xs">
                      {new Date(order.ordered_at).toLocaleString('ar-EG', {
                        month: 'short', day: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                    <td className="px-4 py-3 font-bold text-gray-900">
                      {parseFloat(order.grand_total).toFixed(2)} ج
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={order.status} />
                    </td>
                    <td className="px-4 py-3">
                      <Link
                        href={`/dashboard/orders/${order.id}`}
                        className="text-primary-700 hover:text-primary-800 font-semibold text-xs"
                      >
                        عرض
                      </Link>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
