'use client';
import { useState, useEffect, useCallback } from 'react';
import { RefreshCw, Activity } from 'lucide-react';
import { fetchActivity } from '../../../lib/api';
import type { ActivityLog } from '../../../types';

const ACTION_LABELS: Record<string, string> = {
  admin_login: 'تسجيل دخول',
  admin_logout: 'تسجيل خروج',
  product_created: 'إضافة منتج',
  product_updated: 'تعديل منتج',
  product_deleted: 'حذف منتج',
  product_visibility_changed: 'تغيير ظهور منتج',
  price_updated: 'تحديث سعر',
  banner_created: 'إضافة بانر',
  banner_updated: 'تعديل بانر',
  banner_deleted: 'حذف بانر',
  order_status_changed: 'تغيير حالة طلب',
  order_viewed: 'فتح طلب',
  settings_updated: 'تحديث الإعدادات',
  image_uploaded: 'رفع صورة',
  image_deleted: 'حذف صورة',
};

const ACTION_COLORS: Record<string, string> = {
  admin_login: 'bg-blue-100 text-blue-700',
  admin_logout: 'bg-gray-100 text-gray-600',
  product_created: 'bg-green-100 text-green-700',
  product_updated: 'bg-yellow-100 text-yellow-700',
  product_deleted: 'bg-red-100 text-red-700',
  product_visibility_changed: 'bg-purple-100 text-purple-700',
  price_updated: 'bg-orange-100 text-orange-700',
  banner_created: 'bg-green-100 text-green-700',
  banner_updated: 'bg-yellow-100 text-yellow-700',
  banner_deleted: 'bg-red-100 text-red-700',
  order_status_changed: 'bg-indigo-100 text-indigo-700',
  order_viewed: 'bg-gray-100 text-gray-600',
  settings_updated: 'bg-blue-100 text-blue-700',
  image_uploaded: 'bg-teal-100 text-teal-700',
  image_deleted: 'bg-red-100 text-red-700',
};

export default function ActivityPage() {
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const limit = 50;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchActivity(page, limit);
      if (res.data.success) {
        setLogs(res.data.data);
        setTotal(res.data.meta?.total || 0);
      }
    } finally {
      setLoading(false);
    }
  }, [page]);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="space-y-5">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">سجل النشاط</h1>
          <p className="text-gray-500 text-sm">{total} سجل</p>
        </div>
        <button onClick={load} className="btn-secondary">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          تحديث
        </button>
      </div>

      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الإجراء</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الوصف</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">المستخدم</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden lg:table-cell">IP</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الوقت</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 5 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded w-24" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : logs.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-4 py-12 text-center">
                    <Activity size={32} className="mx-auto text-gray-300 mb-2" />
                    <p className="text-gray-400">لا توجد سجلات بعد</p>
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr key={log.id} className="hover:bg-gray-50 transition-colors">
                    <td className="px-4 py-3">
                      <span className={`inline-block px-2.5 py-1 rounded-full text-xs font-bold
                        ${ACTION_COLORS[log.action] || 'bg-gray-100 text-gray-600'}`}>
                        {ACTION_LABELS[log.action] || log.action}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-gray-700 max-w-xs truncate">
                      {log.description || '—'}
                    </td>
                    <td className="px-4 py-3 text-gray-500 hidden md:table-cell">
                      {log.username || 'نظام'}
                    </td>
                    <td className="px-4 py-3 text-gray-400 text-xs hidden lg:table-cell font-mono">
                      {log.ip_address || '—'}
                    </td>
                    <td className="px-4 py-3 text-gray-500 text-xs whitespace-nowrap">
                      {new Date(log.created_at).toLocaleString('ar-EG', {
                        month: 'short', day: 'numeric',
                        hour: '2-digit', minute: '2-digit',
                      })}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > limit && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >السابق</button>
            <span className="text-sm text-gray-500">
              صفحة {page} من {Math.ceil(total / limit)}
            </span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={page * limit >= total}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >التالي</button>
          </div>
        )}
      </div>
    </div>
  );
}
