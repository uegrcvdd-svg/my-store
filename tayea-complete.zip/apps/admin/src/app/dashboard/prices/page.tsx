'use client';
import { useState, useEffect, useCallback } from 'react';
import Image from 'next/image';
import { Save, RefreshCw, CheckCircle, Search } from 'lucide-react';
import { fetchPrices, updatePrice, bulkUpdatePrices } from '../../../lib/api';
import toast from 'react-hot-toast';

interface PriceProduct {
  id: string;
  name_ar: string;
  unit_ar: string;
  price: string;
  category_name_ar: string;
  primary_image: string | null;
}

export default function PricesPage() {
  const [products, setProducts] = useState<PriceProduct[]>([]);
  const [prices, setPrices] = useState<Record<string, string>>({});
  const [modified, setModified] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);
  const [savingAll, setSavingAll] = useState(false);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchPrices();
      if (res.data.success) {
        const data = res.data.data as unknown as PriceProduct[];
        setProducts(data);
        const priceMap: Record<string, string> = {};
        data.forEach((p) => { priceMap[p.id] = parseFloat(p.price).toString(); });
        setPrices(priceMap);
        setModified(new Set());
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handlePriceChange = (id: string, value: string) => {
    setPrices((prev) => ({ ...prev, [id]: value }));
    setModified((prev) => new Set(prev).add(id));
  };

  const handleSaveOne = async (id: string) => {
    const price = parseFloat(prices[id]);
    if (isNaN(price) || price < 0) { toast.error('السعر غير صحيح'); return; }
    setSaving(id);
    try {
      await updatePrice(id, price);
      setModified((prev) => { const s = new Set(prev); s.delete(id); return s; });
      toast.success('تم حفظ السعر');
    } catch {
      toast.error('فشل حفظ السعر');
    } finally {
      setSaving(null);
    }
  };

  const handleSaveAll = async () => {
    if (modified.size === 0) { toast('لا توجد تغييرات', { icon: 'ℹ️' }); return; }
    const items = Array.from(modified).map((id) => ({
      id,
      price: parseFloat(prices[id]),
    })).filter((i) => !isNaN(i.price) && i.price >= 0);

    if (items.length === 0) { toast.error('لا توجد أسعار صحيحة لحفظها'); return; }
    setSavingAll(true);
    try {
      await bulkUpdatePrices(items);
      setModified(new Set());
      toast.success(`تم حفظ ${items.length} سعر بنجاح`);
    } catch {
      toast.error('فشل حفظ الأسعار');
    } finally {
      setSavingAll(false);
    }
  };

  // Filter displayed products
  const displayed = products.filter((p) => {
    const matchSearch = !search || p.name_ar.includes(search);
    const matchFilter = !filter || p.category_name_ar === filter;
    return matchSearch && matchFilter;
  });

  const categories = Array.from(new Set(products.map((p) => p.category_name_ar)));

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">إدارة الأسعار</h1>
          <p className="text-gray-500 text-sm">
            {products.length} منتج
            {modified.size > 0 && (
              <span className="text-orange-600 font-semibold mr-2">
                · {modified.size} تغيير غير محفوظ
              </span>
            )}
          </p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="btn-secondary">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <button
            onClick={handleSaveAll}
            disabled={savingAll || modified.size === 0}
            className="btn-primary disabled:opacity-50"
          >
            {savingAll ? (
              <RefreshCw size={16} className="animate-spin" />
            ) : (
              <Save size={16} />
            )}
            حفظ الكل ({modified.size})
          </button>
        </div>
      </div>

      {/* Info banner */}
      <div className="bg-blue-50 border border-blue-200 rounded-xl px-4 py-3 text-sm text-blue-700 flex items-center gap-2">
        <CheckCircle size={16} />
        كل تغيير في السعر يظهر فوراً على الموقع بعد الحفظ
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="ابحث عن منتج..."
            className="input pr-9"
          />
        </div>
        <select
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="input w-auto min-w-[140px]"
        >
          <option value="">كل الأقسام</option>
          {categories.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Price table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">المنتج</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">القسم</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الوحدة</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">السعر الحالي</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">السعر الجديد</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">حفظ</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded w-20" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : displayed.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-gray-400">
                    لا توجد منتجات
                  </td>
                </tr>
              ) : (
                displayed.map((product) => {
                  const isModified = modified.has(product.id);
                  const currentPrice = parseFloat(product.price);
                  return (
                    <tr
                      key={product.id}
                      className={`transition-colors ${isModified ? 'bg-orange-50' : 'hover:bg-gray-50'}`}
                    >
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-3">
                          <div className="w-9 h-9 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                            {product.primary_image ? (
                              <Image
                                src={product.primary_image}
                                alt={product.name_ar}
                                width={36}
                                height={36}
                                className="object-cover w-full h-full"
                              />
                            ) : (
                              <div className="w-full h-full flex items-center justify-center text-[9px] text-gray-300">
                                لا صورة
                              </div>
                            )}
                          </div>
                          <span className="font-semibold text-gray-900">{product.name_ar}</span>
                        </div>
                      </td>
                      <td className="px-4 py-3 text-gray-500 hidden md:table-cell">
                        {product.category_name_ar}
                      </td>
                      <td className="px-4 py-3 text-gray-500">{product.unit_ar}</td>
                      <td className="px-4 py-3 font-semibold text-gray-700">
                        {currentPrice > 0 ? `${currentPrice.toFixed(2)} ج` : (
                          <span className="text-gray-400 text-xs">غير محدد</span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <div className="relative">
                          <input
                            type="number"
                            min="0"
                            step="0.01"
                            value={prices[product.id] || ''}
                            onChange={(e) => handlePriceChange(product.id, e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && handleSaveOne(product.id)}
                            className={`input w-28 text-left py-1.5 pr-2 pl-6
                              ${isModified ? 'border-orange-400 bg-orange-50' : ''}`}
                            dir="ltr"
                          />
                          <span className="absolute left-2 top-1/2 -translate-y-1/2 text-gray-400 text-xs pointer-events-none">
                            ج
                          </span>
                        </div>
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => handleSaveOne(product.id)}
                          disabled={saving === product.id || !isModified}
                          className={`flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold
                            transition-all
                            ${isModified
                              ? 'bg-primary-700 text-white hover:bg-primary-800'
                              : 'bg-gray-100 text-gray-400 cursor-not-allowed'
                            }`}
                        >
                          {saving === product.id ? (
                            <RefreshCw size={12} className="animate-spin" />
                          ) : (
                            <Save size={12} />
                          )}
                          حفظ
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
