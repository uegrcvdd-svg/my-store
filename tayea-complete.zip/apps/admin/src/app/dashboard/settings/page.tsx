'use client';
import { useState, useEffect } from 'react';
import { Save, RefreshCw, CheckCircle } from 'lucide-react';
import { fetchAdminSettings, updateSettings } from '../../../lib/api';
import type { Setting } from '../../../types';
import toast from 'react-hot-toast';

export default function SettingsPage() {
  const [settings, setSettings] = useState<Setting[]>([]);
  const [values, setValues] = useState<Record<string, string>>({});
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetchAdminSettings();
      if (res.data.success) {
        setSettings(res.data.data);
        const vals: Record<string, string> = {};
        res.data.data.forEach((s) => { vals[s.key] = s.value || ''; });
        setValues(vals);
      }
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleChange = (key: string, value: string) => {
    setValues((prev) => ({ ...prev, [key]: value }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      // Only send known writable keys
      const writableKeys = [
        'store_name', 'store_address', 'phone_primary', 'phone_secondary',
        'whatsapp_number', 'maps_link', 'working_hours',
        'facebook_url', 'instagram_url', 'delivery_area', 'currency',
      ];
      const payload: Record<string, string> = {};
      writableKeys.forEach((k) => { if (values[k] !== undefined) payload[k] = values[k]; });

      await updateSettings(payload);
      toast.success('تم حفظ الإعدادات بنجاح');
    } catch {
      toast.error('فشل حفظ الإعدادات');
    } finally {
      setSaving(false);
    }
  };

  const fieldConfig: Record<string, { type: string; placeholder: string }> = {
    store_name: { type: 'text', placeholder: 'طابع' },
    store_address: { type: 'text', placeholder: 'قنا، مصر' },
    phone_primary: { type: 'tel', placeholder: '+201008721996' },
    phone_secondary: { type: 'tel', placeholder: '+20xxxxxxxxxx' },
    whatsapp_number: { type: 'text', placeholder: '201008721996' },
    maps_link: { type: 'url', placeholder: 'https://maps.google.com/...' },
    working_hours: { type: 'text', placeholder: 'يومياً 8 ص - 10 م' },
    facebook_url: { type: 'url', placeholder: 'https://facebook.com/...' },
    instagram_url: { type: 'url', placeholder: 'https://instagram.com/...' },
    delivery_area: { type: 'text', placeholder: 'محافظة قنا - مصر' },
    currency: { type: 'text', placeholder: 'جنيه' },
  };

  if (loading) {
    return (
      <div className="space-y-4 max-w-2xl">
        <div className="skeleton h-8 w-40 rounded" />
        <div className="card p-6 space-y-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="space-y-1">
              <div className="skeleton h-4 w-32 rounded" />
              <div className="skeleton h-10 rounded-lg" />
            </div>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-2xl">
      {/* Header */}
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold text-gray-900">الإعدادات</h1>
        <button onClick={load} className="btn-secondary">
          <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
        </button>
      </div>

      <div className="bg-primary-50 border border-primary-100 rounded-xl px-4 py-3 text-sm text-primary-700 flex items-center gap-2">
        <CheckCircle size={16} />
        التغييرات تظهر على الموقع فوراً بعد الحفظ
      </div>

      <div className="card p-6 space-y-5">
        {settings
          .filter((s) => s.key in fieldConfig)
          .sort((a, b) => {
            const order = Object.keys(fieldConfig);
            return order.indexOf(a.key) - order.indexOf(b.key);
          })
          .map((setting) => {
            const config = fieldConfig[setting.key];
            if (!config) return null;
            return (
              <div key={setting.key}>
                <label className="block text-sm font-semibold text-gray-700 mb-1.5">
                  {setting.label || setting.key}
                </label>
                <input
                  type={config.type}
                  value={values[setting.key] || ''}
                  onChange={(e) => handleChange(setting.key, e.target.value)}
                  placeholder={config.placeholder}
                  className="input"
                  dir={['phone_primary', 'phone_secondary', 'whatsapp_number', 'maps_link',
                         'facebook_url', 'instagram_url'].includes(setting.key) ? 'ltr' : 'rtl'}
                />
              </div>
            );
          })}

        {/* Save button */}
        <div className="pt-2 border-t border-gray-100">
          <button
            onClick={handleSave}
            disabled={saving}
            className="btn-primary px-8"
          >
            {saving ? (
              <><RefreshCw size={16} className="animate-spin" /> جاري الحفظ...</>
            ) : (
              <><Save size={16} /> حفظ الإعدادات</>
            )}
          </button>
        </div>
      </div>

      {/* Change username section */}
      <div className="card p-6">
        <h2 className="font-bold text-gray-900 mb-4">تغيير اسم المستخدم</h2>
        <ChangeUsernameForm />
      </div>

      {/* Change password section */}
      <div className="card p-6">
        <h2 className="font-bold text-gray-900 mb-4">تغيير كلمة المرور</h2>
        <ChangePasswordForm />
      </div>
    </div>
  );
}

function ChangeUsernameForm() {
  const [form, setForm] = useState({ newUsername: '', currentPassword: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (form.newUsername.trim().length < 3) { setError('اسم المستخدم يجب أن يكون 3 أحرف على الأقل'); return; }
    if (!form.currentPassword) { setError('كلمة المرور الحالية مطلوبة للتحقق'); return; }

    setSaving(true);
    try {
      const { default: api } = await import('../../../lib/api');
      await api.post('/admin/auth/change-username', {
        new_username: form.newUsername.trim(),
        current_password: form.currentPassword,
      });
      toast.success('تم تغيير اسم المستخدم بنجاح');
      setForm({ newUsername: '', currentPassword: '' });
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'فشل تغيير اسم المستخدم');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-3 py-2 text-sm">
          {error}
        </div>
      )}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">اسم المستخدم الجديد</label>
        <input type="text" value={form.newUsername} onChange={(e) => setForm((p) => ({ ...p, newUsername: e.target.value }))} className="input" dir="ltr" placeholder="new_username" />
      </div>
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور الحالية (للتحقق)</label>
        <input type="password" value={form.currentPassword} onChange={(e) => setForm((p) => ({ ...p, currentPassword: e.target.value }))} className="input" dir="ltr" />
      </div>
      <button type="submit" disabled={saving} className="btn-primary">
        {saving ? <><RefreshCw size={14} className="animate-spin" /> جاري الحفظ...</> : 'تغيير اسم المستخدم'}
      </button>
    </form>
  );
}

function ChangePasswordForm() {
  const [form, setForm] = useState({ current: '', newPass: '', confirm: '' });
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (form.newPass.length < 8) { setError('كلمة المرور يجب أن تكون 8 أحرف على الأقل'); return; }
    if (form.newPass !== form.confirm) { setError('كلمتا المرور غير متطابقتين'); return; }
    if (!/(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/.test(form.newPass)) {
      setError('يجب أن تحتوي على حروف كبيرة وصغيرة وأرقام');
      return;
    }

    setSaving(true);
    try {
      const api = (await import('../../../lib/api')).default;
      await api.post('/admin/auth/change-password', {
        current_password: form.current,
        new_password: form.newPass,
        confirm_password: form.confirm,
      });
      toast.success('تم تغيير كلمة المرور');
      setForm({ current: '', newPass: '', confirm: '' });
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'فشل تغيير كلمة المرور');
    } finally {
      setSaving(false);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      {error && (
        <div className="bg-red-50 border border-red-200 text-red-700 rounded-lg px-3 py-2 text-sm">
          {error}
        </div>
      )}
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور الحالية</label>
        <input type="password" value={form.current} onChange={(e) => setForm((p) => ({ ...p, current: e.target.value }))} className="input" dir="ltr" />
      </div>
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">كلمة المرور الجديدة</label>
        <input type="password" value={form.newPass} onChange={(e) => setForm((p) => ({ ...p, newPass: e.target.value }))} className="input" dir="ltr" />
      </div>
      <div>
        <label className="block text-sm font-semibold text-gray-700 mb-1.5">تأكيد كلمة المرور الجديدة</label>
        <input type="password" value={form.confirm} onChange={(e) => setForm((p) => ({ ...p, confirm: e.target.value }))} className="input" dir="ltr" />
      </div>
      <button type="submit" disabled={saving} className="btn-primary">
        {saving ? <><RefreshCw size={14} className="animate-spin" /> جاري الحفظ...</> : 'تغيير كلمة المرور'}
      </button>
    </form>
  );
}
