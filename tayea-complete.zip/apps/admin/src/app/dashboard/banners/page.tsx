'use client';
import { useState, useEffect, useRef } from 'react';
import Image from 'next/image';
import {
  Plus, Trash2, Eye, EyeOff, Upload, RefreshCw, GripVertical, Loader2,
} from 'lucide-react';
import {
  fetchAdminBanners, createBanner, deleteBanner,
  toggleBanner, updateBanner,
} from '../../../lib/api';
import type { Banner } from '../../../types';
import toast from 'react-hot-toast';

export default function BannersPage() {
  const [banners, setBanners] = useState<Banner[]>([]);
  const [loading, setLoading] = useState(true);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const load = async () => {
    setLoading(true);
    try {
      const res = await fetchAdminBanners();
      if (res.data.success) setBanners(res.data.data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { load(); }, []);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const allowed = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.type)) {
      toast.error('نوع الملف غير مدعوم');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      toast.error('حجم الصورة كبير جداً. الحد الأقصى 10 ميجا');
      return;
    }

    setUploading(true);
    const formData = new FormData();
    formData.append('image', file);
    formData.append('display_order', String(banners.length));

    try {
      const res = await createBanner(formData);
      if (res.data.success) {
        setBanners((prev) => [...prev, res.data.data]);
        toast.success('تم إضافة البانر بنجاح');
      }
    } catch {
      toast.error('فشل رفع البانر');
    } finally {
      setUploading(false);
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const handleToggle = async (id: string) => {
    try {
      await toggleBanner(id);
      setBanners((prev) =>
        prev.map((b) => (b.id === id ? { ...b, is_active: !b.is_active } : b))
      );
      toast.success('تم تحديث حالة البانر');
    } catch {
      toast.error('فشل تحديث البانر');
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm('هل تريد حذف هذا البانر؟')) return;
    try {
      await deleteBanner(id);
      setBanners((prev) => prev.filter((b) => b.id !== id));
      toast.success('تم حذف البانر');
    } catch {
      toast.error('فشل حذف البانر');
    }
  };

  const handleUpdateTitle = async (id: string, title: string, subtitle: string) => {
    try {
      await updateBanner(id, { title, subtitle });
      setBanners((prev) => prev.map((b) => b.id === id ? { ...b, title, subtitle } : b));
      toast.success('تم حفظ النص');
    } catch {
      toast.error('فشل الحفظ');
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">البانرات</h1>
          <p className="text-gray-500 text-sm">الصور التي تظهر في الشريط الرئيسي للموقع</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="btn-secondary">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/jpg,image/png,image/webp"
            onChange={handleUpload}
            className="hidden"
            id="banner-upload"
          />
          <label
            htmlFor="banner-upload"
            className={`btn-primary cursor-pointer ${uploading ? 'opacity-70 pointer-events-none' : ''}`}
          >
            {uploading ? (
              <><Loader2 size={16} className="animate-spin" /> جاري الرفع...</>
            ) : (
              <><Plus size={16} /> إضافة بانر</>
            )}
          </label>
        </div>
      </div>

      {/* Info */}
      <div className="bg-primary-50 border border-primary-100 rounded-xl px-4 py-3 text-sm text-primary-700">
        البانرات الظاهرة ({banners.filter((b) => b.is_active).length}) ستظهر على الموقع بالترتيب المحدد.
        الأبعاد الموصى بها: 1200×500 بكسل
      </div>

      {/* Banners list */}
      {loading ? (
        <div className="grid md:grid-cols-2 gap-4">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="card overflow-hidden">
              <div className="skeleton aspect-[2.5/1]" />
              <div className="p-3 space-y-2">
                <div className="skeleton h-4 w-32 rounded" />
                <div className="skeleton h-8 rounded" />
              </div>
            </div>
          ))}
        </div>
      ) : banners.length === 0 ? (
        <div className="card p-12 text-center">
          <Upload size={40} className="mx-auto text-gray-300 mb-3" />
          <p className="text-gray-500 font-medium">لا توجد بانرات بعد</p>
          <p className="text-gray-400 text-sm mt-1">أضف صورة بانر جديدة من الزر أعلاه</p>
        </div>
      ) : (
        <div className="grid md:grid-cols-2 gap-4">
          {banners.map((banner, index) => (
            <BannerCard
              key={banner.id}
              banner={banner}
              index={index}
              onToggle={handleToggle}
              onDelete={handleDelete}
              onUpdateTitle={handleUpdateTitle}
            />
          ))}
        </div>
      )}
    </div>
  );
}

function BannerCard({
  banner, index, onToggle, onDelete, onUpdateTitle,
}: {
  banner: Banner;
  index: number;
  onToggle: (id: string) => void;
  onDelete: (id: string) => void;
  onUpdateTitle: (id: string, title: string, subtitle: string) => void;
}) {
  const [title, setTitle] = useState(banner.title || '');
  const [subtitle, setSubtitle] = useState(banner.subtitle || '');
  const [editing, setEditing] = useState(false);

  const handleSave = () => {
    onUpdateTitle(banner.id, title, subtitle);
    setEditing(false);
  };

  return (
    <div className={`card overflow-hidden ${!banner.is_active ? 'opacity-60' : ''}`}>
      {/* Image */}
      <div className="relative aspect-[2.5/1] bg-gray-100">
        <Image
          src={banner.image_url}
          alt={banner.title || `بانر ${index + 1}`}
          fill
          className="object-cover"
          sizes="(max-width: 768px) 100vw, 50vw"
        />
        <div className="absolute top-2 right-2">
          <span className={`px-2 py-0.5 rounded-full text-xs font-bold
            ${banner.is_active ? 'bg-green-500 text-white' : 'bg-gray-500 text-white'}`}>
            {banner.is_active ? 'نشط' : 'معطل'}
          </span>
        </div>
        <div className="absolute top-2 left-2">
          <span className="bg-black/40 text-white text-xs px-2 py-0.5 rounded-full">
            #{index + 1}
          </span>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-3">
        {editing ? (
          <div className="space-y-2">
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="عنوان البانر (اختياري)"
              className="input text-sm py-2"
            />
            <input
              value={subtitle}
              onChange={(e) => setSubtitle(e.target.value)}
              placeholder="نص فرعي (اختياري)"
              className="input text-sm py-2"
            />
            <div className="flex gap-2">
              <button onClick={handleSave} className="btn-primary text-xs py-1.5 px-3">
                حفظ
              </button>
              <button onClick={() => setEditing(false)} className="btn-secondary text-xs py-1.5 px-3">
                إلغاء
              </button>
            </div>
          </div>
        ) : (
          <div>
            {banner.title && <p className="font-semibold text-gray-800 text-sm">{banner.title}</p>}
            {banner.subtitle && <p className="text-gray-500 text-xs">{banner.subtitle}</p>}
            {!banner.title && !banner.subtitle && (
              <p className="text-gray-400 text-xs italic">لا يوجد نص</p>
            )}
            <button
              onClick={() => setEditing(true)}
              className="text-xs text-primary-700 font-medium mt-1 hover:underline"
            >
              تعديل النص
            </button>
          </div>
        )}

        {/* Actions */}
        <div className="flex gap-2 pt-1">
          <button
            onClick={() => onToggle(banner.id)}
            className={`flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold transition-colors
              ${banner.is_active
                ? 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                : 'bg-green-50 text-green-700 hover:bg-green-100'
              }`}
          >
            {banner.is_active ? <EyeOff size={13} /> : <Eye size={13} />}
            {banner.is_active ? 'تعطيل' : 'تفعيل'}
          </button>
          <button
            onClick={() => onDelete(banner.id)}
            className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg text-xs font-semibold
                       bg-red-50 text-red-600 hover:bg-red-100 transition-colors"
          >
            <Trash2 size={13} />
            حذف
          </button>
        </div>
      </div>
    </div>
  );
}
