'use client';
import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { createProduct, fetchCategories } from '../../../../lib/api';
import type { Category } from '../../../../types';
import ProductForm from '../../../../components/products/ProductForm';
import toast from 'react-hot-toast';

export default function NewProductPage() {
  const router = useRouter();
  const [categories, setCategories] = useState<Category[]>([]);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    fetchCategories().then((res) => {
      if (res.data.success) setCategories(res.data.data);
    });
  }, []);

  const handleSubmit = async (data: Record<string, unknown>) => {
    setSubmitting(true);
    try {
      const res = await createProduct(data);
      if (res.data.success) {
        toast.success('تم إضافة المنتج بنجاح');
        // Redirect to edit page so admin can upload images
        router.push(`/dashboard/products/${res.data.data.id}/edit`);
      }
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || 'فشل إضافة المنتج';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center gap-3">
        <Link href="/dashboard/products" className="p-2 hover:bg-gray-100 rounded-lg">
          <ArrowRight size={20} />
        </Link>
        <h1 className="text-2xl font-bold text-gray-900">إضافة منتج جديد</h1>
      </div>

      <div className="card p-6">
        {categories.length === 0 ? (
          <div className="text-center py-8 text-gray-400">جاري تحميل الأقسام...</div>
        ) : (
          <ProductForm
            categories={categories}
            onSubmit={handleSubmit}
            submitting={submitting}
          />
        )}
      </div>
    </div>
  );
}
