'use client';
import { useState, useEffect, useCallback } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import {
  Plus, Search, Eye, EyeOff, Edit, Trash2, Star, RefreshCw,
} from 'lucide-react';
import {
  fetchAdminProducts, deleteProduct,
  toggleProductVisibility, toggleProductPopular,
} from '../../../lib/api';
import type { Product } from '../../../types';
import toast from 'react-hot-toast';

export default function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('');
  const [page, setPage] = useState(1);
  const [total, setTotal] = useState(0);
  const limit = 30;

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchAdminProducts({ page, limit, search: search || undefined, category: category || undefined });
      if (res.data.success) {
        setProducts(res.data.data);
        setTotal(res.data.meta?.total || 0);
      }
    } finally {
      setLoading(false);
    }
  }, [page, search, category]);

  useEffect(() => { load(); }, [load]);

  const handleDelete = async (id: string, name: string) => {
    if (!confirm(`هل أنت متأكد من حذف "${name}"؟`)) return;
    try {
      await deleteProduct(id);
      toast.success('تم حذف المنتج');
      load();
    } catch {
      toast.error('فشل حذف المنتج');
    }
  };

  const handleToggleVisibility = async (id: string) => {
    try {
      await toggleProductVisibility(id);
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, is_visible: !p.is_visible } : p))
      );
      toast.success('تم التحديث');
    } catch {
      toast.error('فشل التحديث');
    }
  };

  const handleTogglePopular = async (id: string) => {
    try {
      await toggleProductPopular(id);
      setProducts((prev) =>
        prev.map((p) => (p.id === id ? { ...p, is_popular: !p.is_popular } : p))
      );
      toast.success('تم التحديث');
    } catch {
      toast.error('فشل التحديث');
    }
  };

  return (
    <div className="space-y-5">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">المنتجات</h1>
          <p className="text-gray-500 text-sm">{total} منتج</p>
        </div>
        <div className="flex gap-2">
          <button onClick={load} className="btn-secondary">
            <RefreshCw size={16} className={loading ? 'animate-spin' : ''} />
          </button>
          <Link href="/dashboard/products/new" className="btn-primary">
            <Plus size={16} />
            منتج جديد
          </Link>
        </div>
      </div>

      {/* Filters */}
      <div className="card p-4 flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={16} className="absolute top-1/2 -translate-y-1/2 right-3 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => { setSearch(e.target.value); setPage(1); }}
            placeholder="بحث في المنتجات..."
            className="input pr-9"
          />
        </div>
        <select
          value={category}
          onChange={(e) => { setCategory(e.target.value); setPage(1); }}
          className="input w-auto min-w-[140px]"
        >
          <option value="">كل الأقسام</option>
          <option value="vegetables">خضار</option>
          <option value="fruits">فاكهة</option>
        </select>
      </div>

      {/* Products table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-100">
              <tr>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">المنتج</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600 hidden md:table-cell">القسم</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">السعر</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الوحدة</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">الحالة</th>
                <th className="text-right px-4 py-3 font-semibold text-gray-600">إجراءات</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-50">
              {loading ? (
                Array.from({ length: 10 }).map((_, i) => (
                  <tr key={i}>
                    {Array.from({ length: 6 }).map((_, j) => (
                      <td key={j} className="px-4 py-3">
                        <div className="skeleton h-4 rounded w-24" />
                      </td>
                    ))}
                  </tr>
                ))
              ) : products.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-4 py-12 text-center text-gray-400">
                    لا توجد منتجات
                  </td>
                </tr>
              ) : (
                products.map((product) => (
                  <tr key={product.id} className={`hover:bg-gray-50 transition-colors ${!product.is_visible ? 'opacity-50' : ''}`}>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 bg-gray-100 rounded-lg overflow-hidden flex-shrink-0">
                          {product.primary_image ? (
                            <Image
                              src={product.primary_image}
                              alt={product.name_ar}
                              width={40}
                              height={40}
                              className="object-cover w-full h-full"
                            />
                          ) : (
                            <div className="w-full h-full flex items-center justify-center text-gray-300 text-xs">
                              لا صورة
                            </div>
                          )}
                        </div>
                        <div>
                          <p className="font-semibold text-gray-900">{product.name_ar}</p>
                          <p className="text-gray-400 text-xs">{product.name}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-gray-600 hidden md:table-cell">
                      {product.category_name_ar}
                    </td>
                    <td className="px-4 py-3 font-bold text-primary-700">
                      {parseFloat(product.price) > 0
                        ? `${parseFloat(product.price).toFixed(2)} ج`
                        : <span className="text-gray-400 font-normal text-xs">غير محدد</span>
                      }
                    </td>
                    <td className="px-4 py-3 text-gray-600">{product.unit_ar}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <span className={`w-2 h-2 rounded-full ${product.is_visible ? 'bg-green-500' : 'bg-gray-300'}`} />
                        <span className="text-xs text-gray-500">
                          {product.is_visible ? 'ظاهر' : 'مخفي'}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => handleToggleVisibility(product.id)}
                          title={product.is_visible ? 'إخفاء' : 'إظهار'}
                          className="p-1.5 hover:bg-gray-100 rounded-lg text-gray-500 hover:text-gray-700 transition-colors"
                        >
                          {product.is_visible ? <Eye size={15} /> : <EyeOff size={15} />}
                        </button>
                        <button
                          onClick={() => handleTogglePopular(product.id)}
                          title={product.is_popular ? 'إزالة من الأكثر مبيعاً' : 'إضافة للأكثر مبيعاً'}
                          className={`p-1.5 hover:bg-gray-100 rounded-lg transition-colors
                            ${product.is_popular ? 'text-yellow-500' : 'text-gray-400 hover:text-gray-600'}`}
                        >
                          <Star size={15} fill={product.is_popular ? 'currentColor' : 'none'} />
                        </button>
                        <Link
                          href={`/dashboard/products/${product.id}/edit`}
                          className="p-1.5 hover:bg-blue-50 rounded-lg text-blue-500 hover:text-blue-700 transition-colors"
                        >
                          <Edit size={15} />
                        </Link>
                        <button
                          onClick={() => handleDelete(product.id, product.name_ar)}
                          className="p-1.5 hover:bg-red-50 rounded-lg text-red-400 hover:text-red-600 transition-colors"
                        >
                          <Trash2 size={15} />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>

        {/* Pagination */}
        {total > limit && (
          <div className="flex items-center justify-between px-4 py-3 border-t border-gray-100">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >السابق</button>
            <span className="text-sm text-gray-500">
              صفحة {page} من {Math.ceil(total / limit)}
            </span>
            <button
              onClick={() => setPage((p) => p + 1)}
              disabled={page * limit >= total}
              className="btn-secondary text-sm py-1.5 disabled:opacity-40"
            >التالي</button>
          </div>
        )}
      </div>
    </div>
  );
}
