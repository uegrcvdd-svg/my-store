'use client';
import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { fetchAdminProduct, fetchCategories, updateProduct } from '../../../../../lib/api';
import type { Product, Category } from '../../../../../types';
import ProductForm from '../../../../../components/products/ProductForm';
import toast from 'react-hot-toast';

export default function EditProductPage() {
  const { id } = useParams<{ id: string }>();
  const router = useRouter();
  const [product, setProduct] = useState<Product | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    Promise.all([
      fetchAdminProduct(id),
      fetchCategories(),
    ]).then(([productRes, catRes]) => {
      if (productRes.data.success) setProduct(productRes.data.data);
      if (catRes.data.success) setCategories(catRes.data.data);
    }).finally(() => setLoading(false));
  }, [id]);

  const handleSubmit = async (data: Record<string, unknown>) => {
    setSubmitting(true);
    try {
      const res = await updateProduct(id, data);
      if (res.data.success) {
        setProduct(res.data.data);
        toast.success('تم حفظ التعديلات بنجاح');
      }
    } catch (err: any) {
      const msg = err?.response?.data?.error?.message || 'فشل حفظ التعديلات';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  if (loading) {
    return (
      <div className="max-w-3xl space-y-4">
        <div className="skeleton h-8 w-48 rounded" />
        <div className="card p-6 space-y-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="skeleton h-10 rounded-lg" />
          ))}
        </div>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="text-center py-12">
        <p className="text-gray-500 mb-4">المنتج غير موجود</p>
        <Link href="/dashboard/products" className="btn-primary inline-flex">
          العودة للمنتجات
        </Link>
      </div>
    );
  }

  return (
    <div className="space-y-5 max-w-3xl">
      <div className="flex items-center gap-3">
        <Link href="/dashboard/products" className="p-2 hover:bg-gray-100 rounded-lg">
          <ArrowRight size={20} />
        </Link>
        <div>
          <h1 className="text-2xl font-bold text-gray-900">تعديل منتج</h1>
          <p className="text-gray-500 text-sm">{product.name_ar}</p>
        </div>
      </div>

      <div className="card p-6">
        <ProductForm
          product={product}
          categories={categories}
          onSubmit={handleSubmit}
          submitting={submitting}
        />
      </div>
    </div>
  );
}
