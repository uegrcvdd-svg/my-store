'use client';
import { useState, useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import {
  LayoutDashboard, ShoppingBag, Package, Tag, Users, Share2,
  Settings, LogOut, Menu, X, Activity, ChevronLeft,
} from 'lucide-react';
import { getMe, logout } from '../../lib/api';

const navItems = [
  { href: '/dashboard', label: 'لوحة التحكم', icon: LayoutDashboard },
  { href: '/dashboard/orders', label: 'الطلبات', icon: ShoppingBag },
  { href: '/dashboard/products', label: 'المنتجات', icon: Package },
  { href: '/dashboard/prices', label: 'إدارة الأسعار', icon: Tag },
  { href: '/dashboard/banners', label: 'البانرات', icon: Share2 },
  { href: '/dashboard/activity', label: 'سجل النشاط', icon: Activity },
  { href: '/dashboard/settings', label: 'الإعدادات', icon: Settings },
];

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const [username, setUsername] = useState('');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);

  useEffect(() => {
    getMe()
      .then((r) => setUsername(r.data.data.username))
      .catch(() => router.replace('/login'));
  }, []);

  const handleLogout = async () => {
    setLoggingOut(true);
    try {
      await logout();
      router.replace('/login');
    } finally {
      setLoggingOut(false);
    }
  };

  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-5 py-5 border-b border-white/10">
        <Image src="/logo.png" alt="طابع" width={50} height={34} className="h-9 w-auto brightness-0 invert" />
        <div>
          <p className="text-white font-bold text-sm">طابع</p>
          <p className="text-white/50 text-xs">لوحة التحكم</p>
        </div>
      </div>

      {/* Navigation */}
      <nav className="flex-1 px-3 py-4 space-y-1 overflow-y-auto">
        {navItems.map(({ href, label, icon: Icon }) => {
          const isActive = pathname === href || (href !== '/dashboard' && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              onClick={() => setSidebarOpen(false)}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm font-medium
                ${isActive
                  ? 'bg-white/20 text-white'
                  : 'text-white/60 hover:bg-white/10 hover:text-white'
                }`}
            >
              <Icon size={18} />
              {label}
              {isActive && <ChevronLeft size={14} className="mr-auto" />}
            </Link>
          );
        })}
      </nav>

      {/* User & Logout */}
      <div className="border-t border-white/10 px-4 py-4">
        <div className="flex items-center gap-3 mb-3">
          <div className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
            <span className="text-white font-bold text-sm">{username[0]?.toUpperCase()}</span>
          </div>
          <div>
            <p className="text-white text-sm font-semibold">{username}</p>
            <p className="text-white/50 text-xs">مدير النظام</p>
          </div>
        </div>
        <button
          onClick={handleLogout}
          disabled={loggingOut}
          className="w-full flex items-center gap-2 px-3 py-2 text-white/60 hover:text-white
                     hover:bg-white/10 rounded-lg transition-colors text-sm"
        >
          <LogOut size={16} />
          {loggingOut ? 'جاري الخروج...' : 'تسجيل الخروج'}
        </button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      {/* Desktop sidebar */}
      <aside className="hidden lg:flex w-60 bg-sidebar flex-col flex-shrink-0">
        <SidebarContent />
      </aside>

      {/* Mobile sidebar overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div className="absolute inset-0 bg-black/50" onClick={() => setSidebarOpen(false)} />
          <div className="absolute right-0 top-0 h-full w-60 bg-sidebar z-10">
            <SidebarContent />
          </div>
        </div>
      )}

      {/* Main content */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 flex items-center justify-between px-4 h-14 flex-shrink-0">
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg hover:bg-gray-100"
          >
            <Menu size={20} />
          </button>

          <div className="flex items-center gap-2 mr-auto">
            <span className="text-sm text-gray-500 hidden sm:inline">مرحباً،</span>
            <span className="text-sm font-semibold text-gray-800">{username}</span>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
