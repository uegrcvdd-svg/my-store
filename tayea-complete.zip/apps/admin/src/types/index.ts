export interface Admin {
  id: string;
  username: string;
}

export interface Product {
  id: string;
  category_id: string;
  category_name_ar: string;
  category_slug: string;
  name: string;
  name_ar: string;
  description: string | null;
  unit: string;
  unit_ar: string;
  price: string;
  display_order: number;
  is_visible: boolean;
  is_popular: boolean;
  created_at: string;
  updated_at: string;
  images: ProductImage[];
  primary_image: string | null;
}

export interface ProductImage {
  id: string;
  image_url: string;
  storage_key: string;
  is_primary: boolean;
  sort_order: number;
}

export interface Category {
  id: string;
  name: string;
  name_ar: string;
  slug: string;
}

export interface Order {
  id: string;
  order_number: number;
  customer_name: string;
  phone_primary: string;
  phone_secondary: string | null;
  address_text: string;
  gps_lat: string | null;
  gps_lng: string | null;
  maps_link: string | null;
  landmark: string | null;
  notes: string | null;
  status: OrderStatus;
  grand_total: string;
  ordered_at: string;
  updated_at: string;
  items?: OrderItem[];
  item_count?: string;
}

export type OrderStatus = 'new' | 'confirmed' | 'prepared' | 'in_delivery' | 'delivered' | 'cancelled';

export interface OrderItem {
  id: string;
  product_name_ar: string;
  quantity: string;
  unit_ar: string;
  price_per_unit: string;
  item_total: string;
}

export interface Banner {
  id: string;
  image_url: string;
  title: string | null;
  subtitle: string | null;
  link_url: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
}

export interface Setting {
  key: string;
  value: string | null;
  label: string | null;
}

export interface ActivityLog {
  id: string;
  action: string;
  entity_type: string | null;
  description: string | null;
  metadata: unknown;
  ip_address: string | null;
  created_at: string;
  username: string | null;
}

export interface DashboardStats {
  total_sales_today: string;
  total_sales_all: string;
  orders_today: string;
  orders_total: string;
  customers_total: string;
  new_orders: string;
  total_sales_yesterday: string;
  orders_yesterday: string;
}

export interface ApiResponse<T> {
  success: boolean;
  message: string;
  data: T;
  meta?: {
    page: number;
    limit: number;
    total: number;
    hasMore: boolean;
    totalPages: number;
  };
  error?: {
    code: string;
    message: string;
  };
}

export const STATUS_LABELS: Record<OrderStatus, string> = {
  new: 'جديد',
  confirmed: 'تم التأكيد',
  prepared: 'تم التجهيز بنجاح',
  in_delivery: 'قيد التوصيل',
  delivered: 'تم التوصيل',
  cancelled: 'ملغي',
};

export const STATUS_COLORS: Record<OrderStatus, string> = {
  new: 'bg-blue-100 text-blue-700',
  confirmed: 'bg-yellow-100 text-yellow-700',
  prepared: 'bg-purple-100 text-purple-700',
  in_delivery: 'bg-orange-100 text-orange-700',
  delivered: 'bg-green-100 text-green-700',
  cancelled: 'bg-gray-100 text-gray-500',
};
