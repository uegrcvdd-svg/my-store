import axios from 'axios';
import type {
  ApiResponse, Product, Order, Banner, Setting, DashboardStats, ActivityLog, Category
} from '../types';

const api = axios.create({
  baseURL: process.env.NEXT_PUBLIC_API_URL || 'http://localhost:4000/api',
  withCredentials: true,
  timeout: 15000,
});

// Redirect to login on 401
api.interceptors.response.use(
  (r) => r,
  (err) => {
    if (err.response?.status === 401 && typeof window !== 'undefined') {
      window.location.href = '/login';
    }
    return Promise.reject(err);
  }
);

// AUTH
export const login = (username: string, password: string) =>
  api.post<ApiResponse<{ id: string; username: string }>>('/admin/auth/login', { username, password });

export const logout = () => api.post('/admin/auth/logout');

export const getMe = () =>
  api.get<ApiResponse<{ id: string; username: string }>>('/admin/auth/me');

// DASHBOARD
export const fetchDashboardStats = () =>
  api.get<ApiResponse<DashboardStats>>('/admin/orders/stats');

export const fetchRecentOrders = () =>
  api.get<ApiResponse<Order[]>>('/admin/orders/recent');

// PRODUCTS
export const fetchAdminProducts = (params?: { page?: number; limit?: number; search?: string; category?: string }) =>
  api.get<ApiResponse<Product[]>>('/admin/products', { params });

export const fetchAdminProduct = (id: string) =>
  api.get<ApiResponse<Product>>(`/admin/products/${id}`);

export const createProduct = (data: FormData | object) =>
  api.post<ApiResponse<Product>>('/admin/products', data);

export const updateProduct = (id: string, data: object) =>
  api.patch<ApiResponse<Product>>(`/admin/products/${id}`, data);

export const deleteProduct = (id: string) =>
  api.delete(`/admin/products/${id}`);

export const toggleProductVisibility = (id: string) =>
  api.patch(`/admin/products/${id}/visibility`);

export const toggleProductPopular = (id: string) =>
  api.patch(`/admin/products/${id}/popular`);

export const reorderProducts = (items: { id: string; display_order: number }[]) =>
  api.patch('/admin/products/reorder', { items });

export const uploadProductImage = (productId: string, formData: FormData) =>
  api.post(`/admin/products/${productId}/images`, formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

export const setPrimaryImage = (productId: string, imageId: string) =>
  api.patch(`/admin/products/${productId}/images/${imageId}/primary`);

export const deleteProductImage = (productId: string, imageId: string) =>
  api.delete(`/admin/products/${productId}/images/${imageId}`);

// ORDERS
export const fetchAdminOrders = (params?: { page?: number; limit?: number; search?: string; status?: string }) =>
  api.get<ApiResponse<Order[]>>('/admin/orders', { params });

export const fetchAdminOrder = (id: string) =>
  api.get<ApiResponse<Order>>(`/admin/orders/${id}`);

export const updateOrderStatus = (id: string, status: string) =>
  api.patch(`/admin/orders/${id}/status`, { status });

export const getOrderShareMessage = (id: string) =>
  api.get<ApiResponse<{ message: string }>>(`/admin/orders/${id}/share`);

// BANNERS
export const fetchAdminBanners = () =>
  api.get<ApiResponse<Banner[]>>('/admin/banners');

export const createBanner = (formData: FormData) =>
  api.post<ApiResponse<Banner>>('/admin/banners', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });

export const updateBanner = (id: string, data: object) =>
  api.patch<ApiResponse<Banner>>(`/admin/banners/${id}`, data);

export const toggleBanner = (id: string) =>
  api.patch(`/admin/banners/${id}/toggle`);

export const deleteBanner = (id: string) =>
  api.delete(`/admin/banners/${id}`);

export const reorderBanners = (items: { id: string; display_order: number }[]) =>
  api.patch('/admin/banners/reorder', { items });

// PRICES
export const fetchPrices = () =>
  api.get<ApiResponse<Product[]>>('/admin/prices');

export const updatePrice = (id: string, price: number) =>
  api.patch(`/admin/prices/${id}`, { price });

export const bulkUpdatePrices = (items: { id: string; price: number }[]) =>
  api.patch('/admin/prices/bulk', { items });

// SETTINGS
export const fetchAdminSettings = () =>
  api.get<ApiResponse<Setting[]>>('/admin/settings');

export const updateSettings = (data: Record<string, string>) =>
  api.patch('/admin/settings', data);

// CATEGORIES
export const fetchCategories = () =>
  api.get<ApiResponse<Category[]>>('/categories');

// ACTIVITY
export const fetchActivity = (page = 1, limit = 50) =>
  api.get<ApiResponse<ActivityLog[]>>('/admin/activity', { params: { page, limit } });

export default api;
