import type { Order } from '../types';
import { STATUS_LABELS } from '../types';

export function formatDriverMessage(order: Order): string {
  const lines: string[] = [];

  lines.push('🛒 طلب جديد من طابع');
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`🔢 رقم الطلب: #${order.order_number}`);
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`👤 العميل: ${order.customer_name}`);
  lines.push(`📞 الهاتف: ${order.phone_primary}`);

  if (order.phone_secondary) {
    lines.push(`📞 هاتف إضافي: ${order.phone_secondary}`);
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push('🛍 المنتجات:');

  if (order.items) {
    for (const item of order.items) {
      const qty = Number(item.quantity);
      const price = Number(item.price_per_unit).toFixed(2);
      const total = Number(item.item_total).toFixed(2);
      lines.push(`• ${item.product_name_ar} × ${qty} ${item.unit_ar} @ ${price} ج = ${total} ج`);
    }
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`💰 الإجمالي: ${Number(order.grand_total).toFixed(2)} جنيه`);
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push('📍 الموقع:');

  if (order.maps_link) {
    lines.push(order.maps_link);
  } else {
    lines.push(order.address_text);
  }

  if (order.landmark) lines.push(`🏛 علامة مميزة: ${order.landmark}`);
  if (order.notes) lines.push(`📝 ملاحظات: ${order.notes}`);

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`📌 الحالة: ${STATUS_LABELS[order.status]}`);

  return lines.join('\n');
}
