# Public Assets

Place the following files in this directory:

- `logo.png` — Official Tayea logo (exact, unmodified)
