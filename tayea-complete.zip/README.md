# طابع — Tayea 🥦🍎
### منصة بيع الخضار والفاكهة الطازجة — محافظة قنا، مصر

Production-grade e-commerce platform for fresh vegetables and fruits delivery within Qena Governorate, Egypt.

---

## 🏗️ Architecture

| Component | Technology | Port |
|-----------|-----------|------|
| Customer Website | Next.js 14 + TypeScript + Tailwind | 3000 |
| Admin Dashboard | Next.js 14 + TypeScript + Tailwind | 3001 |
| Backend API | Node.js + Express.js + TypeScript | 4000 |
| Database | PostgreSQL 16 | 5432 |
| Storage | Supabase Storage | — |
| Reverse Proxy | Nginx | 80/443 |

---

## 📋 Prerequisites

- Node.js 20+
- PostgreSQL 16+
- Docker & Docker Compose (optional)
- Supabase account (for image storage)
- Google Maps API key

---

## ⚡ Quick Start (Development)

### 1. Clone and install

```bash
git clone <repo-url>
cd tayea

# Install server dependencies
cd server && npm install && cd ..

# Install web dependencies
cd apps/web && npm install && cd ../..

# Install admin dependencies
cd apps/admin && npm install && cd ../..
```

### 2. Configure environment

```bash
# Server
cp server/.env.example server/.env
# Edit server/.env with your values

# Web
cp apps/web/.env.example apps/web/.env.local
# Edit apps/web/.env.local

# Admin
cp apps/admin/.env.example apps/admin/.env.local
# Edit apps/admin/.env.local
```

### 3. Set up database

```bash
cd server

# Run migrations
npm run migrate

# Seed initial data (categories, 148 products, default admin)
npm run seed
```

> **⚠️ Default Admin Credentials:**
> - Username: `admin`
> - Password: `Tayea@Admin2024!`
> - **Change this immediately after first login!**

### 4. Start all services

```bash
# Terminal 1 — Backend API
cd server && npm run dev

# Terminal 2 — Customer Website
cd apps/web && npm run dev

# Terminal 3 — Admin Dashboard
cd apps/admin && npm run dev
```

**Access:**
- Customer site: http://localhost:3000
- Admin dashboard: http://localhost:3001
- API: http://localhost:4000

---

## 🐳 Docker (Recommended for Production)

### Development with Docker

```bash
# Copy env file
cp server/.env.example .env
# Edit .env with your values

# Start all services
docker-compose up -d

# Run migrations
docker-compose exec server npm run migrate

# Seed database
docker-compose exec server npm run seed
```

### Production Deployment

```bash
# Configure production env
cp server/.env.example .env.prod
# Fill all values in .env.prod

# Deploy
docker-compose -f docker-compose.prod.yml --env-file .env.prod up -d

# Run migrations on production
docker-compose -f docker-compose.prod.yml exec server npm run migrate

# Seed (first deployment only)
docker-compose -f docker-compose.prod.yml exec server npm run seed
```

---

## 🔧 Environment Variables

### Server (`server/.env`)

| Variable | Description | Required |
|----------|-------------|----------|
| `NODE_ENV` | `development` or `production` | ✅ |
| `PORT` | Server port (default: 4000) | ✅ |
| `DATABASE_URL` | PostgreSQL connection string | ✅ |
| `SESSION_SECRET` | 64-byte random hex string | ✅ |
| `SUPABASE_URL` | Supabase project URL | ✅ |
| `SUPABASE_SERVICE_KEY` | Supabase service role key | ✅ |
| `SUPABASE_BUCKET_PRODUCTS` | Bucket name for product images | ✅ |
| `SUPABASE_BUCKET_BANNERS` | Bucket name for banners | ✅ |
| `FRONTEND_URL` | Customer website URL (for CORS) | ✅ |
| `ADMIN_URL` | Admin dashboard URL (for CORS) | ✅ |

### Web App (`apps/web/.env.local`)

| Variable | Description | Required |
|----------|-------------|----------|
| `NEXT_PUBLIC_API_URL` | Backend API URL | ✅ |
| `NEXT_PUBLIC_GOOGLE_MAPS_API_KEY` | Google Maps API key | ✅ |
| `NEXT_PUBLIC_WHATSAPP_NUMBER` | WhatsApp number (no +) | ✅ |

---

## 📦 Supabase Storage Setup

1. Create a Supabase project at https://supabase.com
2. Go to **Storage** → Create two buckets:
   - `products` — for product images (public)
   - `banners` — for homepage banners (public)
3. Set both buckets to **Public** access
4. Copy the project URL and service role key to your `.env`

---

## 🗃️ Database Schema

| Table | Description |
|-------|-------------|
| `admins` | Admin accounts (Argon2id passwords) |
| `categories` | Product categories (vegetables, fruits) |
| `products` | All products with prices |
| `product_images` | Multiple images per product |
| `homepage_banners` | Slider banner images |
| `orders` | Customer orders |
| `order_items` | Items within each order (price snapshot) |
| `settings` | Store configuration key-value pairs |
| `activity_logs` | Admin action audit trail |
| `user_sessions` | PostgreSQL session store |

---

## 🔐 Security Features

- **Argon2id** password hashing
- **HttpOnly + Secure + SameSite** session cookies
- **Helmet.js** security headers (CSP, HSTS, etc.)
- **Rate limiting** on all endpoints (stricter on login/orders)
- **Input validation** via Zod on every endpoint
- **Parameterized SQL** — zero string interpolation
- **CORS** restricted to allowed origins only
- **File type validation** — only JPG/PNG/WEBP accepted
- **Image compression** via Sharp before upload
- **Activity logging** for all admin actions
- GPS coordinates validated to **Qena Governorate bounds** only

---

## 📡 API Endpoints

### Public (Customer)
```
GET  /api/products          — List products (paginated)
GET  /api/products/popular  — Popular products
GET  /api/products/search   — Search products
GET  /api/products/:id      — Product detail
GET  /api/categories        — All categories
GET  /api/banners           — Active banners
GET  /api/settings/public   — Public store settings
POST /api/orders            — Submit order
```

### Admin (Protected — requires session)
```
POST   /api/admin/auth/login             — Login
POST   /api/admin/auth/logout            — Logout
GET    /api/admin/orders                 — List orders
PATCH  /api/admin/orders/:id/status      — Update order status
GET    /api/admin/orders/:id/share       — Get driver share message
GET    /api/admin/products               — List all products
POST   /api/admin/products               — Create product
PATCH  /api/admin/products/:id           — Update product
DELETE /api/admin/products/:id           — Delete product
PATCH  /api/admin/products/:id/visibility — Toggle visibility
POST   /api/admin/products/:id/images    — Upload image
GET    /api/admin/prices                 — All products with prices
PATCH  /api/admin/prices/:id             — Update single price
PATCH  /api/admin/prices/bulk            — Bulk price update
GET    /api/admin/banners                — All banners
POST   /api/admin/banners                — Upload new banner
DELETE /api/admin/banners/:id            — Delete banner
GET    /api/admin/settings               — Store settings
PATCH  /api/admin/settings               — Update settings
GET    /api/admin/activity               — Activity log
```

---

## 🏪 Business Rules

- Delivery operates **only within Qena Governorate** — GPS coordinates are validated against Qena's geographic bounds
- **No delivery fee** calculated by website — driver determines cost manually
- **No inventory/stock** system — all products always available
- Order numbers start at **#1001**
- Product prices set to **0.00** by default — admin sets prices before launch
- **Historical orders preserve** price snapshots even after price changes
- WhatsApp contact button uses number: **+20 100 872 1996**

---

## 🚀 Deployment Checklist

Before going live:

- [ ] Change default admin password
- [ ] Set all prices in Price Management page
- [ ] Upload product images
- [ ] Add homepage banners
- [ ] Configure store settings (name, phone, hours)
- [ ] Set `SESSION_SECRET` to a real 64-byte random string
- [ ] Configure Supabase storage buckets as public
- [ ] Set Google Maps API key
- [ ] Configure CORS with your actual domain names
- [ ] Set up SSL/TLS certificate (Let's Encrypt recommended)
- [ ] Enable database backups on your PostgreSQL provider
- [ ] Test order flow end-to-end

---

## 📞 Support

WhatsApp: **+20 100 872 1996**

---

© طابع 2024 — جميع الحقوق محفوظة
