import { describe, it, expect } from 'vitest';
import { formatOrderShareMessage } from '../src/utils/orderFormatter';

describe('Order Formatter', () => {
  const baseOrder = {
    order_number: 1025,
    customer_name: 'أحمد محمد',
    phone_primary: '01012345678',
    phone_secondary: null,
    address_text: 'قنا، شارع النصر',
    landmark: null,
    notes: null,
    maps_link: 'https://maps.google.com/?q=26.165,32.716',
    gps_lat: 26.165,
    gps_lng: 32.716,
    grand_total: '49.00',
    status: 'new',
    items: [
      {
        product_name_ar: 'طماطم',
        quantity: 2,
        unit_ar: 'كيلو',
        price_per_unit: 12.00,
        item_total: 24.00,
      },
      {
        product_name_ar: 'بطاطس',
        quantity: 1,
        unit_ar: 'كيلو',
        price_per_unit: 10.00,
        item_total: 10.00,
      },
    ],
  };

  it('includes order number', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('#1025');
  });

  it('includes customer name', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('أحمد محمد');
  });

  it('includes primary phone', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('01012345678');
  });

  it('includes all product names', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('طماطم');
    expect(msg).toContain('بطاطس');
  });

  it('includes grand total', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('49.00');
  });

  it('includes maps link', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('maps.google.com');
  });

  it('includes status label', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).toContain('جديد');
  });

  it('includes secondary phone when provided', () => {
    const order = { ...baseOrder, phone_secondary: '01198765432' };
    const msg = formatOrderShareMessage(order);
    expect(msg).toContain('01198765432');
  });

  it('omits secondary phone when null', () => {
    const msg = formatOrderShareMessage(baseOrder);
    expect(msg).not.toContain('هاتف إضافي');
  });

  it('includes landmark when provided', () => {
    const order = { ...baseOrder, landmark: 'أمام المسجد' };
    const msg = formatOrderShareMessage(order);
    expect(msg).toContain('أمام المسجد');
  });

  it('includes notes when provided', () => {
    const order = { ...baseOrder, notes: 'يرجى الاتصال قبل الوصول' };
    const msg = formatOrderShareMessage(order);
    expect(msg).toContain('يرجى الاتصال قبل الوصول');
  });

  it('produces readable multiline message', () => {
    const msg = formatOrderShareMessage(baseOrder);
    const lines = msg.split('\n');
    expect(lines.length).toBeGreaterThan(5);
  });
});
