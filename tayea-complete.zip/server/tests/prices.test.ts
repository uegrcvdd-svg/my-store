import { describe, it, expect } from 'vitest';
import supertest from 'supertest';
import app from '../src/app';

const request = supertest(app);

describe('Prices API (protected)', () => {
  describe('GET /api/admin/prices', () => {
    it('blocks unauthenticated access', async () => {
      const res = await request.get('/api/admin/prices');
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/admin/prices/:id', () => {
    it('blocks unauthenticated price update', async () => {
      const res = await request
        .patch('/api/admin/prices/00000000-0000-0000-0000-000000000001')
        .send({ price: 15.00 });
      expect(res.status).toBe(401);
    });
  });

  describe('PATCH /api/admin/prices/bulk', () => {
    it('blocks unauthenticated bulk update', async () => {
      const res = await request
        .patch('/api/admin/prices/bulk')
        .send({ items: [{ id: '00000000-0000-0000-0000-000000000001', price: 10 }] });
      expect(res.status).toBe(401);
    });
  });
});
