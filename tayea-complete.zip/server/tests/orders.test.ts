import { describe, it, expect } from 'vitest';
import supertest from 'supertest';
import app from '../src/app';

const request = supertest(app);

describe('Orders API', () => {
  describe('POST /api/orders - Validation', () => {
    it('rejects empty body', async () => {
      const res = await request.post('/api/orders').send({});
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
      expect(res.body.error.code).toBe('VALIDATION_ERROR');
    });

    it('rejects invalid Egyptian phone number', async () => {
      const res = await request.post('/api/orders').send({
        customer_name: 'أحمد محمد',
        phone_primary: '123456789',   // invalid
        address_text: 'قنا، شارع النصر',
        items: [{ product_id: '00000000-0000-0000-0000-000000000001', quantity: 1 }],
      });
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it('rejects GPS coordinates outside Qena', async () => {
      const res = await request.post('/api/orders').send({
        customer_name: 'أحمد محمد',
        phone_primary: '01012345678',
        address_text: 'القاهرة',
        gps_lat: 30.0444,    // Cairo — outside Qena bounds
        gps_lng: 31.2357,
        items: [{ product_id: '00000000-0000-0000-0000-000000000001', quantity: 1 }],
      });
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it('rejects empty items array', async () => {
      const res = await request.post('/api/orders').send({
        customer_name: 'أحمد محمد',
        phone_primary: '01012345678',
        address_text: 'قنا، شارع النصر',
        items: [],
      });
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it('rejects negative quantity', async () => {
      const res = await request.post('/api/orders').send({
        customer_name: 'أحمد محمد',
        phone_primary: '01012345678',
        address_text: 'قنا',
        items: [{ product_id: '00000000-0000-0000-0000-000000000001', quantity: -1 }],
      });
      expect(res.status).toBe(400);
    });

    it('rejects short customer name', async () => {
      const res = await request.post('/api/orders').send({
        customer_name: 'أ',   // too short
        phone_primary: '01012345678',
        address_text: 'قنا',
        items: [{ product_id: '00000000-0000-0000-0000-000000000001', quantity: 1 }],
      });
      expect(res.status).toBe(400);
    });

    it('accepts valid secondary phone', async () => {
      // Should not fail on validation (may fail on product lookup which is expected)
      const res = await request.post('/api/orders').send({
        customer_name: 'أحمد محمد',
        phone_primary: '01012345678',
        phone_secondary: '01198765432',
        address_text: 'قنا، شارع النصر',
        items: [{ product_id: '00000000-0000-0000-0000-000000000001', quantity: 1 }],
      });
      // Will get 400 (product not found) or 201 — not a validation error
      expect([201, 400, 500]).toContain(res.status);
      if (res.status === 400) {
        // Should not be a phone validation error
        expect(res.body.error?.code).not.toBe('VALIDATION_ERROR');
      }
    });
  });

  describe('Rate limiting on orders', () => {
    it('has rate limiting headers', async () => {
      const res = await request.post('/api/orders').send({});
      expect(res.headers['ratelimit-limit'] || res.headers['x-ratelimit-limit']).toBeDefined();
    });
  });
});
