import { describe, it, expect, beforeAll } from 'vitest';
import supertest from 'supertest';
import app from '../src/app';

const request = supertest(app);

describe('Authentication', () => {
  describe('POST /api/admin/auth/login', () => {
    it('rejects missing credentials', async () => {
      const res = await request.post('/api/admin/auth/login').send({});
      expect(res.status).toBe(400);
      expect(res.body.success).toBe(false);
    });

    it('rejects wrong password', async () => {
      const res = await request.post('/api/admin/auth/login').send({
        username: 'admin',
        password: 'wrongpassword',
      });
      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
    });

    it('rejects non-existent user', async () => {
      const res = await request.post('/api/admin/auth/login').send({
        username: 'nonexistent_user_xyz',
        password: 'anypassword',
      });
      expect(res.status).toBe(401);
      expect(res.body.success).toBe(false);
    });

    it('returns 401 without session on protected routes', async () => {
      const res = await request.get('/api/admin/products');
      expect(res.status).toBe(401);
    });
  });

  describe('GET /health', () => {
    it('returns 200 OK', async () => {
      const res = await request.get('/health');
      expect(res.status).toBe(200);
      expect(res.body.status).toBe('ok');
    });
  });
});
