import { describe, it, expect } from 'vitest';
import supertest from 'supertest';
import app from '../src/app';

const request = supertest(app);

describe('Public Products API', () => {
  describe('GET /api/products', () => {
    it('returns paginated product list', async () => {
      const res = await request.get('/api/products');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.data)).toBe(true);
      expect(res.body.meta).toBeDefined();
      expect(res.body.meta).toHaveProperty('page');
      expect(res.body.meta).toHaveProperty('total');
    });

    it('filters by category slug', async () => {
      const res = await request.get('/api/products?category=vegetables');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      if (res.body.data.length > 0) {
        expect(res.body.data[0].category_slug).toBe('vegetables');
      }
    });

    it('supports search query', async () => {
      const res = await request.get('/api/products?search=طماطم');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
    });

    it('respects pagination params', async () => {
      const res = await request.get('/api/products?page=1&limit=5');
      expect(res.status).toBe(200);
      expect(res.body.data.length).toBeLessThanOrEqual(5);
    });
  });

  describe('GET /api/products/popular', () => {
    it('returns popular products', async () => {
      const res = await request.get('/api/products/popular');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.data)).toBe(true);
    });
  });

  describe('GET /api/products/:id', () => {
    it('returns 404 for non-existent product', async () => {
      const res = await request.get('/api/products/00000000-0000-0000-0000-000000000000');
      expect(res.status).toBe(404);
    });

    it('returns 404 for invalid UUID', async () => {
      const res = await request.get('/api/products/not-a-uuid');
      expect([400, 404, 500]).toContain(res.status);
    });
  });

  describe('GET /api/categories', () => {
    it('returns categories list', async () => {
      const res = await request.get('/api/categories');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.data)).toBe(true);
      // Should have exactly vegetables and fruits
      expect(res.body.data.length).toBeGreaterThanOrEqual(2);
    });
  });

  describe('GET /api/banners', () => {
    it('returns banners list', async () => {
      const res = await request.get('/api/banners');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(Array.isArray(res.body.data)).toBe(true);
    });
  });

  describe('GET /api/settings/public', () => {
    it('returns public settings', async () => {
      const res = await request.get('/api/settings/public');
      expect(res.status).toBe(200);
      expect(res.body.success).toBe(true);
      expect(res.body.data).toHaveProperty('store_name');
      expect(res.body.data).toHaveProperty('whatsapp_number');
    });
  });
});

describe('Admin Products API (protected)', () => {
  it('blocks unauthenticated access', async () => {
    const res = await request.get('/api/admin/products');
    expect(res.status).toBe(401);
  });

  it('blocks unauthenticated product creation', async () => {
    const res = await request.post('/api/admin/products').send({
      name: 'Test',
      name_ar: 'اختبار',
    });
    expect(res.status).toBe(401);
  });
});
