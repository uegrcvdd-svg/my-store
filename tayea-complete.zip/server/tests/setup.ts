import 'dotenv/config';

// Use a test database URL if provided
if (process.env.DATABASE_URL_TEST) {
  process.env.DATABASE_URL = process.env.DATABASE_URL_TEST;
}

process.env.NODE_ENV = 'test';
process.env.SESSION_SECRET = 'test_session_secret_64chars_long_string_for_testing_only_replace';
process.env.PORT = '4001';
