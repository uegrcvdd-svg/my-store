import { describe, it, expect } from 'vitest';
import { createOrderSchema } from '../src/validators/orders.validator';
import { createProductSchema } from '../src/validators/products.validator';
import { loginSchema } from '../src/validators/auth.validator';

describe('Order Validator', () => {
  const validOrder = {
    customer_name: 'أحمد محمد علي',
    phone_primary: '01012345678',
    address_text: 'قنا، شارع النصر',
    items: [{ product_id: '550e8400-e29b-41d4-a716-446655440000', quantity: 2 }],
  };

  it('accepts valid order', () => {
    const result = createOrderSchema.safeParse(validOrder);
    expect(result.success).toBe(true);
  });

  it('rejects order with invalid phone prefix', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      phone_primary: '09012345678',
    });
    expect(result.success).toBe(false);
  });

  it('rejects all invalid Egyptian phone formats', () => {
    const invalidPhones = [
      '00201012345678',  // international format
      '201012345678',    // missing leading 0
      '0101234567',      // too short
      '010123456789',    // too long
      '01312345678',     // invalid prefix (013)
      'abcdefghijk',     // non-numeric
    ];

    for (const phone of invalidPhones) {
      const result = createOrderSchema.safeParse({ ...validOrder, phone_primary: phone });
      expect(result.success).toBe(false);
    }
  });

  it('accepts all valid Egyptian phone prefixes', () => {
    const validPhones = ['01012345678', '01112345678', '01212345678', '01512345678'];
    for (const phone of validPhones) {
      const result = createOrderSchema.safeParse({ ...validOrder, phone_primary: phone });
      expect(result.success).toBe(true);
    }
  });

  it('rejects GPS coords outside Qena', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      gps_lat: 30.0,   // Cairo
      gps_lng: 31.2,
    });
    expect(result.success).toBe(false);
  });

  it('accepts GPS coords inside Qena', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      gps_lat: 26.165,
      gps_lng: 32.716,
    });
    expect(result.success).toBe(true);
  });

  it('requires at least one item', () => {
    const result = createOrderSchema.safeParse({ ...validOrder, items: [] });
    expect(result.success).toBe(false);
  });

  it('rejects zero quantity', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      items: [{ product_id: '550e8400-e29b-41d4-a716-446655440000', quantity: 0 }],
    });
    expect(result.success).toBe(false);
  });

  it('optional phone_secondary passes when valid', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      phone_secondary: '01512345678',
    });
    expect(result.success).toBe(true);
  });

  it('optional phone_secondary fails when invalid', () => {
    const result = createOrderSchema.safeParse({
      ...validOrder,
      phone_secondary: '123',
    });
    expect(result.success).toBe(false);
  });
});

describe('Product Validator', () => {
  const validProduct = {
    category_id: '550e8400-e29b-41d4-a716-446655440000',
    name: 'Tomatoes',
    name_ar: 'طماطم',
    unit: 'kg' as const,
    price: 12.5,
  };

  it('accepts valid product', () => {
    const result = createProductSchema.safeParse(validProduct);
    expect(result.success).toBe(true);
  });

  it('adds unit_ar via transform', () => {
    const result = createProductSchema.safeParse(validProduct);
    if (result.success) {
      expect(result.data.unit_ar).toBe('كيلو');
    }
  });

  it('rejects negative price', () => {
    const result = createProductSchema.safeParse({ ...validProduct, price: -1 });
    expect(result.success).toBe(false);
  });

  it('accepts zero price', () => {
    const result = createProductSchema.safeParse({ ...validProduct, price: 0 });
    expect(result.success).toBe(true);
  });

  it('rejects invalid unit', () => {
    const result = createProductSchema.safeParse({ ...validProduct, unit: 'invalid' as any });
    expect(result.success).toBe(false);
  });

  it('accepts all valid units', () => {
    const units = ['kg', 'piece', 'bundle', 'tray', 'bag', 'jar', 'pack', 'roll'];
    for (const unit of units) {
      const result = createProductSchema.safeParse({ ...validProduct, unit: unit as any });
      expect(result.success).toBe(true);
    }
  });

  it('rejects invalid category UUID', () => {
    const result = createProductSchema.safeParse({ ...validProduct, category_id: 'not-a-uuid' });
    expect(result.success).toBe(false);
  });
});

describe('Auth Validator', () => {
  it('accepts valid login', () => {
    const result = loginSchema.safeParse({ username: 'admin', password: 'password123' });
    expect(result.success).toBe(true);
  });

  it('rejects empty username', () => {
    const result = loginSchema.safeParse({ username: '', password: 'password123' });
    expect(result.success).toBe(false);
  });

  it('rejects empty password', () => {
    const result = loginSchema.safeParse({ username: 'admin', password: '' });
    expect(result.success).toBe(false);
  });

  it('lowercases username', () => {
    const result = loginSchema.safeParse({ username: 'ADMIN', password: 'password123' });
    if (result.success) {
      expect(result.data.username).toBe('admin');
    }
  });
});
