import { describe, it, expect } from 'vitest';
import supertest from 'supertest';
import path from 'path';
import app from '../src/app';
import { isAllowedImageType, validateFileSize } from '../src/services/image.service';

const request = supertest(app);

describe('Image Upload API (protected)', () => {
  it('blocks unauthenticated image upload', async () => {
    const res = await request
      .post('/api/admin/products/00000000-0000-0000-0000-000000000001/images')
      .attach('image', Buffer.from('fake'), { filename: 'test.jpg', contentType: 'image/jpeg' });
    expect(res.status).toBe(401);
  });
});

describe('Image Service Validation', () => {
  describe('isAllowedImageType', () => {
    it('accepts JPEG', () => {
      expect(isAllowedImageType('image/jpeg')).toBe(true);
    });

    it('accepts JPG', () => {
      expect(isAllowedImageType('image/jpg')).toBe(true);
    });

    it('accepts PNG', () => {
      expect(isAllowedImageType('image/png')).toBe(true);
    });

    it('accepts WEBP', () => {
      expect(isAllowedImageType('image/webp')).toBe(true);
    });

    it('rejects GIF', () => {
      expect(isAllowedImageType('image/gif')).toBe(false);
    });

    it('rejects SVG', () => {
      expect(isAllowedImageType('image/svg+xml')).toBe(false);
    });

    it('rejects PDF', () => {
      expect(isAllowedImageType('application/pdf')).toBe(false);
    });

    it('rejects executable', () => {
      expect(isAllowedImageType('application/exe')).toBe(false);
    });

    it('is case insensitive', () => {
      expect(isAllowedImageType('IMAGE/JPEG')).toBe(true);
    });
  });

  describe('validateFileSize', () => {
    it('accepts file under 10MB', () => {
      expect(validateFileSize(5 * 1024 * 1024)).toBe(true);
    });

    it('accepts file exactly at 10MB', () => {
      expect(validateFileSize(10 * 1024 * 1024)).toBe(true);
    });

    it('rejects file over 10MB', () => {
      expect(validateFileSize(10 * 1024 * 1024 + 1)).toBe(false);
    });

    it('accepts small file', () => {
      expect(validateFileSize(1024)).toBe(true);
    });
  });
});
