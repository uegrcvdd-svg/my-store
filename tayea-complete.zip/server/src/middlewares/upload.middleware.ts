import multer from 'multer';
import { Request, Response, NextFunction } from 'express';
import { errorResponse } from '../utils/apiResponse';
import { isAllowedImageType, validateFileSize } from '../services/image.service';

const storage = multer.memoryStorage();

const fileFilter = (
  _req: Request,
  file: Express.Multer.File,
  cb: multer.FileFilterCallback
) => {
  if (!isAllowedImageType(file.mimetype)) {
    cb(new Error('نوع الملف غير مسموح. المسموح به: JPG, PNG, WEBP فقط'));
    return;
  }
  cb(null, true);
};

export const uploadSingle = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB
}).single('image');

export const uploadMiddleware = (req: Request, res: Response, next: NextFunction) => {
  uploadSingle(req, res, (err) => {
    if (err instanceof multer.MulterError) {
      if (err.code === 'LIMIT_FILE_SIZE') {
        return errorResponse(res, 'حجم الصورة كبير جداً. الحد الأقصى 10 ميجا', 413, 'FILE_TOO_LARGE');
      }
      return errorResponse(res, 'خطأ في رفع الملف', 400, 'UPLOAD_ERROR');
    }
    if (err) {
      return errorResponse(res, err.message, 415, 'INVALID_FILE_TYPE');
    }
    next();
  });
};
