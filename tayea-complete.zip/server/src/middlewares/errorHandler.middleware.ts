import { Request, Response, NextFunction } from 'express';
import { logger } from '../utils/logger';

export function errorHandler(
  err: Error,
  req: Request,
  res: Response,
  _next: NextFunction
) {
  logger.error('Unhandled error', {
    message: err.message,
    stack: err.stack,
    method: req.method,
    url: req.url,
    ip: req.ip,
  });

  if (res.headersSent) return;

  const statusCode = (err as any).statusCode || 500;

  res.status(statusCode).json({
    success: false,
    error: {
      code: 'SERVER_ERROR',
      message:
        process.env.NODE_ENV === 'production'
          ? 'حدث خطأ في الخادم'
          : err.message,
    },
  });
}

export function notFoundHandler(req: Request, res: Response) {
  res.status(404).json({
    success: false,
    error: {
      code: 'NOT_FOUND',
      message: `المسار غير موجود: ${req.method} ${req.path}`,
    },
  });
}
