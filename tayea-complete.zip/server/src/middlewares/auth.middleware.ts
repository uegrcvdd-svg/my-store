import { Request, Response, NextFunction } from 'express';
import { unauthorizedResponse } from '../utils/apiResponse';

declare module 'express-session' {
  interface SessionData {
    adminId: string;
    username: string;
  }
}

export function requireAuth(req: Request, res: Response, next: NextFunction) {
  if (!req.session?.adminId) {
    return unauthorizedResponse(res, 'يجب تسجيل الدخول أولاً');
  }
  next();
}
