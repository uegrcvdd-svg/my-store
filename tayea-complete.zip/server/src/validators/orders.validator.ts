import { z } from 'zod';

const egyptianPhone = z
  .string()
  .regex(/^01[0125][0-9]{8}$/, 'رقم الهاتف غير صحيح، يجب أن يكون رقم مصري صحيح');

// Qena Governorate approximate bounding box
const QENA_LAT_MIN = 25.5;
const QENA_LAT_MAX = 27.0;
const QENA_LNG_MIN = 32.0;
const QENA_LNG_MAX = 33.5;

export const createOrderSchema = z.object({
  customer_name: z
    .string()
    .min(2, 'الاسم يجب أن يكون حرفين على الأقل')
    .max(255, 'الاسم طويل جداً')
    .trim(),
  phone_primary: egyptianPhone,
  phone_secondary: egyptianPhone.optional().or(z.literal('')).transform(v => v || undefined),
  address_text: z
    .string()
    .min(5, 'العنوان يجب أن يكون 5 أحرف على الأقل')
    .max(500, 'العنوان طويل جداً')
    .trim(),
  gps_lat: z
    .number()
    .min(QENA_LAT_MIN, 'الموقع خارج نطاق محافظة قنا')
    .max(QENA_LAT_MAX, 'الموقع خارج نطاق محافظة قنا')
    .optional(),
  gps_lng: z
    .number()
    .min(QENA_LNG_MIN, 'الموقع خارج نطاق محافظة قنا')
    .max(QENA_LNG_MAX, 'الموقع خارج نطاق محافظة قنا')
    .optional(),
  landmark: z.string().max(255).trim().optional().or(z.literal('')).transform(v => v || undefined),
  notes: z.string().max(1000).trim().optional().or(z.literal('')).transform(v => v || undefined),
  items: z
    .array(
      z.object({
        product_id: z.string().uuid('معرف المنتج غير صحيح'),
        quantity: z
          .number()
          .positive('الكمية يجب أن تكون أكبر من صفر')
          .max(999, 'الكمية كبيرة جداً'),
      })
    )
    .min(1, 'يجب إضافة منتج واحد على الأقل')
    .max(50, 'عدد المنتجات كبير جداً'),
});

export type CreateOrderInput = z.infer<typeof createOrderSchema>;
