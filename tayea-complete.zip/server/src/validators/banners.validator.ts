import { z } from 'zod';

export const updateBannerSchema = z.object({
  title: z.string().max(255).trim().optional(),
  subtitle: z.string().max(255).trim().optional(),
  link_url: z.string().url('رابط غير صحيح').max(500).optional().or(z.literal('')).transform(v => v || undefined),
  display_order: z.number().int().min(0).max(999).optional(),
  is_active: z.boolean().optional(),
});

export const reorderBannersSchema = z.object({
  items: z.array(
    z.object({
      id: z.string().uuid(),
      display_order: z.number().int().min(0).max(999),
    })
  ).min(1),
});
