import { z } from 'zod';

export const updateSettingsSchema = z.object({
  store_name: z.string().max(255).trim().optional(),
  store_address: z.string().max(500).trim().optional(),
  phone_primary: z.string().max(20).trim().optional(),
  phone_secondary: z.string().max(20).trim().optional(),
  whatsapp_number: z.string().max(20).trim().optional(),
  maps_link: z.string().url().max(500).optional().or(z.literal('')),
  working_hours: z.string().max(255).trim().optional(),
  facebook_url: z.string().url().max(500).optional().or(z.literal('')),
  instagram_url: z.string().url().max(500).optional().or(z.literal('')),
  delivery_area: z.string().max(255).trim().optional(),
  currency: z.string().max(50).trim().optional(),
}).strict();
