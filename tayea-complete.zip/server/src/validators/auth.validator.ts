import { z } from 'zod';

export const loginSchema = z.object({
  username: z
    .string()
    .min(1, 'اسم المستخدم مطلوب')
    .max(100)
    .trim()
    .toLowerCase(),
  password: z.string().min(1, 'كلمة المرور مطلوبة').max(200),
});

export const changePasswordSchema = z
  .object({
    current_password: z.string().min(1, 'كلمة المرور الحالية مطلوبة'),
    new_password: z
      .string()
      .min(8, 'كلمة المرور الجديدة يجب أن تكون 8 أحرف على الأقل')
      .max(200)
      .regex(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/,
        'كلمة المرور يجب أن تحتوي على حروف كبيرة وصغيرة وأرقام'
      ),
    confirm_password: z.string(),
  })
  .refine((d) => d.new_password === d.confirm_password, {
    message: 'كلمة المرور الجديدة غير متطابقة',
    path: ['confirm_password'],
  });
