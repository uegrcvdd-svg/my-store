import { z } from 'zod';

const VALID_UNITS = ['kg', 'piece', 'bundle', 'tray', 'bag', 'jar', 'pack', 'roll'] as const;
const UNIT_AR_MAP: Record<string, string> = {
  kg: 'كيلو',
  piece: 'حبة',
  bundle: 'ربطة',
  tray: 'صينية',
  bag: 'كيس',
  jar: 'جرة',
  pack: 'علبة',
  roll: 'لفة',
};

export const createProductSchema = z.object({
  category_id: z.string().uuid('معرف الفئة غير صحيح'),
  name: z.string().min(1, 'الاسم مطلوب').max(255).trim(),
  name_ar: z.string().min(1, 'الاسم بالعربي مطلوب').max(255).trim(),
  description: z.string().max(2000).trim().optional(),
  unit: z.enum(VALID_UNITS, { errorMap: () => ({ message: 'الوحدة غير صحيحة' }) }),
  price: z
    .number()
    .min(0, 'السعر لا يمكن أن يكون سالباً')
    .max(99999, 'السعر كبير جداً'),
  display_order: z.number().int().min(0).max(9999).optional(),
  is_visible: z.boolean().optional(),
  is_popular: z.boolean().optional(),
}).transform((data) => ({
  ...data,
  unit_ar: UNIT_AR_MAP[data.unit] || data.unit,
}));

export const updateProductSchema = createProductSchema.partial().omit({ category_id: true });

export const reorderSchema = z.object({
  items: z.array(
    z.object({
      id: z.string().uuid(),
      display_order: z.number().int().min(0).max(9999),
    })
  ).min(1),
});

export const priceUpdateSchema = z.object({
  price: z.number().min(0, 'السعر لا يمكن أن يكون سالباً').max(99999),
});

export const bulkPriceSchema = z.object({
  items: z.array(
    z.object({
      id: z.string().uuid(),
      price: z.number().min(0).max(99999),
    })
  ).min(1).max(500),
});
