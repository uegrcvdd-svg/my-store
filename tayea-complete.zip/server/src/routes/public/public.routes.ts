import { Router } from 'express';
import * as productsCtrl from '../../controllers/public/products.controller';
import * as ordersCtrl from '../../controllers/public/orders.controller';
import * as publicCtrl from '../../controllers/public/public.controller';
import { searchLimiter, orderLimiter } from '../../middlewares/rateLimiter.middleware';

const router = Router();

// Products
router.get('/products', productsCtrl.listProducts);
router.get('/products/popular', productsCtrl.getPopularProducts);
router.get('/products/search', searchLimiter, productsCtrl.searchProducts);
router.get('/products/:id', productsCtrl.getProduct);

// Categories
router.get('/categories', publicCtrl.listCategories);

// Banners
router.get('/banners', publicCtrl.listBanners);

// Settings
router.get('/settings/public', publicCtrl.getSettings);

// Orders
router.post('/orders', orderLimiter, ordersCtrl.submitOrder);
router.get('/orders/:id/status', ordersCtrl.getOrderStatus);

export default router;
