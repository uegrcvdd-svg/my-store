import { Router } from 'express';
import { login, logout, getMe, changeAdminPassword, changeAdminUsername } from '../../controllers/admin/auth.controller';
import { loginLimiter } from '../../middlewares/rateLimiter.middleware';
import { validate } from '../../middlewares/validate.middleware';
import { requireAuth } from '../../middlewares/auth.middleware';
import { loginSchema } from '../../validators/auth.validator';

const router = Router();

router.post('/login', loginLimiter, validate(loginSchema), login);
router.post('/logout', requireAuth, logout);
router.get('/me', requireAuth, getMe);
router.post('/change-password', requireAuth, changeAdminPassword);
router.post('/change-username', requireAuth, changeAdminUsername);

export default router;
