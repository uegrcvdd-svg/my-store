import { Router } from 'express';
import * as bannersCtrl from '../../controllers/admin/banners.controller';
import * as pricesCtrl from '../../controllers/admin/prices.controller';
import * as settingsCtrl from '../../controllers/admin/settings.controller';
import * as activityCtrl from '../../controllers/admin/activity.controller';
import { requireAuth } from '../../middlewares/auth.middleware';
import { validate } from '../../middlewares/validate.middleware';
import { uploadMiddleware } from '../../middlewares/upload.middleware';
import { updateBannerSchema, reorderBannersSchema } from '../../validators/banners.validator';
import { priceUpdateSchema, bulkPriceSchema } from '../../validators/products.validator';
import { updateSettingsSchema } from '../../validators/settings.validator';

// Banners
export const bannersRouter = Router();
bannersRouter.use(requireAuth);
bannersRouter.get('/', bannersCtrl.listBanners);
bannersRouter.post('/', uploadMiddleware, bannersCtrl.createBanner);
bannersRouter.patch('/reorder', validate(reorderBannersSchema), bannersCtrl.reorderBanners);
bannersRouter.patch('/:id', validate(updateBannerSchema), bannersCtrl.updateBanner);
bannersRouter.patch('/:id/toggle', bannersCtrl.toggleBanner);
bannersRouter.delete('/:id', bannersCtrl.deleteBanner);

// Prices
export const pricesRouter = Router();
pricesRouter.use(requireAuth);
pricesRouter.get('/', pricesCtrl.listPrices);
pricesRouter.patch('/bulk', validate(bulkPriceSchema), pricesCtrl.bulkUpdatePrices);
pricesRouter.patch('/:id', validate(priceUpdateSchema), pricesCtrl.updatePrice);

// Settings
export const settingsRouter = Router();
settingsRouter.use(requireAuth);
settingsRouter.get('/', settingsCtrl.getSettings);
settingsRouter.patch('/', validate(updateSettingsSchema), settingsCtrl.updateSettings);

// Activity
export const activityRouter = Router();
activityRouter.use(requireAuth);
activityRouter.get('/', activityCtrl.listActivity);
