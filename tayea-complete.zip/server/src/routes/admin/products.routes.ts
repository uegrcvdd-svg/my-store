import { Router } from 'express';
import * as ctrl from '../../controllers/admin/products.controller';
import { requireAuth } from '../../middlewares/auth.middleware';
import { validate } from '../../middlewares/validate.middleware';
import { uploadMiddleware } from '../../middlewares/upload.middleware';
import { createProductSchema, updateProductSchema, reorderSchema } from '../../validators/products.validator';

const router = Router();
router.use(requireAuth);

router.get('/', ctrl.listProducts);
router.post('/', validate(createProductSchema), ctrl.createProduct);
router.patch('/reorder', validate(reorderSchema), ctrl.reorderProducts);
router.get('/:id', ctrl.getProduct);
router.patch('/:id', validate(updateProductSchema), ctrl.updateProduct);
router.delete('/:id', ctrl.deleteProduct);
router.patch('/:id/visibility', ctrl.toggleVisibility);
router.patch('/:id/popular', ctrl.togglePopular);
router.post('/:id/images', uploadMiddleware, ctrl.uploadProductImage);
router.patch('/:id/images/:imgId/primary', ctrl.setPrimaryImage);
router.delete('/:id/images/:imgId', ctrl.deleteProductImage);

export default router;
