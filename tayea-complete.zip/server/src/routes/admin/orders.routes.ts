import { Router } from 'express';
import * as ctrl from '../../controllers/admin/orders.controller';
import { requireAuth } from '../../middlewares/auth.middleware';

const router = Router();
router.use(requireAuth);

router.get('/', ctrl.listOrders);
router.get('/stats', ctrl.getDashboardStats);
router.get('/recent', ctrl.getRecentOrders);
router.get('/:id', ctrl.getOrder);
router.patch('/:id/status', ctrl.updateStatus);
router.get('/:id/share', ctrl.getShareMessage);

export default router;
