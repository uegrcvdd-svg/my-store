import { Router } from 'express';
import publicRouter from './public/public.routes';
import authRouter from './admin/auth.routes';
import adminProductsRouter from './admin/products.routes';
import adminOrdersRouter from './admin/orders.routes';
import { bannersRouter, pricesRouter, settingsRouter, activityRouter } from './admin/misc.routes';

const router = Router();

// Public API
router.use('/api', publicRouter);

// Admin API
router.use('/api/admin/auth', authRouter);
router.use('/api/admin/products', adminProductsRouter);
router.use('/api/admin/orders', adminOrdersRouter);
router.use('/api/admin/banners', bannersRouter);
router.use('/api/admin/prices', pricesRouter);
router.use('/api/admin/settings', settingsRouter);
router.use('/api/admin/activity', activityRouter);

export default router;
