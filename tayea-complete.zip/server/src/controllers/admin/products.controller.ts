import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import {
  successResponse, createdResponse, notFoundResponse, errorResponse,
} from '../../utils/apiResponse';
import * as ProductsService from '../../services/products.service';
import * as StorageService from '../../services/storage.service';
import * as ImageService from '../../services/image.service';
import { logActivity } from '../../services/activity.service';

export const listProducts = asyncHandler(async (req: Request, res: Response) => {
  const { page, limit, search, category } = req.query;
  const result = await ProductsService.getAllProductsAdmin(page, limit, search as string, category as string);
  return successResponse(res, result.products, 'تم الجلب بنجاح', 200, result.meta);
});

export const getProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductsService.getProductById(req.params.id, true);
  if (!product) return notFoundResponse(res, 'المنتج غير موجود');
  return successResponse(res, product);
});

export const createProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductsService.createProduct(req.body);

  await logActivity({
    adminId: req.session.adminId,
    action: 'product_created',
    entityType: 'product',
    entityId: product.id,
    description: `تم إضافة منتج جديد: ${req.body.name_ar}`,
    ipAddress: req.ip,
  });

  const full = await ProductsService.getProductById(product.id, true);
  return createdResponse(res, full, 'تم إضافة المنتج بنجاح');
});

export const updateProduct = asyncHandler(async (req: Request, res: Response) => {
  const updated = await ProductsService.updateProduct(req.params.id, req.body);
  if (!updated) return notFoundResponse(res, 'المنتج غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'product_updated',
    entityType: 'product',
    entityId: req.params.id,
    description: `تم تعديل المنتج`,
    ipAddress: req.ip,
    metadata: req.body,
  });

  const full = await ProductsService.getProductById(req.params.id, true);
  return successResponse(res, full, 'تم تعديل المنتج بنجاح');
});

export const deleteProduct = asyncHandler(async (req: Request, res: Response) => {
  const deleted = await ProductsService.deleteProduct(req.params.id);
  if (!deleted) return notFoundResponse(res, 'المنتج غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'product_deleted',
    entityType: 'product',
    entityId: req.params.id,
    description: `تم حذف المنتج`,
    ipAddress: req.ip,
  });

  return successResponse(res, null, 'تم حذف المنتج بنجاح');
});

export const toggleVisibility = asyncHandler(async (req: Request, res: Response) => {
  const result = await ProductsService.toggleVisibility(req.params.id);
  if (!result) return notFoundResponse(res, 'المنتج غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'product_visibility_changed',
    entityType: 'product',
    entityId: req.params.id,
    description: `تم ${result.is_visible ? 'إظهار' : 'إخفاء'} المنتج`,
    ipAddress: req.ip,
    metadata: { is_visible: result.is_visible },
  });

  return successResponse(res, result, `تم ${result.is_visible ? 'إظهار' : 'إخفاء'} المنتج`);
});

export const togglePopular = asyncHandler(async (req: Request, res: Response) => {
  const result = await ProductsService.togglePopular(req.params.id);
  if (!result) return notFoundResponse(res, 'المنتج غير موجود');
  return successResponse(res, result, 'تم التحديث بنجاح');
});

export const reorderProducts = asyncHandler(async (req: Request, res: Response) => {
  await ProductsService.reorderProducts(req.body.items);
  return successResponse(res, null, 'تم تحديث الترتيب بنجاح');
});

export const uploadProductImage = asyncHandler(async (req: Request, res: Response) => {
  if (!req.file) return errorResponse(res, 'لم يتم رفع أي صورة', 400);

  const { buffer, contentType } = await ImageService.processImage(req.file.buffer);
  const storageKey = ImageService.generateStorageKey('products', req.file.originalname);
  const bucket = process.env.SUPABASE_BUCKET_PRODUCTS || 'products';

  const imageUrl = await StorageService.uploadToStorage(bucket, storageKey, buffer, contentType);

  // Check if this product has any images yet; if not, make it primary
  const product = await ProductsService.getProductById(req.params.id, true);
  if (!product) return notFoundResponse(res, 'المنتج غير موجود');

  const isPrimary = !product.images || product.images.length === 0;
  const image = await ProductsService.addProductImage(req.params.id, imageUrl, storageKey, isPrimary);

  await logActivity({
    adminId: req.session.adminId,
    action: 'image_uploaded',
    entityType: 'product',
    entityId: req.params.id,
    description: 'تم رفع صورة للمنتج',
    ipAddress: req.ip,
  });

  return createdResponse(res, image, 'تم رفع الصورة بنجاح');
});

export const setPrimaryImage = asyncHandler(async (req: Request, res: Response) => {
  const result = await ProductsService.setPrimaryImage(req.params.id, req.params.imgId);
  if (!result) return notFoundResponse(res, 'الصورة غير موجودة');
  return successResponse(res, result, 'تم تعيين الصورة الرئيسية');
});

export const deleteProductImage = asyncHandler(async (req: Request, res: Response) => {
  const deleted = await ProductsService.deleteProductImage(req.params.id, req.params.imgId);
  if (!deleted) return notFoundResponse(res, 'الصورة غير موجودة');

  try {
    const bucket = process.env.SUPABASE_BUCKET_PRODUCTS || 'products';
    await StorageService.deleteFromStorage(bucket, deleted.storage_key);
  } catch {
    // Log but don't fail the request if storage delete fails
  }

  await logActivity({
    adminId: req.session.adminId,
    action: 'image_deleted',
    entityType: 'product',
    entityId: req.params.id,
    description: 'تم حذف صورة من المنتج',
    ipAddress: req.ip,
  });

  return successResponse(res, null, 'تم حذف الصورة بنجاح');
});
