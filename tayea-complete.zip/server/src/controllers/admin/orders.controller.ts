import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse, notFoundResponse } from '../../utils/apiResponse';
import * as OrdersService from '../../services/orders.service';
import { logActivity } from '../../services/activity.service';
import { formatOrderShareMessage } from '../../utils/orderFormatter';

export const listOrders = asyncHandler(async (req: Request, res: Response) => {
  const { page, limit, search, status } = req.query;
  const result = await OrdersService.getAllOrders(page, limit, search as string, status as string);
  return successResponse(res, result.orders, 'تم الجلب بنجاح', 200, result.meta);
});

export const getOrder = asyncHandler(async (req: Request, res: Response) => {
  const order = await OrdersService.getOrderById(req.params.id);
  if (!order) return notFoundResponse(res, 'الطلب غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'order_viewed',
    entityType: 'order',
    entityId: req.params.id,
    description: `تم فتح الطلب #${order.order_number}`,
    ipAddress: req.ip,
  });

  return successResponse(res, order);
});

export const updateStatus = asyncHandler(async (req: Request, res: Response) => {
  const { status } = req.body;
  const order = await OrdersService.getOrderById(req.params.id);
  if (!order) return notFoundResponse(res, 'الطلب غير موجود');

  const updated = await OrdersService.updateOrderStatus(req.params.id, status);

  await logActivity({
    adminId: req.session.adminId,
    action: 'order_status_changed',
    entityType: 'order',
    entityId: req.params.id,
    description: `تم تغيير حالة الطلب #${order.order_number} من ${order.status} إلى ${status}`,
    ipAddress: req.ip,
    metadata: { old_status: order.status, new_status: status },
  });

  return successResponse(res, updated, 'تم تحديث حالة الطلب');
});

export const getShareMessage = asyncHandler(async (req: Request, res: Response) => {
  const order = await OrdersService.getOrderById(req.params.id);
  if (!order) return notFoundResponse(res, 'الطلب غير موجود');

  const message = formatOrderShareMessage({
    order_number: order.order_number,
    customer_name: order.customer_name,
    phone_primary: order.phone_primary,
    phone_secondary: order.phone_secondary,
    address_text: order.address_text,
    landmark: order.landmark,
    notes: order.notes,
    maps_link: order.maps_link,
    gps_lat: order.gps_lat ? parseFloat(String(order.gps_lat)) : null,
    gps_lng: order.gps_lng ? parseFloat(String(order.gps_lng)) : null,
    grand_total: order.grand_total,
    status: order.status,
    items: order.items || [],
  });

  return successResponse(res, { message });
});

export const getDashboardStats = asyncHandler(async (_req: Request, res: Response) => {
  const stats = await OrdersService.getDashboardStats();
  return successResponse(res, stats);
});

export const getRecentOrders = asyncHandler(async (_req: Request, res: Response) => {
  const orders = await OrdersService.getRecentOrders(10);
  return successResponse(res, orders);
});
