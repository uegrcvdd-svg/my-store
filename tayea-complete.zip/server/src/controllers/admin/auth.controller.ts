import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse, unauthorizedResponse, errorResponse } from '../../utils/apiResponse';
import { findAdminByUsername, verifyPassword, changePassword, changeUsername } from '../../services/auth.service';
import { logActivity } from '../../services/activity.service';
import { loginSchema, changePasswordSchema } from '../../validators/auth.validator';

export const login = asyncHandler(async (req: Request, res: Response) => {
  const { username, password } = req.body;

  const admin = await findAdminByUsername(username);
  if (!admin) {
    return unauthorizedResponse(res, 'اسم المستخدم أو كلمة المرور غير صحيحة');
  }

  const valid = await verifyPassword(password, admin.password_hash);
  if (!valid) {
    await logActivity({
      action: 'admin_login',
      description: `فشل تسجيل الدخول للمستخدم: ${username}`,
      ipAddress: req.ip,
      metadata: { success: false, username },
    });
    return unauthorizedResponse(res, 'اسم المستخدم أو كلمة المرور غير صحيحة');
  }

  req.session.adminId = admin.id;
  req.session.username = admin.username;

  await logActivity({
    adminId: admin.id,
    action: 'admin_login',
    description: 'تسجيل دخول ناجح',
    ipAddress: req.ip,
    metadata: { success: true },
  });

  return successResponse(res, {
    id: admin.id,
    username: admin.username,
  }, 'تم تسجيل الدخول بنجاح');
});

export const logout = asyncHandler(async (req: Request, res: Response) => {
  const adminId = req.session.adminId;

  await logActivity({
    adminId,
    action: 'admin_logout',
    description: 'تسجيل خروج',
    ipAddress: req.ip,
  });

  req.session.destroy((err) => {
    if (err) {
      return errorResponse(res, 'فشل تسجيل الخروج', 500);
    }
    res.clearCookie('__tayea_sid');
    return successResponse(res, null, 'تم تسجيل الخروج بنجاح');
  });
});

export const getMe = asyncHandler(async (req: Request, res: Response) => {
  return successResponse(res, {
    id: req.session.adminId,
    username: req.session.username,
  });
});

export const changeAdminPassword = asyncHandler(async (req: Request, res: Response) => {
  const parsed = changePasswordSchema.safeParse(req.body);
  if (!parsed.success) {
    return errorResponse(res, 'بيانات غير صحيحة', 400, 'VALIDATION_ERROR', parsed.error.errors);
  }

  const admin = await findAdminByUsername(req.session.username!);
  if (!admin) return errorResponse(res, 'المستخدم غير موجود', 404);

  const valid = await verifyPassword(parsed.data.current_password, admin.password_hash);
  if (!valid) return unauthorizedResponse(res, 'كلمة المرور الحالية غير صحيحة');

  await changePassword(admin.id, parsed.data.new_password);

  await logActivity({
    adminId: admin.id,
    action: 'settings_updated',
    description: 'تم تغيير كلمة المرور',
    ipAddress: req.ip,
  });

  return successResponse(res, null, 'تم تغيير كلمة المرور بنجاح');
});

export const changeAdminUsername = asyncHandler(async (req: Request, res: Response) => {
  const { new_username, current_password } = req.body;
  if (!new_username || typeof new_username !== 'string' || new_username.trim().length < 3) {
    return errorResponse(res, 'اسم المستخدم يجب أن يكون 3 أحرف على الأقل', 400, 'VALIDATION_ERROR');
  }
  if (!current_password) {
    return errorResponse(res, 'كلمة المرور الحالية مطلوبة', 400, 'VALIDATION_ERROR');
  }

  const admin = await findAdminByUsername(req.session.username!);
  if (!admin) return errorResponse(res, 'المستخدم غير موجود', 404);

  const valid = await verifyPassword(current_password, admin.password_hash);
  if (!valid) return unauthorizedResponse(res, 'كلمة المرور الحالية غير صحيحة');

  // Check username not already taken
  const existing = await findAdminByUsername(new_username.trim().toLowerCase());
  if (existing && existing.id !== admin.id) {
    return errorResponse(res, 'اسم المستخدم مستخدم بالفعل', 409, 'CONFLICT');
  }

  await changeUsername(admin.id, new_username);
  req.session.username = new_username.trim().toLowerCase();

  await logActivity({
    adminId: admin.id,
    action: 'settings_updated',
    description: `تم تغيير اسم المستخدم إلى: ${new_username}`,
    ipAddress: req.ip,
  });

  return successResponse(res, { username: new_username.trim().toLowerCase() }, 'تم تغيير اسم المستخدم بنجاح');
});
