import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse, notFoundResponse } from '../../utils/apiResponse';
import * as ProductsService from '../../services/products.service';
import { logActivity } from '../../services/activity.service';

export const listPrices = asyncHandler(async (_req: Request, res: Response) => {
  const products = await ProductsService.getAllProductPrices();
  return successResponse(res, products);
});

export const updatePrice = asyncHandler(async (req: Request, res: Response) => {
  const { price } = req.body;
  const existing = await ProductsService.getProductById(req.params.id, true);
  if (!existing) return notFoundResponse(res, 'المنتج غير موجود');

  const updated = await ProductsService.updateProductPrice(req.params.id, price);

  await logActivity({
    adminId: req.session.adminId,
    action: 'price_updated',
    entityType: 'product',
    entityId: req.params.id,
    description: `تم تغيير سعر ${existing.name_ar} من ${existing.price} إلى ${price}`,
    ipAddress: req.ip,
    metadata: { old_price: existing.price, new_price: price },
  });

  return successResponse(res, updated, 'تم تحديث السعر بنجاح');
});

export const bulkUpdatePrices = asyncHandler(async (req: Request, res: Response) => {
  const { items } = req.body;
  const results = await ProductsService.bulkUpdatePrices(items);

  await logActivity({
    adminId: req.session.adminId,
    action: 'price_updated',
    description: `تم تحديث ${items.length} سعر دفعة واحدة`,
    ipAddress: req.ip,
    metadata: { count: items.length },
  });

  return successResponse(res, results, `تم تحديث ${results.length} سعر بنجاح`);
});
