import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse } from '../../utils/apiResponse';
import * as SettingsService from '../../services/settings.service';
import { logActivity } from '../../services/activity.service';

export const getSettings = asyncHandler(async (_req: Request, res: Response) => {
  const settings = await SettingsService.getAllSettingsWithLabels();
  return successResponse(res, settings);
});

export const updateSettings = asyncHandler(async (req: Request, res: Response) => {
  await SettingsService.updateSettings(req.body);

  await logActivity({
    adminId: req.session.adminId,
    action: 'settings_updated',
    description: 'تم تحديث إعدادات المتجر',
    ipAddress: req.ip,
    metadata: req.body,
  });

  const updated = await SettingsService.getAllSettingsWithLabels();
  return successResponse(res, updated, 'تم تحديث الإعدادات بنجاح');
});
