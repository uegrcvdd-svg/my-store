import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse, createdResponse, notFoundResponse, errorResponse } from '../../utils/apiResponse';
import * as BannersService from '../../services/banners.service';
import * as StorageService from '../../services/storage.service';
import * as ImageService from '../../services/image.service';
import { logActivity } from '../../services/activity.service';

export const listBanners = asyncHandler(async (_req: Request, res: Response) => {
  const banners = await BannersService.getAllBannersAdmin();
  return successResponse(res, banners);
});

export const createBanner = asyncHandler(async (req: Request, res: Response) => {
  if (!req.file) return errorResponse(res, 'صورة البانر مطلوبة', 400);

  const { buffer, contentType } = await ImageService.processBannerImage(req.file.buffer);
  const storageKey = ImageService.generateStorageKey('banners', req.file.originalname);
  const bucket = process.env.SUPABASE_BUCKET_BANNERS || 'banners';

  const imageUrl = await StorageService.uploadToStorage(bucket, storageKey, buffer, contentType);

  const banner = await BannersService.createBanner({
    image_url: imageUrl,
    storage_key: storageKey,
    title: req.body.title,
    subtitle: req.body.subtitle,
    link_url: req.body.link_url,
    display_order: req.body.display_order ? parseInt(req.body.display_order) : 0,
  });

  await logActivity({
    adminId: req.session.adminId,
    action: 'banner_created',
    entityType: 'banner',
    entityId: banner.id,
    description: 'تم إضافة بانر جديد',
    ipAddress: req.ip,
  });

  return createdResponse(res, banner, 'تم إضافة البانر بنجاح');
});

export const updateBanner = asyncHandler(async (req: Request, res: Response) => {
  const updated = await BannersService.updateBanner(req.params.id, req.body);
  if (!updated) return notFoundResponse(res, 'البانر غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'banner_updated',
    entityType: 'banner',
    entityId: req.params.id,
    description: 'تم تعديل البانر',
    ipAddress: req.ip,
  });

  return successResponse(res, updated, 'تم تعديل البانر بنجاح');
});

export const toggleBanner = asyncHandler(async (req: Request, res: Response) => {
  const updated = await BannersService.toggleBannerActive(req.params.id);
  if (!updated) return notFoundResponse(res, 'البانر غير موجود');

  await logActivity({
    adminId: req.session.adminId,
    action: 'banner_updated',
    entityType: 'banner',
    entityId: req.params.id,
    description: `تم ${updated.is_active ? 'تفعيل' : 'تعطيل'} البانر`,
    ipAddress: req.ip,
  });

  return successResponse(res, updated, `تم ${updated.is_active ? 'تفعيل' : 'تعطيل'} البانر`);
});

export const deleteBanner = asyncHandler(async (req: Request, res: Response) => {
  const deleted = await BannersService.deleteBanner(req.params.id);
  if (!deleted) return notFoundResponse(res, 'البانر غير موجود');

  try {
    const bucket = process.env.SUPABASE_BUCKET_BANNERS || 'banners';
    await StorageService.deleteFromStorage(bucket, deleted.storage_key);
  } catch {
    // Log but don't fail
  }

  await logActivity({
    adminId: req.session.adminId,
    action: 'banner_deleted',
    entityType: 'banner',
    entityId: req.params.id,
    description: 'تم حذف البانر',
    ipAddress: req.ip,
  });

  return successResponse(res, null, 'تم حذف البانر بنجاح');
});

export const reorderBanners = asyncHandler(async (req: Request, res: Response) => {
  await BannersService.reorderBanners(req.body.items);
  return successResponse(res, null, 'تم تحديث الترتيب بنجاح');
});
