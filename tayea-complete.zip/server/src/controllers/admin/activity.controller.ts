import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse } from '../../utils/apiResponse';
import { getActivityLogs } from '../../services/activity.service';
import { getPagination, buildMeta } from '../../utils/pagination';

export const listActivity = asyncHandler(async (req: Request, res: Response) => {
  const { page, limit } = getPagination(req.query.page, req.query.limit, 100);
  const { logs, total } = await getActivityLogs(page, limit);
  return successResponse(res, logs, 'تم الجلب بنجاح', 200, buildMeta(page, limit, total));
});
