import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse, notFoundResponse } from '../../utils/apiResponse';
import * as ProductsService from '../../services/products.service';

export const listProducts = asyncHandler(async (req: Request, res: Response) => {
  const { page, limit, search, category } = req.query;
  const result = await ProductsService.getPublicProducts(page, limit, category as string, search as string);
  return successResponse(res, result.products, 'تم الجلب بنجاح', 200, result.meta);
});

export const getPopularProducts = asyncHandler(async (_req: Request, res: Response) => {
  const products = await ProductsService.getPopularProducts();
  return successResponse(res, products);
});

export const getProduct = asyncHandler(async (req: Request, res: Response) => {
  const product = await ProductsService.getProductById(req.params.id);
  if (!product) return notFoundResponse(res, 'المنتج غير موجود');
  return successResponse(res, product);
});

export const searchProducts = asyncHandler(async (req: Request, res: Response) => {
  const { q, page, limit } = req.query;
  const result = await ProductsService.getPublicProducts(page, limit, undefined, q as string);
  return successResponse(res, result.products, 'نتائج البحث', 200, result.meta);
});
