import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { successResponse } from '../../utils/apiResponse';
import { getActiveBanners } from '../../services/banners.service';
import { getPublicSettings } from '../../services/settings.service';
import { getAllCategories } from '../../services/categories.service';

export const listBanners = asyncHandler(async (_req: Request, res: Response) => {
  const banners = await getActiveBanners();
  return successResponse(res, banners);
});

export const getSettings = asyncHandler(async (_req: Request, res: Response) => {
  const settings = await getPublicSettings();
  return successResponse(res, settings);
});

export const listCategories = asyncHandler(async (_req: Request, res: Response) => {
  const categories = await getAllCategories();
  return successResponse(res, categories);
});
