import { Request, Response } from 'express';
import { asyncHandler } from '../../utils/asyncHandler';
import { createdResponse, errorResponse, successResponse } from '../../utils/apiResponse';
import { createOrder, getOrderById } from '../../services/orders.service';
import { createOrderSchema } from '../../validators/orders.validator';

export const submitOrder = asyncHandler(async (req: Request, res: Response) => {
  const parsed = createOrderSchema.safeParse(req.body);
  if (!parsed.success) {
    return errorResponse(res, 'بيانات الطلب غير صحيحة', 400, 'VALIDATION_ERROR', parsed.error.errors);
  }

  const order = await createOrder(parsed.data);
  return createdResponse(res, {
    id: order.id,
    order_number: order.order_number,
    grand_total: order.grand_total,
    status: order.status,
  }, 'تم استلام طلبك بنجاح');
});

// Public endpoint — returns only id, order_number, status (no sensitive customer data)
export const getOrderStatus = asyncHandler(async (req: Request, res: Response) => {
  const { id } = req.params;
  const order = await getOrderById(id);
  if (!order) {
    return errorResponse(res, 'الطلب غير موجود', 404, 'NOT_FOUND');
  }
  return successResponse(res, {
    id: order.id,
    order_number: order.order_number,
    status: order.status,
  }, 'تم جلب حالة الطلب');
});
