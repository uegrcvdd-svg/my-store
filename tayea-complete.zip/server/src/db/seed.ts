import * as fs from 'fs';
import * as path from 'path';
import * as argon2 from 'argon2';
import { pool } from './pool';

async function seed() {
  const client = await pool.connect();

  try {
    // Run SQL seed files
    const seedsDir = path.join(__dirname, 'seeds');
    const files = fs.readdirSync(seedsDir)
      .filter(f => f.endsWith('.sql'))
      .sort();

    for (const file of files) {
      console.log(`Running seed: ${file}`);
      const sql = fs.readFileSync(path.join(seedsDir, file), 'utf8');
      await client.query(sql);
      console.log(`✅ Seeded: ${file}`);
    }

    // Seed vegetables
    await seedVegetables(client);

    // Seed fruits
    await seedFruits(client);

    // Create default admin (change password immediately after first login)
    const defaultPassword = process.env.ADMIN_DEFAULT_PASSWORD || 'Tayea@Admin2024!';
    const hash = await argon2.hash(defaultPassword, {
      type: argon2.argon2id,
      memoryCost: 65536,
      timeCost: 3,
      parallelism: 4,
    });

    await client.query(`
      INSERT INTO admins (username, password_hash)
      VALUES ('admin', $1)
      ON CONFLICT (username) DO NOTHING
    `, [hash]);

    console.log('\n✅ Default admin created: username=admin');
    console.log(`   Password: ${defaultPassword}`);
    console.log('   ⚠️  CHANGE THIS PASSWORD IMMEDIATELY AFTER FIRST LOGIN\n');
    console.log('✅ All seeds applied successfully');

  } finally {
    client.release();
    await pool.end();
  }
}

async function seedVegetables(client: any) {
  const catId = 'a1000000-0000-0000-0000-000000000001';

  const vegetables = [
    ['طماطم', 'Tomatoes', 'kg', 'كيلو', 1, true],
    ['طماطم كرزي', 'Cherry Tomatoes', 'kg', 'كيلو', 2, false],
    ['طماطم صلصة', 'Tomato Sauce Tomatoes', 'kg', 'كيلو', 3, false],
    ['بطاطس جديدة', 'New Potatoes', 'kg', 'كيلو', 4, true],
    ['بطاطس روزيتا ممتازة', 'Rosetta Potatoes Premium', 'kg', 'كيلو', 5, false],
    ['بطاطس روزيتا وسط', 'Rosetta Medium Potatoes', 'kg', 'كيلو', 6, false],
    ['بطاطس إسبونتا قلي', 'Espunta Frying Potatoes', 'kg', 'كيلو', 7, false],
    ['بطاطس كارا قلي', 'Cara Frying Potatoes', 'kg', 'كيلو', 8, false],
    ['بطاطس صغيرة', 'Small Potatoes', 'kg', 'كيلو', 9, false],
    ['بطاطا حلوة صفراء', 'Yellow Sweet Potatoes', 'kg', 'كيلو', 10, false],
    ['بطاطا حلوة بيضاء', 'White Sweet Potatoes', 'kg', 'كيلو', 11, false],
    ['بامية صغيرة', 'Small Okra', 'kg', 'كيلو', 12, false],
    ['بامية كبيرة', 'Large Okra', 'kg', 'كيلو', 13, false],
    ['بامية حمراء', 'Red Okra', 'kg', 'كيلو', 14, false],
    ['فاصوليا خضراء', 'Green Beans', 'kg', 'كيلو', 15, false],
    ['بسلة خضراء', 'Green Peas', 'kg', 'كيلو', 16, false],
    ['فول أخضر طازج', 'Fresh Broad Beans', 'kg', 'كيلو', 17, false],
    ['قلقاس', 'Taro', 'kg', 'كيلو', 18, false],
    ['خيار صغير', 'Small Cucumbers', 'kg', 'كيلو', 19, true],
    ['كوسة حشو', 'Stuffing Zucchini', 'kg', 'كيلو', 20, false],
    ['كوسة مجوفة جاهزة', 'Ready Hollowed Zucchini', 'kg', 'كيلو', 21, false],
    ['شمندر', 'Beetroot', 'kg', 'كيلو', 22, false],
    ['جزر', 'Carrots', 'kg', 'كيلو', 23, true],
    ['بروكلي', 'Broccoli', 'kg', 'كيلو', 24, false],
    ['ذرة حلوة', 'Sweet Corn', 'piece', 'حبة', 25, false],
    ['فلفل أخضر حشو', 'Stuffing Green Pepper', 'kg', 'كيلو', 26, false],
    ['فلفل حار', 'Hot Pepper', 'kg', 'كيلو', 27, false],
    ['فلفل ملون', 'Colored Pepper', 'kg', 'كيلو', 28, false],
    ['فلفل أحمر حار', 'Red Chili Pepper', 'kg', 'كيلو', 29, false],
    ['فلفل مجوف', 'Hollowed Pepper', 'kg', 'كيلو', 30, false],
    ['باذنجان أسود', 'Black Eggplant', 'kg', 'كيلو', 31, false],
    ['باذنجان أبيض حشو', 'White Stuffing Eggplant', 'kg', 'كيلو', 32, false],
    ['باذنجان أسود حشو', 'Black Stuffing Eggplant', 'kg', 'كيلو', 33, false],
    ['باذنجان مقلم حشو', 'Striped Stuffing Eggplant', 'kg', 'كيلو', 34, false],
    ['باذنجان أبيض مجوف', 'White Hollowed Eggplant', 'kg', 'كيلو', 35, false],
    ['باذنجان أسود مجوف', 'Black Hollowed Eggplant', 'kg', 'كيلو', 36, false],
    ['باذنجان مقلم مجوف', 'Striped Hollowed Eggplant', 'kg', 'كيلو', 37, false],
    ['بصل أحمر', 'Red Onion', 'kg', 'كيلو', 38, true],
    ['بصل أبيض', 'White Onion', 'kg', 'كيلو', 39, false],
    ['بصل أبيض قديم', 'Old White Onion', 'kg', 'كيلو', 40, false],
    ['بصل أخضر', 'Green Onion', 'bundle', 'ربطة', 41, false],
    ['ثوم طازج', 'Fresh Garlic', 'kg', 'كيلو', 42, false],
    ['ثوم أخضر', 'Green Garlic', 'bundle', 'ربطة', 43, false],
    ['ثوم صيني', 'Chinese Garlic', 'kg', 'كيلو', 44, false],
    ['ثوم مقشر', 'Peeled Garlic', 'kg', 'كيلو', 45, false],
    ['ليمون بلدي', 'Local Lemon', 'kg', 'كيلو', 46, false],
    ['ليمون أضاليا', 'Adalia Lemon', 'kg', 'كيلو', 47, false],
    ['قرع عسلي', 'Pumpkin', 'kg', 'كيلو', 48, false],
    ['قرع حلو', 'Sweet Pumpkin', 'kg', 'كيلو', 49, false],
    ['كرنب', 'Cabbage', 'piece', 'حبة', 50, false],
    ['كرنب أبيض', 'White Cabbage', 'piece', 'حبة', 51, false],
    ['كرنب أحمر', 'Red Cabbage', 'piece', 'حبة', 52, false],
    ['ورق كرنب مسلوق', 'Cooked Cabbage Leaves', 'pack', 'علبة', 53, false],
    ['قرنبيط', 'Cauliflower', 'piece', 'حبة', 54, false],
    ['ورق عنب جرة', 'Grape Leaves Jar', 'jar', 'جرة', 55, false],
    ['ورق عنب كيس', 'Grape Leaves Bag', 'bag', 'كيس', 56, false],
    ['ملوخية', 'Molokhia', 'bundle', 'ربطة', 57, true],
    ['سبانخ', 'Spinach', 'bundle', 'ربطة', 58, false],
    ['خس', 'Lettuce', 'piece', 'حبة', 59, false],
    ['جرجير', 'Arugula', 'bundle', 'ربطة', 60, false],
    ['نعناع', 'Mint', 'bundle', 'ربطة', 61, false],
    ['كرفس', 'Celery', 'bundle', 'ربطة', 62, false],
    ['سلق', 'Swiss Chard', 'bundle', 'ربطة', 63, false],
    ['فجل إنجليزي', 'English Radish', 'bundle', 'ربطة', 64, false],
    ['زنجبيل طازج', 'Fresh Ginger', 'kg', 'كيلو', 65, false],
    ['فطر طازج', 'Fresh Mushroom', 'kg', 'كيلو', 66, false],
    ['زعتر طازج', 'Fresh Thyme', 'bundle', 'ربطة', 67, false],
    ['روزماري طازج', 'Fresh Rosemary', 'bundle', 'ربطة', 68, false],
    ['أعشاب طازجة', 'Fresh Herbs', 'bundle', 'ربطة', 69, false],
    ['شبت', 'Dill', 'bundle', 'ربطة', 70, false],
    ['بقدونس', 'Parsley', 'bundle', 'ربطة', 71, false],
    ['كزبرة', 'Coriander', 'bundle', 'ربطة', 72, false],
    ['شمر', 'Fennel', 'bundle', 'ربطة', 73, false],
    ['خضرة ثوم', 'Green Garlic Stems', 'bundle', 'ربطة', 74, false],
  ];

  for (const [nameAr, name, unit, unitAr, order, isPopular] of vegetables) {
    await client.query(`
      INSERT INTO products (category_id, name, name_ar, unit, unit_ar, price, display_order, is_visible, is_popular)
      VALUES ($1, $2, $3, $4, $5, 0.00, $6, true, $7)
      ON CONFLICT DO NOTHING
    `, [catId, name, nameAr, unit, unitAr, order, isPopular]);
  }

  console.log(`✅ Seeded ${vegetables.length} vegetables`);
}

async function seedFruits(client: any) {
  const catId = 'a1000000-0000-0000-0000-000000000002';

  const fruits = [
    ['موز بلدي', 'Local Banana', 'kg', 'كيلو', 1, true],
    ['موز بيكو', 'Pico Banana', 'kg', 'كيلو', 2, false],
    ['مانجو صديقة', 'Mango Sedika', 'kg', 'كيلو', 3, true],
    ['مانجو عويس', 'Mango Owais', 'kg', 'كيلو', 4, false],
    ['مانجو فونص', 'Mango Fons', 'kg', 'كيلو', 5, false],
    ['مانجو حلوة ممتازة', 'Premium Sweet Mango', 'kg', 'كيلو', 6, false],
    ['مانجو حلوة إسماعيلية', 'Ismailia Sweet Mango', 'kg', 'كيلو', 7, false],
    ['مانجو زبدة', 'Mango Zebda', 'kg', 'كيلو', 8, false],
    ['مانجو جولك', 'Mango Golk', 'kg', 'كيلو', 9, false],
    ['مانجو خد الجميل', 'Mango Khad El Gamil', 'kg', 'كيلو', 10, false],
    ['تفاح بلدي', 'Local Apple', 'kg', 'كيلو', 11, false],
    ['تفاح إيطالي أصفر', 'Yellow Italian Apple', 'kg', 'كيلو', 12, false],
    ['تفاح إيطالي حلو', 'Sweet Italian Apple', 'kg', 'كيلو', 13, false],
    ['تفاح أمريكي', 'American Apple', 'kg', 'كيلو', 14, false],
    ['تفاح أخضر', 'Green Apple', 'kg', 'كيلو', 15, false],
    ['تفاح فرنسي', 'French Apple', 'kg', 'كيلو', 16, false],
    ['برتقال عصير', 'Orange Juice Orange', 'kg', 'كيلو', 17, true],
    ['برتقال أبو سرة', 'Navel Orange', 'kg', 'كيلو', 18, false],
    ['برتقال حلو', 'Sweet Orange', 'kg', 'كيلو', 19, false],
    ['يوسفي بلدي', 'Local Mandarin', 'kg', 'كيلو', 20, false],
    ['يوسفي عرايشي', 'Arayshi Mandarin', 'kg', 'كيلو', 21, false],
    ['عنب أسود', 'Black Grapes', 'kg', 'كيلو', 22, false],
    ['عنب أسود لبناني', 'Lebanese Black Grapes', 'kg', 'كيلو', 23, false],
    ['جوافة', 'Guava', 'kg', 'كيلو', 24, true],
    ['جوافة حمراء', 'Red Guava', 'kg', 'كيلو', 25, false],
    ['فراولة', 'Strawberry', 'kg', 'كيلو', 26, true],
    ['توت إسباني', 'Spanish Berries', 'tray', 'صينية', 27, false],
    ['توت عُماني', 'Omani Berries', 'tray', 'صينية', 28, false],
    ['كيوي إيراني', 'Iranian Kiwi', 'kg', 'كيلو', 29, false],
    ['كيوي إيطالي', 'Italian Kiwi', 'kg', 'كيلو', 30, false],
    ['إجاص إسباني', 'Spanish Pear', 'kg', 'كيلو', 31, false],
    ['إجاص أفريقي', 'African Pear', 'kg', 'كيلو', 32, false],
    ['برقوق أسود', 'Black Plum', 'kg', 'كيلو', 33, false],
    ['برقوق هيليود', 'Heliod Plum', 'kg', 'كيلو', 34, false],
    ['خوخ', 'Peach', 'kg', 'كيلو', 35, false],
    ['خوخ حلو', 'Sweet Peach', 'kg', 'كيلو', 36, false],
    ['مشمش', 'Apricot', 'kg', 'كيلو', 37, false],
    ['تين', 'Fig', 'kg', 'كيلو', 38, false],
    ['رمان حلو', 'Sweet Pomegranate', 'kg', 'كيلو', 39, false],
    ['كاكا', 'Persimmon', 'kg', 'كيلو', 40, false],
    ['كيب جوزبيري', 'Cape Gooseberry', 'tray', 'صينية', 41, false],
    ['كمكوات', 'Kumquat', 'kg', 'كيلو', 42, false],
    ['قشطة', 'Custard Apple', 'kg', 'كيلو', 43, false],
    ['باشن فروت', 'Passion Fruit', 'piece', 'حبة', 44, false],
    ['دراجون فروت', 'Dragon Fruit', 'piece', 'حبة', 45, false],
    ['أفوكادو كيني', 'Kenyan Avocado', 'piece', 'حبة', 46, false],
    ['أناناس', 'Pineapple', 'piece', 'حبة', 47, false],
    ['جوز هند', 'Coconut', 'piece', 'حبة', 48, false],
    ['كستناء', 'Chestnut', 'kg', 'كيلو', 49, false],
    ['سفرجل', 'Quince', 'kg', 'كيلو', 50, false],
    ['بلح برحي', 'Barhi Dates', 'kg', 'كيلو', 51, false],
    ['بلح سيوة', 'Siwa Dates', 'kg', 'كيلو', 52, false],
    ['بلح سكري سعودي', 'Saudi Sukary Dates', 'kg', 'كيلو', 53, false],
    ['بلح مجدول', 'Medjool Dates', 'kg', 'كيلو', 54, false],
    ['شمام بلدي', 'Local Melon', 'piece', 'حبة', 55, false],
    ['كانتالوب', 'Cantaloupe', 'piece', 'حبة', 56, false],
    ['شمام عراقي عسلي', 'Iraqi Honey Melon', 'piece', 'حبة', 57, false],
    ['بطيخ كبير', 'Large Watermelon', 'piece', 'حبة', 58, true],
    ['بطيخ وسط', 'Medium Watermelon', 'piece', 'حبة', 59, false],
    ['بطيخ جامبو', 'Jumbo Watermelon', 'piece', 'حبة', 60, false],
    ['ليتشي', 'Lychee', 'kg', 'كيلو', 61, false],
    ['بابايا', 'Papaya', 'kg', 'كيلو', 62, false],
    ['عنب أبيض', 'White Grapes', 'kg', 'كيلو', 63, false],
    ['عنب أحمر', 'Red Grapes', 'kg', 'كيلو', 64, false],
    ['عنب عناقيد', 'Grape Clusters', 'kg', 'كيلو', 65, false],
    ['توت بلدي', 'Mulberry', 'kg', 'كيلو', 66, false],
    ['تين شوكي', 'Cactus Fruit', 'kg', 'كيلو', 67, false],
    ['عناب', 'Jujube', 'kg', 'كيلو', 68, false],
    ['تمر هندي', 'Tamarind', 'kg', 'كيلو', 69, false],
    ['رمان', 'Pomegranate', 'kg', 'كيلو', 70, false],
    ['خوخ أبيض', 'White Peach', 'kg', 'كيلو', 71, false],
    ['جريب فروت', 'Grapefruit', 'kg', 'كيلو', 72, false],
    ['برقوق أصفر', 'Yellow Plum', 'kg', 'كيلو', 73, false],
    ['فراولة مجمدة', 'Frozen Strawberry', 'bag', 'كيس', 74, false],
  ];

  for (const [nameAr, name, unit, unitAr, order, isPopular] of fruits) {
    await client.query(`
      INSERT INTO products (category_id, name, name_ar, unit, unit_ar, price, display_order, is_visible, is_popular)
      VALUES ($1, $2, $3, $4, $5, 0.00, $6, true, $7)
      ON CONFLICT DO NOTHING
    `, [catId, name, nameAr, unit, unitAr, order, isPopular]);
  }

  console.log(`✅ Seeded ${fruits.length} fruits`);
}

seed().catch((err) => {
  console.error('Seed failed:', err);
  process.exit(1);
});
