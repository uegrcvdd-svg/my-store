-- Seed 004: Default settings
INSERT INTO settings (key, value, label) VALUES
    ('store_name',       'طابع',             'اسم المتجر'),
    ('store_address',    'قنا، مصر',          'عنوان المتجر'),
    ('phone_primary',    '+201008721996',     'رقم الهاتف الأساسي'),
    ('phone_secondary',  '',                  'رقم الهاتف الإضافي'),
    ('whatsapp_number',  '201008721996',      'رقم الواتساب'),
    ('maps_link',        '',                  'رابط خرائط جوجل'),
    ('working_hours',    'يومياً 8 ص - 10 م','ساعات العمل'),
    ('facebook_url',     '',                  'رابط فيسبوك'),
    ('instagram_url',    '',                  'رابط إنستاجرام'),
    ('delivery_area',    'محافظة قنا - مصر', 'منطقة التوصيل'),
    ('currency',         'جنيه',             'العملة')
ON CONFLICT (key) DO NOTHING;
