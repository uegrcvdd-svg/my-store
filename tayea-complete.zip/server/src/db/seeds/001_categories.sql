-- Seed 001: Categories
INSERT INTO categories (id, name, name_ar, slug) VALUES
    ('a1000000-0000-0000-0000-000000000001', 'Vegetables', 'خضار',  'vegetables'),
    ('a1000000-0000-0000-0000-000000000002', 'Fruits',     'فاكهة', 'fruits')
ON CONFLICT (slug) DO NOTHING;
