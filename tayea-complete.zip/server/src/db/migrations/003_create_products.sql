-- Migration 003: Create products table
CREATE TABLE IF NOT EXISTS products (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_id   UUID NOT NULL REFERENCES categories(id) ON DELETE RESTRICT,
    name          VARCHAR(255) NOT NULL,
    name_ar       VARCHAR(255) NOT NULL,
    description   TEXT,
    unit          VARCHAR(50) NOT NULL CHECK (unit IN ('kg','piece','bundle','tray','bag','jar','pack','roll')),
    unit_ar       VARCHAR(50) NOT NULL,
    price         NUMERIC(10,2) NOT NULL DEFAULT 0.00 CHECK (price >= 0),
    display_order INTEGER NOT NULL DEFAULT 999,
    is_visible    BOOLEAN NOT NULL DEFAULT TRUE,
    is_popular    BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_products_updated_at
    BEFORE UPDATE ON products
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_categories_updated_at
    BEFORE UPDATE ON categories
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER trg_admins_updated_at
    BEFORE UPDATE ON admins
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
