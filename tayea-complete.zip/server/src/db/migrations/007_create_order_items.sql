-- Migration 007: Create order_items table (price snapshot)
CREATE TABLE IF NOT EXISTS order_items (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_id        UUID NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    product_id      UUID REFERENCES products(id) ON DELETE SET NULL,
    product_name    VARCHAR(255) NOT NULL,
    product_name_ar VARCHAR(255) NOT NULL,
    quantity        NUMERIC(10,3) NOT NULL CHECK (quantity > 0),
    unit            VARCHAR(50) NOT NULL,
    unit_ar         VARCHAR(50) NOT NULL,
    price_per_unit  NUMERIC(10,2) NOT NULL CHECK (price_per_unit >= 0),
    item_total      NUMERIC(10,2) NOT NULL CHECK (item_total >= 0),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
