-- Migration 004: Create product_images table
CREATE TABLE IF NOT EXISTS product_images (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    product_id  UUID NOT NULL REFERENCES products(id) ON DELETE CASCADE,
    image_url   TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    is_primary  BOOLEAN NOT NULL DEFAULT FALSE,
    sort_order  INTEGER NOT NULL DEFAULT 0,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Only one primary image per product
CREATE UNIQUE INDEX IF NOT EXISTS idx_one_primary_per_product
    ON product_images(product_id)
    WHERE is_primary = TRUE;

CREATE INDEX IF NOT EXISTS idx_product_images_product ON product_images(product_id);
