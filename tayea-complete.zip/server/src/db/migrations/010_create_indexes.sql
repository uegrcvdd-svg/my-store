-- Migration 010: Additional performance indexes
CREATE INDEX IF NOT EXISTS idx_products_category  ON products(category_id);
CREATE INDEX IF NOT EXISTS idx_products_visible   ON products(is_visible);
CREATE INDEX IF NOT EXISTS idx_products_popular   ON products(is_popular);
CREATE INDEX IF NOT EXISTS idx_products_display   ON products(display_order ASC);
CREATE INDEX IF NOT EXISTS idx_products_name_trgm ON products USING gin(name_ar gin_trgm_ops);

-- Enable trigram extension for fuzzy search (if not already enabled)
CREATE EXTENSION IF NOT EXISTS pg_trgm;
