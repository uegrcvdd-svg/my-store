-- Migration 005: Create homepage_banners table
CREATE TABLE IF NOT EXISTS homepage_banners (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    image_url     TEXT NOT NULL,
    storage_key   TEXT NOT NULL,
    title         VARCHAR(255),
    subtitle      VARCHAR(255),
    link_url      TEXT,
    display_order INTEGER NOT NULL DEFAULT 0,
    is_active     BOOLEAN NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_banners_active ON homepage_banners(is_active, display_order);

CREATE TRIGGER trg_banners_updated_at
    BEFORE UPDATE ON homepage_banners
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();
