-- Migration 009: Create activity_logs table
CREATE TYPE IF NOT EXISTS log_action AS ENUM (
    'admin_login',
    'admin_logout',
    'product_created',
    'product_updated',
    'product_deleted',
    'product_visibility_changed',
    'price_updated',
    'banner_created',
    'banner_updated',
    'banner_deleted',
    'order_status_changed',
    'order_viewed',
    'settings_updated',
    'image_uploaded',
    'image_deleted'
);

CREATE TABLE IF NOT EXISTS activity_logs (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    admin_id    UUID REFERENCES admins(id) ON DELETE SET NULL,
    action      log_action NOT NULL,
    entity_type VARCHAR(100),
    entity_id   UUID,
    description TEXT,
    metadata    JSONB,
    ip_address  INET,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_logs_admin   ON activity_logs(admin_id);
CREATE INDEX IF NOT EXISTS idx_logs_action  ON activity_logs(action);
CREATE INDEX IF NOT EXISTS idx_logs_entity  ON activity_logs(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_logs_created ON activity_logs(created_at DESC);
