-- Migration 006: Create orders table
CREATE TYPE IF NOT EXISTS order_status AS ENUM (
    'new',
    'confirmed',
    'prepared',
    'in_delivery',
    'delivered',
    'cancelled'
);

CREATE SEQUENCE IF NOT EXISTS order_number_seq START WITH 1 INCREMENT BY 1;

CREATE TABLE IF NOT EXISTS orders (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    order_number    INTEGER NOT NULL DEFAULT nextval('order_number_seq') UNIQUE,
    customer_name   VARCHAR(255) NOT NULL,
    phone_primary   VARCHAR(20) NOT NULL,
    phone_secondary VARCHAR(20),
    address_text    TEXT NOT NULL,
    gps_lat         NUMERIC(10,8),
    gps_lng         NUMERIC(11,8),
    maps_link       TEXT,
    landmark        TEXT,
    notes           TEXT,
    status          order_status NOT NULL DEFAULT 'new',
    grand_total     NUMERIC(10,2) NOT NULL DEFAULT 0.00 CHECK (grand_total >= 0),
    ordered_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Auto-generate maps_link from coordinates
CREATE OR REPLACE FUNCTION set_maps_link()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.gps_lat IS NOT NULL AND NEW.gps_lng IS NOT NULL THEN
        NEW.maps_link := 'https://maps.google.com/?q=' || NEW.gps_lat || ',' || NEW.gps_lng;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_orders_maps_link
    BEFORE INSERT OR UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION set_maps_link();

CREATE TRIGGER trg_orders_updated_at
    BEFORE UPDATE ON orders
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE INDEX IF NOT EXISTS idx_orders_number   ON orders(order_number);
CREATE INDEX IF NOT EXISTS idx_orders_phone    ON orders(phone_primary);
CREATE INDEX IF NOT EXISTS idx_orders_customer ON orders(customer_name);
CREATE INDEX IF NOT EXISTS idx_orders_status   ON orders(status);
CREATE INDEX IF NOT EXISTS idx_orders_date     ON orders(ordered_at DESC);
