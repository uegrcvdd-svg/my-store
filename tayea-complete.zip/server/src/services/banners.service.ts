import { query } from '../db/pool';

export interface Banner {
  id: string;
  image_url: string;
  storage_key: string;
  title: string | null;
  subtitle: string | null;
  link_url: string | null;
  display_order: number;
  is_active: boolean;
  created_at: string;
  updated_at: string;
}

export async function getActiveBanners(): Promise<Banner[]> {
  const { rows } = await query<Banner>(
    `SELECT id, image_url, title, subtitle, link_url, display_order
     FROM homepage_banners
     WHERE is_active = TRUE
     ORDER BY display_order ASC`
  );
  return rows;
}

export async function getAllBannersAdmin(): Promise<Banner[]> {
  const { rows } = await query<Banner>(
    `SELECT * FROM homepage_banners ORDER BY display_order ASC, created_at DESC`
  );
  return rows;
}

export async function createBanner(data: {
  image_url: string;
  storage_key: string;
  title?: string;
  subtitle?: string;
  link_url?: string;
  display_order?: number;
}): Promise<Banner> {
  const { rows } = await query<Banner>(
    `INSERT INTO homepage_banners (image_url, storage_key, title, subtitle, link_url, display_order)
     VALUES ($1, $2, $3, $4, $5, $6)
     RETURNING *`,
    [
      data.image_url,
      data.storage_key,
      data.title || null,
      data.subtitle || null,
      data.link_url || null,
      data.display_order ?? 0,
    ]
  );
  return rows[0];
}

const BANNER_UPDATE_ALLOWED_COLUMNS = new Set([
  'title', 'subtitle', 'link_url', 'display_order', 'is_active',
]);

export async function updateBanner(
  id: string,
  data: Partial<{
    title: string;
    subtitle: string;
    link_url: string;
    display_order: number;
    is_active: boolean;
  }>
): Promise<Banner | null> {
  const fields: string[] = [];
  const values: unknown[] = [];
  let i = 1;

  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined && BANNER_UPDATE_ALLOWED_COLUMNS.has(key)) {
      fields.push(`${key} = $${i++}`);
      values.push(value);
    }
  }

  if (fields.length === 0) return null;

  values.push(id);
  const { rows } = await query<Banner>(
    `UPDATE homepage_banners SET ${fields.join(', ')}, updated_at = NOW()
     WHERE id = $${i} RETURNING *`,
    values
  );
  return rows[0] || null;
}

export async function toggleBannerActive(id: string): Promise<Banner | null> {
  const { rows } = await query<Banner>(
    `UPDATE homepage_banners SET is_active = NOT is_active, updated_at = NOW()
     WHERE id = $1 RETURNING *`,
    [id]
  );
  return rows[0] || null;
}

export async function deleteBanner(id: string): Promise<Banner | null> {
  const { rows } = await query<Banner>(
    `DELETE FROM homepage_banners WHERE id = $1 RETURNING *`,
    [id]
  );
  return rows[0] || null;
}

export async function reorderBanners(items: { id: string; display_order: number }[]) {
  const promises = items.map(({ id, display_order }) =>
    query(
      'UPDATE homepage_banners SET display_order = $1, updated_at = NOW() WHERE id = $2',
      [display_order, id]
    )
  );
  await Promise.all(promises);
}
