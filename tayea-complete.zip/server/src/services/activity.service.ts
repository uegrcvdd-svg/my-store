import { query } from '../db/pool';
import { logger } from '../utils/logger';

export type LogAction =
  | 'admin_login'
  | 'admin_logout'
  | 'product_created'
  | 'product_updated'
  | 'product_deleted'
  | 'product_visibility_changed'
  | 'price_updated'
  | 'banner_created'
  | 'banner_updated'
  | 'banner_deleted'
  | 'order_status_changed'
  | 'order_viewed'
  | 'settings_updated'
  | 'image_uploaded'
  | 'image_deleted';

interface LogEntry {
  adminId?: string;
  action: LogAction;
  entityType?: string;
  entityId?: string;
  description?: string;
  metadata?: Record<string, unknown>;
  ipAddress?: string;
}

export async function logActivity(entry: LogEntry): Promise<void> {
  try {
    await query(
      `INSERT INTO activity_logs 
        (admin_id, action, entity_type, entity_id, description, metadata, ip_address)
       VALUES ($1, $2, $3, $4, $5, $6, $7::inet)`,
      [
        entry.adminId || null,
        entry.action,
        entry.entityType || null,
        entry.entityId || null,
        entry.description || null,
        entry.metadata ? JSON.stringify(entry.metadata) : null,
        entry.ipAddress || null,
      ]
    );
  } catch (err) {
    // Never crash the app because of logging failure
    logger.error('Failed to write activity log', { entry, error: err });
  }
}

export async function getActivityLogs(page: number, limit: number) {
  const offset = (page - 1) * limit;

  const { rows } = await query<{
    id: string;
    action: string;
    entity_type: string;
    description: string;
    metadata: unknown;
    ip_address: string;
    created_at: string;
    username: string | null;
  }>(
    `SELECT al.id, al.action, al.entity_type, al.entity_id,
            al.description, al.metadata, al.ip_address, al.created_at,
            a.username
     FROM activity_logs al
     LEFT JOIN admins a ON al.admin_id = a.id
     ORDER BY al.created_at DESC
     LIMIT $1 OFFSET $2`,
    [limit, offset]
  );

  const { rows: countRows } = await query<{ count: string }>(
    'SELECT COUNT(*) as count FROM activity_logs'
  );

  return {
    logs: rows,
    total: parseInt(countRows[0]?.count || '0', 10),
  };
}
