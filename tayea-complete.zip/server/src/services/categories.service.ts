import { query } from '../db/pool';

export interface Category {
  id: string;
  name: string;
  name_ar: string;
  slug: string;
  product_count?: number;
}

export async function getAllCategories(): Promise<Category[]> {
  const { rows } = await query<Category>(
    `SELECT c.id, c.name, c.name_ar, c.slug,
            COUNT(p.id) FILTER (WHERE p.is_visible = TRUE) AS product_count
     FROM categories c
     LEFT JOIN products p ON p.category_id = c.id
     GROUP BY c.id
     ORDER BY c.name ASC`
  );
  return rows;
}
