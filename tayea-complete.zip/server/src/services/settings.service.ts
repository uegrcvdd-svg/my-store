import { query } from '../db/pool';

export interface Setting {
  key: string;
  value: string | null;
  label: string | null;
  updated_at: string;
}

export async function getAllSettings(): Promise<Record<string, string>> {
  const { rows } = await query<Setting>('SELECT key, value FROM settings ORDER BY key');
  return Object.fromEntries(rows.map((r) => [r.key, r.value || '']));
}

export async function getAllSettingsWithLabels(): Promise<Setting[]> {
  const { rows } = await query<Setting>(
    'SELECT key, value, label, updated_at FROM settings ORDER BY key'
  );
  return rows;
}

export async function getPublicSettings(): Promise<Record<string, string>> {
  const publicKeys = [
    'store_name',
    'store_address',
    'phone_primary',
    'phone_secondary',
    'whatsapp_number',
    'working_hours',
    'facebook_url',
    'instagram_url',
    'delivery_area',
    'currency',
    'maps_link',
  ];

  const { rows } = await query<Setting>(
    `SELECT key, value FROM settings WHERE key = ANY($1::text[])`,
    [publicKeys]
  );
  return Object.fromEntries(rows.map((r) => [r.key, r.value || '']));
}

export async function updateSettings(
  updates: Record<string, string>
): Promise<void> {
  const promises = Object.entries(updates).map(([key, value]) =>
    query(
      `INSERT INTO settings (key, value) VALUES ($1, $2)
       ON CONFLICT (key) DO UPDATE SET value = $2, updated_at = NOW()`,
      [key, value]
    )
  );
  await Promise.all(promises);
}

export async function getSetting(key: string): Promise<string | null> {
  const { rows } = await query<{ value: string | null }>(
    'SELECT value FROM settings WHERE key = $1',
    [key]
  );
  return rows[0]?.value || null;
}
