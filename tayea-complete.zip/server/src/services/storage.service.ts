import { createClient, SupabaseClient } from '@supabase/supabase-js';
import { logger } from '../utils/logger';

let supabase: SupabaseClient;

export function getSupabaseClient(): SupabaseClient {
  if (!supabase) {
    const url = process.env.SUPABASE_URL;
    const key = process.env.SUPABASE_SERVICE_KEY;

    if (!url || !key) {
      throw new Error('SUPABASE_URL and SUPABASE_SERVICE_KEY are required');
    }

    supabase = createClient(url, key, {
      auth: { persistSession: false },
    });
  }
  return supabase;
}

export async function uploadToStorage(
  bucket: string,
  key: string,
  buffer: Buffer,
  contentType = 'image/webp'
): Promise<string> {
  const client = getSupabaseClient();

  const { error } = await client.storage.from(bucket).upload(key, buffer, {
    contentType,
    upsert: true,
  });

  if (error) {
    logger.error('Supabase upload error', { bucket, key, error: error.message });
    throw new Error(`Storage upload failed: ${error.message}`);
  }

  const { data } = client.storage.from(bucket).getPublicUrl(key);
  return data.publicUrl;
}

export async function deleteFromStorage(bucket: string, key: string): Promise<void> {
  const client = getSupabaseClient();

  const { error } = await client.storage.from(bucket).remove([key]);

  if (error) {
    logger.error('Supabase delete error', { bucket, key, error: error.message });
    throw new Error(`Storage delete failed: ${error.message}`);
  }
}
