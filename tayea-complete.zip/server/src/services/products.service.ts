import { query } from '../db/pool';
import { getPagination, buildMeta } from '../utils/pagination';

export interface Product {
  id: string;
  category_id: string;
  category_name_ar: string;
  category_slug: string;
  name: string;
  name_ar: string;
  description: string | null;
  unit: string;
  unit_ar: string;
  price: string;
  display_order: number;
  is_visible: boolean;
  is_popular: boolean;
  created_at: string;
  updated_at: string;
  images: ProductImage[];
  primary_image: string | null;
}

export interface ProductImage {
  id: string;
  image_url: string;
  storage_key: string;
  is_primary: boolean;
  sort_order: number;
}

const PRODUCT_BASE_QUERY = `
  SELECT 
    p.id, p.category_id, p.name, p.name_ar, p.description,
    p.unit, p.unit_ar, p.price, p.display_order,
    p.is_visible, p.is_popular, p.created_at, p.updated_at,
    c.name_ar AS category_name_ar, c.slug AS category_slug,
    COALESCE(
      json_agg(
        json_build_object(
          'id', pi.id,
          'image_url', pi.image_url,
          'storage_key', pi.storage_key,
          'is_primary', pi.is_primary,
          'sort_order', pi.sort_order
        ) ORDER BY pi.is_primary DESC, pi.sort_order ASC
      ) FILTER (WHERE pi.id IS NOT NULL), '[]'
    ) AS images,
    MAX(CASE WHEN pi.is_primary THEN pi.image_url END) AS primary_image
  FROM products p
  JOIN categories c ON p.category_id = c.id
  LEFT JOIN product_images pi ON pi.product_id = p.id
`;

const PRODUCT_GROUP = `GROUP BY p.id, c.name_ar, c.slug`;

export async function getPublicProducts(
  page: unknown,
  limit: unknown,
  categorySlug?: string,
  search?: string
) {
  const { page: pg, limit: lim, offset } = getPagination(page, limit, 50);

  let whereClause = 'WHERE p.is_visible = TRUE';
  const params: unknown[] = [];
  let paramIndex = 1;

  if (categorySlug) {
    whereClause += ` AND c.slug = $${paramIndex++}`;
    params.push(categorySlug);
  }

  if (search && search.trim()) {
    whereClause += ` AND (p.name_ar ILIKE $${paramIndex} OR p.name ILIKE $${paramIndex})`;
    params.push(`%${search.trim()}%`);
    paramIndex++;
  }

  const countQuery = `
    SELECT COUNT(*) as count FROM products p
    JOIN categories c ON p.category_id = c.id
    ${whereClause}
  `;

  const dataQuery = `
    ${PRODUCT_BASE_QUERY}
    ${whereClause}
    ${PRODUCT_GROUP}
    ORDER BY p.display_order ASC, p.created_at DESC
    LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
  `;

  params.push(lim, offset);

  const [{ rows: countRows }, { rows }] = await Promise.all([
    query<{ count: string }>(countQuery, params.slice(0, paramIndex - 1)),
    query<Product>(dataQuery, params),
  ]);

  const total = parseInt(countRows[0]?.count || '0', 10);
  return { products: rows, meta: buildMeta(pg, lim, total) };
}

export async function getPopularProducts() {
  const { rows } = await query<Product>(
    `${PRODUCT_BASE_QUERY}
     WHERE p.is_visible = TRUE AND p.is_popular = TRUE
     ${PRODUCT_GROUP}
     ORDER BY p.display_order ASC
     LIMIT 20`
  );
  return rows;
}

export async function getProductById(id: string, adminView = false) {
  const visibilityFilter = adminView ? '' : 'AND p.is_visible = TRUE';
  const { rows } = await query<Product>(
    `${PRODUCT_BASE_QUERY}
     WHERE p.id = $1 ${visibilityFilter}
     ${PRODUCT_GROUP}`,
    [id]
  );
  return rows[0] || null;
}

export async function getAllProductsAdmin(
  page: unknown,
  limit: unknown,
  search?: string,
  categorySlug?: string
) {
  const { page: pg, limit: lim, offset } = getPagination(page, limit, 100);

  let whereClause = 'WHERE 1=1';
  const params: unknown[] = [];
  let paramIndex = 1;

  if (categorySlug) {
    whereClause += ` AND c.slug = $${paramIndex++}`;
    params.push(categorySlug);
  }

  if (search && search.trim()) {
    whereClause += ` AND (p.name_ar ILIKE $${paramIndex} OR p.name ILIKE $${paramIndex})`;
    params.push(`%${search.trim()}%`);
    paramIndex++;
  }

  const countQuery = `
    SELECT COUNT(*) as count FROM products p
    JOIN categories c ON p.category_id = c.id
    ${whereClause}
  `;

  const dataQuery = `
    ${PRODUCT_BASE_QUERY}
    ${whereClause}
    ${PRODUCT_GROUP}
    ORDER BY p.display_order ASC, p.created_at DESC
    LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
  `;

  params.push(lim, offset);

  const [{ rows: countRows }, { rows }] = await Promise.all([
    query<{ count: string }>(countQuery, params.slice(0, paramIndex - 1)),
    query<Product>(dataQuery, params),
  ]);

  const total = parseInt(countRows[0]?.count || '0', 10);
  return { products: rows, meta: buildMeta(pg, lim, total) };
}

export async function createProduct(data: {
  category_id: string;
  name: string;
  name_ar: string;
  description?: string;
  unit: string;
  unit_ar: string;
  price: number;
  display_order?: number;
  is_visible?: boolean;
  is_popular?: boolean;
}) {
  const { rows } = await query<{ id: string }>(
    `INSERT INTO products
      (category_id, name, name_ar, description, unit, unit_ar, price, display_order, is_visible, is_popular)
     VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
     RETURNING id`,
    [
      data.category_id,
      data.name,
      data.name_ar,
      data.description || null,
      data.unit,
      data.unit_ar,
      data.price,
      data.display_order ?? 999,
      data.is_visible ?? true,
      data.is_popular ?? false,
    ]
  );
  return rows[0];
}

// Whitelist of columns allowed in dynamic UPDATE to prevent SQL injection
const PRODUCT_UPDATE_ALLOWED_COLUMNS = new Set([
  'category_id', 'name', 'name_ar', 'description', 'unit', 'unit_ar',
  'price', 'display_order', 'is_visible', 'is_popular',
]);

export async function updateProduct(
  id: string,
  data: Partial<{
    category_id: string;
    name: string;
    name_ar: string;
    description: string;
    unit: string;
    unit_ar: string;
    price: number;
    display_order: number;
    is_visible: boolean;
    is_popular: boolean;
  }>
) {
  const fields: string[] = [];
  const values: unknown[] = [];
  let i = 1;

  for (const [key, value] of Object.entries(data)) {
    if (value !== undefined && PRODUCT_UPDATE_ALLOWED_COLUMNS.has(key)) {
      fields.push(`${key} = $${i++}`);
      values.push(value);
    }
  }

  if (fields.length === 0) return null;

  values.push(id);
  const { rows } = await query<{ id: string }>(
    `UPDATE products SET ${fields.join(', ')}, updated_at = NOW()
     WHERE id = $${i} RETURNING id`,
    values
  );
  return rows[0] || null;
}

export async function deleteProduct(id: string) {
  const { rows } = await query<{ id: string }>(
    'DELETE FROM products WHERE id = $1 RETURNING id',
    [id]
  );
  return rows[0] || null;
}

export async function toggleVisibility(id: string) {
  const { rows } = await query<{ id: string; is_visible: boolean }>(
    `UPDATE products SET is_visible = NOT is_visible, updated_at = NOW()
     WHERE id = $1 RETURNING id, is_visible`,
    [id]
  );
  return rows[0] || null;
}

export async function togglePopular(id: string) {
  const { rows } = await query<{ id: string; is_popular: boolean }>(
    `UPDATE products SET is_popular = NOT is_popular, updated_at = NOW()
     WHERE id = $1 RETURNING id, is_popular`,
    [id]
  );
  return rows[0] || null;
}

export async function reorderProducts(items: { id: string; display_order: number }[]) {
  const promises = items.map(({ id, display_order }) =>
    query('UPDATE products SET display_order = $1, updated_at = NOW() WHERE id = $2', [
      display_order,
      id,
    ])
  );
  await Promise.all(promises);
}

// Image management
export async function addProductImage(
  productId: string,
  imageUrl: string,
  storageKey: string,
  isPrimary: boolean
) {
  if (isPrimary) {
    // Unset existing primary
    await query(
      'UPDATE product_images SET is_primary = FALSE WHERE product_id = $1',
      [productId]
    );
  }

  const { rows } = await query<{ id: string }>(
    `INSERT INTO product_images (product_id, image_url, storage_key, is_primary, sort_order)
     VALUES ($1, $2, $3, $4, (SELECT COALESCE(MAX(sort_order), 0) + 1 FROM product_images WHERE product_id = $1))
     RETURNING id`,
    [productId, imageUrl, storageKey, isPrimary]
  );
  return rows[0];
}

export async function setPrimaryImage(productId: string, imageId: string) {
  await query(
    'UPDATE product_images SET is_primary = FALSE WHERE product_id = $1',
    [productId]
  );
  const { rows } = await query<{ id: string }>(
    'UPDATE product_images SET is_primary = TRUE WHERE id = $1 AND product_id = $2 RETURNING id',
    [imageId, productId]
  );
  return rows[0] || null;
}

export async function deleteProductImage(productId: string, imageId: string) {
  const { rows } = await query<{ id: string; storage_key: string; is_primary: boolean }>(
    'DELETE FROM product_images WHERE id = $1 AND product_id = $2 RETURNING id, storage_key, is_primary',
    [imageId, productId]
  );
  const deleted = rows[0];

  // If deleted image was primary, promote next image to primary
  if (deleted?.is_primary) {
    await query(
      `UPDATE product_images SET is_primary = TRUE
       WHERE product_id = $1 AND id = (
         SELECT id FROM product_images WHERE product_id = $1 ORDER BY sort_order ASC LIMIT 1
       )`,
      [productId]
    );
  }

  return deleted || null;
}

// Price management
export async function getAllProductPrices() {
  const { rows } = await query<{
    id: string;
    name_ar: string;
    unit_ar: string;
    price: string;
    category_name_ar: string;
    primary_image: string | null;
  }>(
    `SELECT p.id, p.name_ar, p.unit_ar, p.price,
            c.name_ar AS category_name_ar,
            MAX(CASE WHEN pi.is_primary THEN pi.image_url END) AS primary_image
     FROM products p
     JOIN categories c ON p.category_id = c.id
     LEFT JOIN product_images pi ON pi.product_id = p.id
     WHERE p.is_visible = TRUE
     GROUP BY p.id, c.name_ar
     ORDER BY c.name_ar, p.display_order ASC`
  );
  return rows;
}

export async function updateProductPrice(id: string, price: number) {
  const { rows } = await query<{ id: string; price: string }>(
    `UPDATE products SET price = $1, updated_at = NOW()
     WHERE id = $2 RETURNING id, price`,
    [price, id]
  );
  return rows[0] || null;
}

export async function bulkUpdatePrices(items: { id: string; price: number }[]) {
  const promises = items.map(({ id, price }) => updateProductPrice(id, price));
  return Promise.all(promises);
}
