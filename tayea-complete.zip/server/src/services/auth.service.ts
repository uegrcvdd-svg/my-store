import * as argon2 from 'argon2';
import { query } from '../db/pool';
import { logger } from '../utils/logger';

export interface Admin {
  id: string;
  username: string;
  created_at: string;
}

export async function findAdminByUsername(username: string): Promise<(Admin & { password_hash: string }) | null> {
  const { rows } = await query<Admin & { password_hash: string }>(
    'SELECT id, username, password_hash, created_at FROM admins WHERE username = $1',
    [username]
  );
  return rows[0] || null;
}

export async function verifyPassword(plain: string, hash: string): Promise<boolean> {
  try {
    return await argon2.verify(hash, plain);
  } catch (err) {
    logger.error('Password verification error', { error: err });
    return false;
  }
}

export async function hashPassword(plain: string): Promise<string> {
  return argon2.hash(plain, {
    type: argon2.argon2id,
    memoryCost: 65536,
    timeCost: 3,
    parallelism: 4,
  });
}

export async function changePassword(adminId: string, newPassword: string): Promise<void> {
  const hash = await hashPassword(newPassword);
  await query(
    'UPDATE admins SET password_hash = $1, updated_at = NOW() WHERE id = $2',
    [hash, adminId]
  );
}

export async function changeUsername(adminId: string, newUsername: string): Promise<void> {
  await query(
    'UPDATE admins SET username = $1, updated_at = NOW() WHERE id = $2',
    [newUsername.trim().toLowerCase(), adminId]
  );
}
