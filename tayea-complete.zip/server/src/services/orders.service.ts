import { query } from '../db/pool';
import { getPagination, buildMeta } from '../utils/pagination';

export interface OrderItem {
  id: string;
  product_id: string | null;
  product_name: string;
  product_name_ar: string;
  quantity: string;
  unit: string;
  unit_ar: string;
  price_per_unit: string;
  item_total: string;
}

export interface Order {
  id: string;
  order_number: number;
  customer_name: string;
  phone_primary: string;
  phone_secondary: string | null;
  address_text: string;
  gps_lat: string | null;
  gps_lng: string | null;
  maps_link: string | null;
  landmark: string | null;
  notes: string | null;
  status: string;
  grand_total: string;
  ordered_at: string;
  updated_at: string;
  items?: OrderItem[];
}

export interface CreateOrderInput {
  customer_name: string;
  phone_primary: string;
  phone_secondary?: string;
  address_text: string;
  gps_lat?: number;
  gps_lng?: number;
  landmark?: string;
  notes?: string;
  items: {
    product_id: string;
    quantity: number;
  }[];
}

export async function createOrder(input: CreateOrderInput): Promise<Order> {
  const client = (await import('../db/pool')).pool;
  const conn = await client.connect();

  try {
    await conn.query('BEGIN');

    // Fetch product details and calculate totals
    const productIds = input.items.map((i) => i.product_id);
    const { rows: products } = await conn.query(
      `SELECT id, name, name_ar, unit, unit_ar, price, is_visible
       FROM products WHERE id = ANY($1::uuid[])`,
      [productIds]
    );

    const productMap = new Map(products.map((p: any) => [p.id, p]));

    // Validate all products exist and are visible
    for (const item of input.items) {
      const product = productMap.get(item.product_id);
      if (!product) throw new Error(`المنتج غير موجود: ${item.product_id}`);
      if (!product.is_visible) throw new Error(`المنتج غير متاح: ${product.name_ar}`);
    }

    // Calculate grand total
    let grandTotal = 0;
    const orderItems = input.items.map((item) => {
      const product = productMap.get(item.product_id) as any;
      const pricePerUnit = parseFloat(product.price);
      const itemTotal = pricePerUnit * item.quantity;
      grandTotal += itemTotal;

      return {
        product_id: item.product_id,
        product_name: product.name,
        product_name_ar: product.name_ar,
        quantity: item.quantity,
        unit: product.unit,
        unit_ar: product.unit_ar,
        price_per_unit: pricePerUnit,
        item_total: itemTotal,
      };
    });

    // Insert order
    const { rows: orderRows } = await conn.query(
      `INSERT INTO orders
        (customer_name, phone_primary, phone_secondary, address_text,
         gps_lat, gps_lng, landmark, notes, grand_total)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
       RETURNING *`,
      [
        input.customer_name,
        input.phone_primary,
        input.phone_secondary || null,
        input.address_text,
        input.gps_lat || null,
        input.gps_lng || null,
        input.landmark || null,
        input.notes || null,
        grandTotal.toFixed(2),
      ]
    );

    const order = orderRows[0];

    // Insert order items
    for (const item of orderItems) {
      await conn.query(
        `INSERT INTO order_items
          (order_id, product_id, product_name, product_name_ar,
           quantity, unit, unit_ar, price_per_unit, item_total)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)`,
        [
          order.id,
          item.product_id,
          item.product_name,
          item.product_name_ar,
          item.quantity,
          item.unit,
          item.unit_ar,
          item.price_per_unit,
          item.item_total,
        ]
      );
    }

    await conn.query('COMMIT');
    return order as Order;
  } catch (err) {
    await conn.query('ROLLBACK');
    throw err;
  } finally {
    conn.release();
  }
}

export async function getOrderById(id: string): Promise<Order | null> {
  const { rows } = await query<Order>(
    `SELECT * FROM orders WHERE id = $1`,
    [id]
  );
  const order = rows[0];
  if (!order) return null;

  const { rows: items } = await query<OrderItem>(
    `SELECT * FROM order_items WHERE order_id = $1 ORDER BY created_at ASC`,
    [id]
  );

  order.items = items;
  return order;
}

export async function getOrderByNumber(orderNumber: number): Promise<Order | null> {
  const { rows } = await query<Order>(
    `SELECT * FROM orders WHERE order_number = $1`,
    [orderNumber]
  );
  const order = rows[0];
  if (!order) return null;

  const { rows: items } = await query<OrderItem>(
    `SELECT * FROM order_items WHERE order_id = $1 ORDER BY created_at ASC`,
    [order.id]
  );

  order.items = items;
  return order;
}

export async function getAllOrders(
  page: unknown,
  limit: unknown,
  search?: string,
  status?: string
) {
  const { page: pg, limit: lim, offset } = getPagination(page, limit, 100);

  let whereClause = 'WHERE 1=1';
  const params: unknown[] = [];
  let paramIndex = 1;

  if (status) {
    whereClause += ` AND o.status = $${paramIndex++}`;
    params.push(status);
  }

  if (search && search.trim()) {
    const s = search.trim();
    whereClause += ` AND (
      CAST(o.order_number AS TEXT) ILIKE $${paramIndex}
      OR o.customer_name ILIKE $${paramIndex}
      OR o.phone_primary ILIKE $${paramIndex}
    )`;
    params.push(`%${s}%`);
    paramIndex++;
  }

  const countQuery = `SELECT COUNT(*) as count FROM orders o ${whereClause}`;
  const dataQuery = `
    SELECT o.id, o.order_number, o.customer_name, o.phone_primary,
           o.phone_secondary, o.address_text, o.status, o.grand_total,
           o.ordered_at, o.updated_at,
           (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS item_count
    FROM orders o
    ${whereClause}
    ORDER BY o.ordered_at DESC
    LIMIT $${paramIndex} OFFSET $${paramIndex + 1}
  `;

  params.push(lim, offset);

  const [{ rows: countRows }, { rows }] = await Promise.all([
    query<{ count: string }>(countQuery, params.slice(0, paramIndex - 1)),
    query<Order & { item_count: string }>(dataQuery, params),
  ]);

  const total = parseInt(countRows[0]?.count || '0', 10);
  return { orders: rows, meta: buildMeta(pg, lim, total) };
}

export async function updateOrderStatus(
  id: string,
  status: string
): Promise<Order | null> {
  const validStatuses = ['new', 'confirmed', 'prepared', 'in_delivery', 'delivered', 'cancelled'];
  if (!validStatuses.includes(status)) throw new Error('حالة الطلب غير صحيحة');

  const { rows } = await query<Order>(
    `UPDATE orders SET status = $1::order_status, updated_at = NOW()
     WHERE id = $2 RETURNING *`,
    [status, id]
  );
  return rows[0] || null;
}

export async function getDashboardStats() {
  const { rows } = await query<{
    total_sales_today: string;
    total_sales_all: string;
    orders_today: string;
    orders_total: string;
    customers_total: string;
    new_orders: string;
    total_sales_yesterday: string;
    orders_yesterday: string;
  }>(`
    SELECT
      COALESCE(SUM(CASE WHEN DATE(ordered_at) = CURRENT_DATE THEN grand_total END), 0) AS total_sales_today,
      COALESCE(SUM(grand_total), 0) AS total_sales_all,
      COUNT(CASE WHEN DATE(ordered_at) = CURRENT_DATE THEN 1 END) AS orders_today,
      COUNT(*) AS orders_total,
      COUNT(DISTINCT phone_primary) AS customers_total,
      COUNT(CASE WHEN status = 'new' THEN 1 END) AS new_orders,
      COALESCE(SUM(CASE WHEN DATE(ordered_at) = CURRENT_DATE - INTERVAL '1 day' THEN grand_total END), 0) AS total_sales_yesterday,
      COUNT(CASE WHEN DATE(ordered_at) = CURRENT_DATE - INTERVAL '1 day' THEN 1 END) AS orders_yesterday
    FROM orders
    WHERE status != 'cancelled'
  `);

  return rows[0];
}

export async function getRecentOrders(limit = 10) {
  const { rows } = await query<Order & { item_count: string }>(
    `SELECT o.id, o.order_number, o.customer_name, o.phone_primary,
            o.address_text, o.status, o.grand_total, o.ordered_at,
            (SELECT COUNT(*) FROM order_items WHERE order_id = o.id) AS item_count
     FROM orders o
     ORDER BY o.ordered_at DESC
     LIMIT $1`,
    [limit]
  );
  return rows;
}
