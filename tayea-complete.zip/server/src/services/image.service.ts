import sharp from 'sharp';
import { v4 as uuidv4 } from 'uuid';
import { logger } from '../utils/logger';

const ALLOWED_MIME_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp'];
const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10MB before compression

export function isAllowedImageType(mimetype: string): boolean {
  return ALLOWED_MIME_TYPES.includes(mimetype.toLowerCase());
}

export function validateFileSize(size: number): boolean {
  return size <= MAX_FILE_SIZE;
}

export async function processImage(
  buffer: Buffer,
  options: {
    maxWidth?: number;
    maxHeight?: number;
    quality?: number;
  } = {}
): Promise<{ buffer: Buffer; contentType: string }> {
  const { maxWidth = 1200, maxHeight = 1200, quality = 80 } = options;

  try {
    const processed = await sharp(buffer)
      .resize(maxWidth, maxHeight, {
        fit: 'inside',
        withoutEnlargement: true,
      })
      .webp({ quality })
      .toBuffer();

    return { buffer: processed, contentType: 'image/webp' };
  } catch (error) {
    logger.error('Image processing failed', { error });
    throw new Error('فشل في معالجة الصورة');
  }
}

export async function processBannerImage(buffer: Buffer): Promise<{ buffer: Buffer; contentType: string }> {
  return processImage(buffer, { maxWidth: 1920, maxHeight: 800, quality: 85 });
}

export function generateStorageKey(folder: string, originalName: string): string {
  const ext = 'webp';
  const uuid = uuidv4();
  const timestamp = Date.now();
  return `${folder}/${uuid}-${timestamp}.${ext}`;
}
