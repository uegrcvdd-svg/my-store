export interface PaginationParams {
  page: number;
  limit: number;
  offset: number;
}

export function getPagination(
  rawPage: unknown,
  rawLimit: unknown,
  maxLimit = 100
): PaginationParams {
  const page = Math.max(1, parseInt(String(rawPage || 1), 10) || 1);
  const limit = Math.min(maxLimit, Math.max(1, parseInt(String(rawLimit || 20), 10) || 20));
  const offset = (page - 1) * limit;
  return { page, limit, offset };
}

export function buildMeta(page: number, limit: number, total: number) {
  return {
    page,
    limit,
    total,
    hasMore: page * limit < total,
    totalPages: Math.ceil(total / limit),
  };
}
