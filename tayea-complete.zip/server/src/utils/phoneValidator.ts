/**
 * Egyptian mobile number validation.
 * Valid prefixes: 010, 011, 012, 015
 * Format: 01x-xxxx-xxxx (11 digits)
 */
export function isValidEgyptianPhone(phone: string): boolean {
  const cleaned = phone.replace(/[\s\-\(\)]/g, '');
  return /^01[0125][0-9]{8}$/.test(cleaned);
}

export function normalizePhone(phone: string): string {
  return phone.replace(/[\s\-\(\)]/g, '');
}
