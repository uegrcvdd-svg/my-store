import { Response } from 'express';

export interface ApiMeta {
  page?: number;
  limit?: number;
  total?: number;
  hasMore?: boolean;
}

export function successResponse(
  res: Response,
  data: unknown,
  message = 'تم بنجاح',
  statusCode = 200,
  meta?: ApiMeta
) {
  return res.status(statusCode).json({
    success: true,
    message,
    data,
    ...(meta && { meta }),
  });
}

export function createdResponse(res: Response, data: unknown, message = 'تم الإنشاء بنجاح') {
  return successResponse(res, data, message, 201);
}

export function errorResponse(
  res: Response,
  message: string,
  statusCode = 500,
  code = 'SERVER_ERROR',
  details?: unknown
) {
  return res.status(statusCode).json({
    success: false,
    error: {
      code,
      message,
      ...(details && { details }),
    },
  });
}

export function notFoundResponse(res: Response, message = 'العنصر غير موجود') {
  return errorResponse(res, message, 404, 'NOT_FOUND');
}

export function validationErrorResponse(res: Response, details: unknown) {
  return errorResponse(res, 'بيانات غير صحيحة', 400, 'VALIDATION_ERROR', details);
}

export function unauthorizedResponse(res: Response, message = 'غير مصرح') {
  return errorResponse(res, message, 401, 'UNAUTHORIZED');
}

export function forbiddenResponse(res: Response, message = 'ممنوع') {
  return errorResponse(res, message, 403, 'FORBIDDEN');
}

export function rateLimitResponse(res: Response) {
  return errorResponse(res, 'طلبات كثيرة جداً، حاول لاحقاً', 429, 'RATE_LIMIT_EXCEEDED');
}
