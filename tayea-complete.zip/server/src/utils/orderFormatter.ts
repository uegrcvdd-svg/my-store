interface OrderItem {
  product_name_ar: string;
  quantity: number | string;
  unit_ar: string;
  price_per_unit: number | string;
  item_total: number | string;
}

interface OrderForShare {
  order_number: number;
  customer_name: string;
  phone_primary: string;
  phone_secondary?: string | null;
  address_text: string;
  landmark?: string | null;
  notes?: string | null;
  maps_link?: string | null;
  gps_lat?: number | null;
  gps_lng?: number | null;
  grand_total: number | string;
  status: string;
  items: OrderItem[];
}

const STATUS_LABELS: Record<string, string> = {
  new: 'جديد',
  confirmed: 'تم التأكيد',
  in_delivery: 'قيد التوصيل',
  delivered: 'تم التوصيل',
  cancelled: 'ملغي',
};

export function formatOrderShareMessage(order: OrderForShare): string {
  const lines: string[] = [];

  lines.push('🛒 طلب جديد من طابع');
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`🔢 رقم الطلب: #${order.order_number}`);
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`👤 العميل: ${order.customer_name}`);
  lines.push(`📞 الهاتف: ${order.phone_primary}`);

  if (order.phone_secondary) {
    lines.push(`📞 هاتف إضافي: ${order.phone_secondary}`);
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push('🛍 المنتجات:');

  for (const item of order.items) {
    const qty = Number(item.quantity);
    const price = Number(item.price_per_unit).toFixed(2);
    const total = Number(item.item_total).toFixed(2);
    lines.push(`• ${item.product_name_ar} × ${qty} ${item.unit_ar} @ ${price} ج = ${total} ج`);
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`💰 الإجمالي: ${Number(order.grand_total).toFixed(2)} جنيه`);
  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push('📍 الموقع:');

  const mapsLink =
    order.maps_link ||
    (order.gps_lat && order.gps_lng
      ? `https://maps.google.com/?q=${order.gps_lat},${order.gps_lng}`
      : null);

  if (mapsLink) {
    lines.push(mapsLink);
  } else {
    lines.push(order.address_text);
  }

  if (order.landmark) {
    lines.push(`🏛 علامة مميزة: ${order.landmark}`);
  }

  if (order.notes) {
    lines.push(`📝 ملاحظات: ${order.notes}`);
  }

  lines.push('━━━━━━━━━━━━━━━━━━━━━');
  lines.push(`📌 الحالة: ${STATUS_LABELS[order.status] || order.status}`);

  return lines.join('\n');
}
